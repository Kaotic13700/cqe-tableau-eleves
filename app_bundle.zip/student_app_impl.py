from __future__ import annotations

import os
import shutil
from pathlib import Path

from crypto_quant_engine.dashboard.publication import resolve_latest_public_snapshot


os.environ["CQE_PUBLIC_STUDENT_MODE"] = "1"
configured_data = Path(os.environ["CQE_DATA_DIR"]) if os.getenv("CQE_DATA_DIR") else None
if configured_data is None or not (configured_data / "normalized" / "market.db").exists():
    # Community Cloud may keep process environment variables across a hot
    # redeploy while the bundle loader atomically replaces the directory they
    # pointed to.  Never trust a configured cache path without its database.
    os.environ.pop("CQE_DATA_DIR", None)
    local_data = Path("data")
    if (local_data / "normalized" / "market.db").exists():
        # Local/Discord tunnel: read the same continuously refreshed cache as the internal app.
        os.environ["CQE_DATA_DIR"] = str(local_data)
    else:
        # Hosted classroom app: seed a writable runtime cache from the latest
        # curated publication, then refresh public sources on their own cadence.
        snapshot = resolve_latest_public_snapshot(
            Path(os.getenv("CQE_PUBLIC_SNAPSHOTS_ROOT", "data/public_snapshots"))
        )
        if snapshot is not None:
            runtime = Path(os.getenv("CQE_HOSTED_RUNTIME_DIR", ".runtime_data"))
            if not (runtime / "normalized" / "market.db").exists():
                shutil.copytree(snapshot, runtime, dirs_exist_ok=True)
            os.environ["CQE_DATA_DIR"] = str(runtime)

# Community Cloud keeps this process alive between Streamlit reruns. Schedule
# the refresh on every pass (the 15-minute stamps de-duplicate it) instead of
# limiting collection to the very first runtime-cache creation.
active_data = Path(os.environ["CQE_DATA_DIR"]) if os.getenv("CQE_DATA_DIR") else None
if active_data is not None and active_data.name == Path(
    os.getenv("CQE_HOSTED_RUNTIME_DIR", ".runtime_data")
).name:
    from crypto_quant_engine.dashboard.hosted_refresh import schedule_hosted_refresh, start_hosted_polling


    # HOSTED_SEED_V1: recover a recent, immutable feature cache after a Cloud reboot.
    seed = Path('data/hosted_seed/live/v5-enrichment-gates')
    live = active_data / 'live' / 'v5-enrichment-gates'
    if (seed / 'features.csv.gz').exists() and not (live / 'features.csv.gz').exists():
        live.mkdir(parents=True, exist_ok=True)
        for filename in ('features.csv.gz', 'metadata.json'):
            if (seed / filename).exists():
                shutil.copy2(seed / filename, live / filename)

    start_hosted_polling(active_data)
    schedule_hosted_refresh(active_data)

from crypto_quant_engine.dashboard.runtime import execute_dashboard_page

execute_dashboard_page()
