from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .constants import INSUFFICIENT_CONFIDENCE
from .scoring.data_quality import DataQualityReport
from .scoring.model_confidence import ConfidenceReport


def prediction_payload(
    *,
    snapshot: dict[str, Any],
    model_version: str,
    training_window: str,
    data_quality: DataQualityReport,
    confidence: ConfidenceReport,
    raw_probability: float | None = None,
    calibrated_probability: float | None = None,
    expected_mae: float | None = None,
    expected_mfe: float | None = None,
) -> dict[str, Any]:
    precise = confidence.allows_precise_probability
    return {
        "prediction_timestamp": str(snapshot["prediction_time"]),
        "available_data_timestamp": str(snapshot["feature_available_time"]),
        "asset": snapshot["asset"],
        "price": float(snapshot["spot_price"]),
        "raw_features": snapshot,
        "normalized_features": {key: value for key, value in snapshot.items() if key.endswith("_z")},
        "macro_regime": snapshot.get("macro_regime", "UNCERTAIN"),
        "market_regime": {
            key: snapshot.get(key, "UNCERTAIN")
            for key in ("trend_regime", "volatility_regime", "driver_regime", "positioning_regime", "liquidity_regime")
        },
        "model_version": model_version,
        "training_window": training_window,
        "raw_probability": raw_probability if precise else None,
        "calibrated_probability": calibrated_probability if precise else None,
        "confidence": asdict(confidence),
        "data_quality": asdict(data_quality),
        "expected_mae": expected_mae if precise else None,
        "expected_mfe": expected_mfe if precise else None,
        "status": "STATISTICALLY_USABLE" if precise else INSUFFICIENT_CONFIDENCE,
    }
