from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .constants import INSUFFICIENT_CONFIDENCE
from .scoring.data_quality import DataQualityReport
from .scoring.model_confidence import ConfidenceReport


def validate_probability_context(metadata: dict[str, Any], *, asset: str, horizon: str,
                                 event: str, strategy: str) -> tuple[bool, tuple[str, ...]]:
    required = {"asset", "horizon", "event", "strategy", "model_version", "calibration_version",
                "validation_status", "train_end", "validation_end", "prediction_time"}
    reasons = [f"MISSING_{name.upper()}" for name in sorted(required - set(metadata))]
    for name, expected in (("asset", asset), ("horizon", horizon), ("event", event), ("strategy", strategy)):
        if name in metadata and metadata[name] != expected:
            reasons.append(f"INCOMPATIBLE_{name.upper()}")
    if metadata.get("validation_status") not in {"OOS", "FORWARD_VALIDATED"}:
        reasons.append("NOT_OUT_OF_SAMPLE_VALIDATED")
    try:
        import pandas as pd
        prediction = pd.Timestamp(metadata["prediction_time"])
        for boundary in ("train_end", "validation_end"):
            if pd.Timestamp(metadata[boundary]) >= prediction:
                reasons.append(f"{boundary.upper()}_NOT_BEFORE_PREDICTION")
    except (KeyError, TypeError, ValueError):
        reasons.append("INVALID_VALIDATION_DATES")
    return not reasons, tuple(dict.fromkeys(reasons))


def compute_expected_value(*, probability: float | None, event_return: float | None,
                           non_event_return: float | None, costs: float | None,
                           probability_metadata: dict[str, Any], payoff_metadata: dict[str, Any],
                           asset: str, horizon: str, event: str, strategy: str) -> float | None:
    valid, _ = validate_probability_context(probability_metadata, asset=asset, horizon=horizon,
                                            event=event, strategy=strategy)
    compatible = all(payoff_metadata.get(name) == expected for name, expected in
                     (("asset", asset), ("horizon", horizon), ("event", event), ("strategy", strategy)))
    values = (probability, event_return, non_event_return, costs)
    if not valid or not compatible or any(value is None for value in values):
        return None
    p = float(probability)
    if not 0 <= p <= 1:
        return None
    return p * float(event_return) + (1 - p) * float(non_event_return) - float(costs)


def prediction_payload(
    *,
    snapshot: dict[str, Any],
    model_version: str,
    training_window: str,
    data_quality: DataQualityReport,
    confidence: ConfidenceReport,
    raw_probability: float | None = None,
    calibrated_probability: float | None = None,
    expected_mae: float | None = None,
    expected_mfe: float | None = None,
) -> dict[str, Any]:
    precise = confidence.allows_precise_probability
    return {
        "prediction_timestamp": str(snapshot["prediction_time"]),
        "available_data_timestamp": str(snapshot["feature_available_time"]),
        "asset": snapshot["asset"],
        "price": float(snapshot["spot_price"]),
        "raw_features": snapshot,
        "normalized_features": {key: value for key, value in snapshot.items() if key.endswith("_z")},
        "macro_regime": snapshot.get("macro_regime", "UNCERTAIN"),
        "market_regime": {
            key: snapshot.get(key, "UNCERTAIN")
            for key in ("trend_regime", "volatility_regime", "driver_regime", "positioning_regime", "liquidity_regime")
        },
        "model_version": model_version,
        "training_window": training_window,
        "raw_probability": raw_probability if precise else None,
        "calibrated_probability": calibrated_probability if precise else None,
        "confidence": asdict(confidence),
        "data_quality": asdict(data_quality),
        "expected_mae": expected_mae if precise else None,
        "expected_mfe": expected_mfe if precise else None,
        "status": "STATISTICALLY_USABLE" if precise else INSUFFICIENT_CONFIDENCE,
    }
