from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


DEFAULT_HORIZONS = {
    "4h": timedelta(hours=4),
    "24h": timedelta(hours=24),
    "72h": timedelta(hours=72),
    "7d": timedelta(days=7),
}


def add_forward_returns(
    prices: pd.DataFrame,
    horizons: dict[str, timedelta] | None = None,
    time_column: str = "prediction_time",
    price_column: str = "spot_price",
) -> pd.DataFrame:
    result = prices.sort_values(["asset", time_column]).copy()
    result[time_column] = pd.to_datetime(result[time_column], utc=True)
    for label, horizon in (horizons or DEFAULT_HORIZONS).items():
        result[f"forward_return_{label}"] = np.nan
        result[f"label_end_time_{label}"] = pd.Series(
            pd.NaT, index=result.index, dtype="datetime64[ns, UTC]"
        )
        for _, group in result.groupby("asset"):
            times = group[time_column].to_numpy(dtype="datetime64[ns]")
            values = group[price_column].to_numpy(dtype=float)
            targets = times + np.timedelta64(int(horizon.total_seconds()), "s")
            positions = np.searchsorted(times, targets, side="left")
            valid = positions < len(group)
            returns = np.full(len(group), np.nan)
            ends = np.full(len(group), np.datetime64("NaT", "ns"), dtype="datetime64[ns]")
            returns[valid] = values[positions[valid]] / values[valid] - 1
            ends[valid] = times[positions[valid]]
            result.loc[group.index, f"forward_return_{label}"] = returns
            result.loc[group.index, f"label_end_time_{label}"] = pd.to_datetime(ends, utc=True)
    return result
