from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


def add_first_touch_labels(
    prices: pd.DataFrame,
    thresholds: tuple[float, ...] = (0.01, 0.02, 0.03, 0.05),
    horizon: timedelta = timedelta(hours=72),
    time_column: str = "prediction_time",
    price_column: str = "spot_price",
) -> pd.DataFrame:
    result = prices.sort_values(["asset", time_column]).copy()
    result[time_column] = pd.to_datetime(result[time_column], utc=True)
    for threshold in thresholds:
        key = int(round(threshold * 100))
        result[f"hit_plus_{key}_before_minus_{key}"] = np.nan
        result[f"first_touch_time_{key}"] = pd.Series(
            pd.NaT, index=result.index, dtype="datetime64[ns, UTC]"
        )
    horizon_ns = np.timedelta64(int(horizon.total_seconds()), "s")
    for _, group in result.groupby("asset"):
        times = group[time_column].to_numpy(dtype="datetime64[ns]")
        values = group[price_column].to_numpy(dtype=float)
        for local_index, row_index in enumerate(group.index):
            end = np.searchsorted(times, times[local_index] + horizon_ns, side="right")
            path = values[local_index + 1 : end] / values[local_index] - 1
            path_times = times[local_index + 1 : end]
            for threshold in thresholds:
                key = int(round(threshold * 100))
                up = np.flatnonzero(path >= threshold)
                down = np.flatnonzero(path <= -threshold)
                first_up = up[0] if len(up) else None
                first_down = down[0] if len(down) else None
                if first_up is None and first_down is None:
                    value, touch_time = np.nan, pd.NaT
                elif first_down is None or (first_up is not None and first_up < first_down):
                    value, touch_time = 1.0, pd.Timestamp(path_times[first_up], tz="UTC")
                else:
                    value, touch_time = 0.0, pd.Timestamp(path_times[first_down], tz="UTC")
                result.at[row_index, f"hit_plus_{key}_before_minus_{key}"] = value
                result.at[row_index, f"first_touch_time_{key}"] = touch_time
    return result
