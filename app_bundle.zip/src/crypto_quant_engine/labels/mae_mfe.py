from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


def add_mae_mfe(
    prices: pd.DataFrame,
    horizon: timedelta = timedelta(hours=72),
    suffix: str = "72h",
    time_column: str = "prediction_time",
    price_column: str = "spot_price",
) -> pd.DataFrame:
    result = prices.sort_values(["asset", time_column]).copy()
    result[f"mae_{suffix}"] = np.nan
    result[f"mfe_{suffix}"] = np.nan
    result[f"path_label_end_time_{suffix}"] = pd.Series(
        pd.NaT, index=result.index, dtype="datetime64[ns, UTC]"
    )
    horizon_ns = np.timedelta64(int(horizon.total_seconds()), "s")
    for _, group in result.groupby("asset"):
        times = pd.to_datetime(group[time_column], utc=True).to_numpy(dtype="datetime64[ns]")
        values = group[price_column].to_numpy(dtype=float)
        for local_index, row_index in enumerate(group.index):
            end = np.searchsorted(times, times[local_index] + horizon_ns, side="right")
            path = values[local_index + 1 : end] / values[local_index] - 1
            if len(path):
                result.at[row_index, f"mae_{suffix}"] = min(0.0, float(np.nanmin(path)))
                result.at[row_index, f"mfe_{suffix}"] = max(0.0, float(np.nanmax(path)))
                result.at[row_index, f"path_label_end_time_{suffix}"] = pd.Timestamp(times[end - 1], tz="UTC")
    return result
