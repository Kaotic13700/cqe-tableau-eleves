from __future__ import annotations

from datetime import timezone

ASSETS = ("BTC", "ETH")
UTC = timezone.utc
TIME_COLUMNS = (
    "event_time",
    "exchange_time",
    "received_time",
    "available_time",
    "ingestion_time",
)
FEATURE_FAMILIES = (
    "SPOT",
    "PERPS",
    "OPTIONS",
    "ETF",
    "MACRO",
    "LIQUIDITY",
    "CROSS_ASSET",
    "RELATIVE",
    "VOLATILITY",
)
INSUFFICIENT_CONFIDENCE = "INSUFFICIENT_STATISTICAL_CONFIDENCE"

