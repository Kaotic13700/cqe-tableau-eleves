from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from .collectors.breadth import CoinGeckoMarketBreadthCollector
from .collectors.historical import BinanceHistoricalBackfill
from .collectors.historical.binance import TRANSFORMATION_VERSION
from .collectors.cme import CmeFedWatchCollector
from .collectors.etf import FarsideEtfFlowCollector
from .collectors.macro import FedFomcCollector, FredCsvCollector, JapanStatisticsCpiCollector, EurostatInflationCollector
from .collectors.liquidations import listen_binance_liquidations
from .collectors.options import DeribitOptionsCollector
from .collectors.perps import BinancePerpetualCollector, HyperliquidPerpetualCollector, OkxPerpetualCollector
from .collectors.spot import BinanceSpotCollector, CoinbaseSpotCollector, KrakenSpotCollector, OkxSpotCollector
from .collectors.stablecoins import DefiLlamaStablecoinCollector
from .config import data_dir, load_yaml
from .features.engine import FeatureEngine
from .readiness import assess_backtest_readiness_statistics
from .research.backtest import ResearchSettings, run_research_backtest
from .research.dataset import build_historical_research_dataset, write_research_dataset
from .research.predict import record_forward_predictions
from .storage import NormalizedStore, RawStore
from .storage.features import FeatureStore
from .journal.experiments import ExperimentRegistry
from .journal.predictions import PredictionJournal


def _stores() -> tuple[RawStore, NormalizedStore]:
    root = data_dir()
    return RawStore(root / "raw"), NormalizedStore(root / "normalized" / "market.db")


def collect_command(families: list[str]) -> int:
    exchanges = load_yaml("exchanges.yaml")["exchanges"]
    macro = load_yaml("macro.yaml")
    raw, normalized = _stores()
    collectors = []
    if "spot" in families or "all" in families:
        collectors.extend(
            [
                BinanceSpotCollector(
                    exchanges["binance"]["spot_base_url"], raw, normalized_store=normalized
                ),
                CoinbaseSpotCollector(exchanges["coinbase"]["base_url"], raw),
                KrakenSpotCollector(exchanges["kraken"]["base_url"], raw),
                OkxSpotCollector(exchanges["okx"]["base_url"], raw),
            ]
        )
    if "perps" in families or "all" in families:
        collectors.append(
            BinancePerpetualCollector(
                exchanges["binance"]["futures_base_url"], raw, normalized_store=normalized
            )
        )
        if exchanges.get("okx", {}).get("enabled", False):
            collectors.append(OkxPerpetualCollector(exchanges["okx"]["base_url"], raw))
        if exchanges.get("hyperliquid", {}).get("enabled", False):
            collectors.append(HyperliquidPerpetualCollector(exchanges["hyperliquid"]["base_url"], raw))
    if "options" in families or "all" in families:
        collectors.append(DeribitOptionsCollector(exchanges["deribit"]["base_url"], raw))
    if "macro" in families or "all" in families:
        collectors.append(FredCsvCollector("https://fred.stlouisfed.org", raw, series=macro["series"]))
        collectors.append(JapanStatisticsCpiCollector("https://www.stat.go.jp", raw))
        collectors.append(EurostatInflationCollector("https://ec.europa.eu", raw))
    if "fed" in families or "all" in families:
        collectors.append(FedFomcCollector("https://www.federalreserve.gov", raw))
    if "cme" in families or "all" in families:
        collectors.append(CmeFedWatchCollector("https://cmegroup-tools.quikstrike.net", raw))
    if "etf" in families or "all" in families:
        collectors.append(FarsideEtfFlowCollector("https://farside.co.uk", raw))
    if "stablecoins" in families or "all" in families:
        collectors.append(DefiLlamaStablecoinCollector("https://stablecoins.llama.fi", raw))
    if "breadth" in families or "all" in families:
        collectors.append(CoinGeckoMarketBreadthCollector("https://api.coingecko.com", raw))
    summary = []
    for collector in collectors:
        batch = collector.collect()
        inserted = normalized.insert(batch.observations)
        summary.append(
            {
                "source": collector.source,
                "received": len(batch.observations),
                "inserted": inserted,
                "degraded": batch.degraded,
                "errors": batch.errors,
            }
        )
    print(json.dumps(summary, indent=2))
    return 1 if collectors and all(item["degraded"] for item in summary) else 0


def features_command(version: str) -> int:
    _, normalized = _stores()
    # Daily/live snapshots need enough causal history for the longest rolling
    # feature, not the complete multi-year research database.
    observations = normalized.query(available_after=datetime.now(timezone.utc) - timedelta(days=35))
    exchange_settings = load_yaml("exchanges.yaml")["exchanges"]
    weights = {name: settings.get("quality_weight", 0.5) for name, settings in exchange_settings.items()}
    features = FeatureEngine(weights).build(observations)
    path = FeatureStore(data_dir() / "features").write(
        features,
        version,
        {
            "feature_version": "v5-enrichment-gates",
            "row_count": len(features),
            "point_in_time": True,
            "gamma_dealer_sign_observed": False,
            "gamma_backtest_eligible": False,
            "enrichment_families_forward_only": ["ETF", "STABLECOINS", "LIQUIDATIONS", "CME_FUTURES"],
        },
    )
    print(path)
    return 0


def features_live_command() -> int:
    """Refresh a small current-state cache without accumulating historical snapshots."""

    _, normalized = _stores()
    now = datetime.now(timezone.utc)
    lookbacks = {
        "SPOT": timedelta(days=2),
        "PERPS": timedelta(days=2),
        # Each Deribit snapshot contains the full option chain. Eight hours
        # preserve the current surface while keeping the 15-minute refresh bounded.
        "OPTIONS": timedelta(hours=8),
        "ETF": timedelta(days=35),
        "STABLECOINS": timedelta(days=35),
        "LIQUIDATIONS": timedelta(days=1),
        "CME_FUTURES": timedelta(days=1),
        "MARKET_BREADTH": timedelta(days=2),
    }
    blocks = [
        normalized.query(data_family=family, available_after=now - lookback)
        for family, lookback in lookbacks.items()
    ]
    observations = pd.concat([block for block in blocks if not block.empty], ignore_index=True)
    exchange_settings = load_yaml("exchanges.yaml")["exchanges"]
    weights = {name: settings.get("quality_weight", 0.5) for name, settings in exchange_settings.items()}
    features = FeatureEngine(weights).build(observations)
    if features.empty:
        raise RuntimeError("aucune feature live calculable")
    feature_version = "v5-enrichment-gates"
    path = FeatureStore(data_dir() / "live").write_live(
        features,
        feature_version,
        {
            "feature_version": feature_version,
            "cache_kind": "CURRENT_STATE_NOT_HISTORICAL",
            "generated_at": now.isoformat().replace("+00:00", "Z"),
            "row_count": len(features),
            "point_in_time": True,
            "gamma_dealer_sign_observed": False,
        },
    )
    print(path)
    return 0


def init_command() -> int:
    root = data_dir()
    for name in ("raw", "normalized", "features", "predictions", "experiments"):
        (root / name).mkdir(parents=True, exist_ok=True)
    _stores()
    print(f"Initialized {root.resolve()}")
    return 0


def readiness_command(scope: str = "core") -> int:
    _, normalized = _stores()
    required = ("SPOT", "PERPS") if scope == "core" else ("SPOT", "PERPS", "OPTIONS")
    statistics = normalized.readiness_statistics(required_families=required)
    reports = assess_backtest_readiness_statistics(statistics, required_families=required)
    print(json.dumps([report.to_dict() for report in reports], indent=2))
    return 0


def _utc_argument(value: str) -> datetime:
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        timestamp = timestamp.tz_localize("UTC")
    return timestamp.tz_convert("UTC").to_pydatetime()


def backfill_command(start: str, end: str | None, families: list[str]) -> int:
    exchanges = load_yaml("exchanges.yaml")["exchanges"]
    raw, normalized = _stores()
    backfill = BinanceHistoricalBackfill(
        spot_base_url=exchanges["binance"]["spot_base_url"],
        futures_base_url=exchanges["binance"]["futures_base_url"],
        raw_store=raw,
        normalized_store=normalized,
    )
    family_names = ["SPOT" if family == "spot" else "PERPS" for family in families]
    reports = backfill.backfill_many(
        assets=("BTC", "ETH"),
        families=family_names,
        start=_utc_argument(start),
        end=_utc_argument(end) if end else datetime.now(timezone.utc),
    )
    print(json.dumps([report.to_dict() for report in reports], indent=2))
    return 0 if all(report.status in {"SUCCESS", "ALREADY_CURRENT"} for report in reports) else 1


def research_dataset_command(version: str) -> int:
    _, normalized = _stores()
    observations = normalized.query(transformation_version=TRANSFORMATION_VERSION)
    frame = build_historical_research_dataset(observations)
    if frame.empty:
        raise RuntimeError("aucune donnée historique éligible; lancez d'abord cqe backfill")
    path, digest = write_research_dataset(
        frame,
        data_dir() / "research" / "datasets",
        version,
        {
            "transformation_version": TRANSFORMATION_VERSION,
            "model_features_predeclared": True,
        },
    )
    print(json.dumps({"path": str(path), "sha256": digest, "rows": len(frame)}, indent=2))
    return 0


def backtest_command(dataset_version: str, research_version: str) -> int:
    root = data_dir()
    dataset_path = root / "research" / "datasets" / dataset_version / "dataset.csv.gz"
    if not dataset_path.exists():
        raise FileNotFoundError(f"jeu de recherche introuvable: {dataset_path}")
    frame = pd.read_csv(dataset_path)
    for column in [name for name in frame.columns if "time" in name]:
        frame[column] = pd.to_datetime(frame[column], utc=True, errors="coerce")
    model_config = load_yaml("models.yaml")["validation"]
    settings = ResearchSettings(
        minimum_train_observations=int(model_config["minimum_train_observations"]),
        fold_observations=int(model_config["step_observations"]),
        embargo_observations=int(model_config["embargo_observations"]),
        calibration_observations=int(model_config["validation_observations"]),
        final_holdout_fraction=float(model_config["final_holdout_fraction"]),
        minimum_oos_folds=int(model_config["minimum_oos_folds"]),
    )
    result = run_research_backtest(
        frame=frame,
        dataset_path=dataset_path,
        dataset_version=dataset_version,
        research_version=research_version,
        output_root=root / "research" / "runs",
        model_root=root / "models",
        experiment_registry=ExperimentRegistry(root / "experiments" / "registry.db"),
        settings=settings,
    )
    print(json.dumps({
        "research_version": result["research_version"],
        "evaluations": [
            {
                "asset": item["asset"],
                "target": item["target"],
                "model": item["selected_model"],
                "status": item["status"],
            }
            for item in result["evaluations"]
        ],
    }, indent=2))
    return 0


def predict_command() -> int:
    root = data_dir()
    latest = root / "research" / "runs" / "latest.json"
    if not latest.exists():
        raise FileNotFoundError("aucun modèle de recherche versionné; lancez cqe backtest")
    reports = record_forward_predictions(
        normalized_store=NormalizedStore(root / "normalized" / "market.db"),
        journal=PredictionJournal(root / "predictions" / "journal.db"),
        research_latest_path=latest,
    )
    print(json.dumps(reports, indent=2))
    return 0


def listen_liquidations_command(seconds: int) -> int:
    raw, normalized = _stores()
    summary = listen_binance_liquidations(raw, normalized, duration_seconds=max(0, int(seconds)))
    print(json.dumps(summary, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cqe")
    parser.add_argument("--log-level", default="INFO")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("init")
    readiness_parser = subparsers.add_parser("readiness")
    readiness_parser.add_argument("--scope", choices=["core", "enriched"], default="core")
    backfill_parser = subparsers.add_parser("backfill")
    backfill_parser.add_argument("--start", default="2023-01-01T00:00:00Z")
    backfill_parser.add_argument("--end")
    backfill_parser.add_argument("--families", nargs="+", choices=["spot", "perps"], default=["spot", "perps"])
    dataset_parser = subparsers.add_parser("research-dataset")
    dataset_parser.add_argument("--version", required=True)
    backtest_parser = subparsers.add_parser("backtest")
    backtest_parser.add_argument("--dataset-version", required=True)
    backtest_parser.add_argument("--research-version", required=True)
    subparsers.add_parser("predict")
    liquidations_parser = subparsers.add_parser("listen-liquidations")
    liquidations_parser.add_argument("--seconds", type=int, default=0, help="0 = écoute continue")
    collect_parser = subparsers.add_parser("collect")
    collect_parser.add_argument(
        "families",
        nargs="+",
        choices=["all", "spot", "perps", "options", "macro", "fed", "cme", "etf", "stablecoins", "breadth"],
    )
    feature_parser = subparsers.add_parser("features")
    feature_parser.add_argument("--version", required=True)
    subparsers.add_parser("features-live")
    arguments = parser.parse_args(argv)
    logging.basicConfig(level=getattr(logging, arguments.log_level.upper()), format="%(asctime)s %(levelname)s %(name)s %(message)s")
    if arguments.command == "init":
        return init_command()
    if arguments.command == "collect":
        return collect_command(arguments.families)
    if arguments.command == "features":
        return features_command(arguments.version)
    if arguments.command == "features-live":
        return features_live_command()
    if arguments.command == "readiness":
        return readiness_command(arguments.scope)
    if arguments.command == "backfill":
        return backfill_command(arguments.start, arguments.end, arguments.families)
    if arguments.command == "research-dataset":
        return research_dataset_command(arguments.version)
    if arguments.command == "backtest":
        return backtest_command(arguments.dataset_version, arguments.research_version)
    if arguments.command == "predict":
        return predict_command()
    if arguments.command == "listen-liquidations":
        return listen_liquidations_command(arguments.seconds)
    return 2


if __name__ == "__main__":
    sys.exit(main())
