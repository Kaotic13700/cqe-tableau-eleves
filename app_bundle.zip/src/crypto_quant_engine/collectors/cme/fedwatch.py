from __future__ import annotations

import html
import re
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import requests

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


TOOL_PATH = "/User/QuikStrikeTools.aspx?viewitemid=IntegratedFedWatchTool"
VIEW_PATH = "/User/QuikStrikeView.aspx"
PUBLIC_REFERER = "https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html"


class _RowsParser(HTMLParser):
    """Small dependency-free HTML table parser for the public FedWatch view."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self._row_stack: list[list[str]] = []
        self._cell_stack: list[list[str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "tr":
            self._row_stack.append([])
        elif tag in {"td", "th"} and self._row_stack:
            self._cell_stack.append([])

    def handle_data(self, data: str) -> None:
        if self._cell_stack:
            self._cell_stack[-1].append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self._cell_stack and self._row_stack:
            text = " ".join("".join(self._cell_stack.pop()).split())
            self._row_stack[-1].append(text)
        elif tag == "tr" and self._row_stack:
            row = self._row_stack.pop()
            if row:
                self.rows.append(row)


def _percent(value: str) -> float | None:
    match = re.search(r"(-?\d+(?:[.,]\d+)?)\s*%", value)
    return float(match.group(1).replace(",", ".")) / 100.0 if match else None


def _parse_cme_time(text: str, received: datetime) -> datetime:
    match = re.search(
        r"Data\s+as\s+of\s+(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s+CT",
        text,
        re.IGNORECASE,
    )
    if match:
        month, day, year, hour, minute, second = map(int, match.groups())
    else:
        textual = re.search(
            r"Data\s+as\s+of\s+(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s+CT",
            text,
            re.IGNORECASE,
        )
        if not textual:
            return received
        day_text, month_text, year_text, hour_text, minute_text, second_text = textual.groups()
        parsed = datetime.strptime(f"{day_text} {month_text} {year_text}", "%d %b %Y")
        month, day, year = parsed.month, parsed.day, parsed.year
        hour, minute, second = int(hour_text), int(minute_text), int(second_text)
    central = ZoneInfo("America/Chicago")
    received_utc = received.astimezone(timezone.utc)
    # The public table prints a 12-hour clock but omits AM/PM. Resolve the
    # ambiguity against receipt time and never prefer a materially future tick.
    if 1 <= hour <= 12:
        base_hour = hour % 12
        candidate_hours = (base_hour, base_hour + 12)
    else:
        candidate_hours = (hour,)
    candidates = [
        datetime(year, month, day, candidate_hour, minute, second, tzinfo=central).astimezone(
            timezone.utc
        )
        for candidate_hour in candidate_hours
    ]
    plausible = [candidate for candidate in candidates if candidate <= received_utc + timedelta(minutes=5)]
    pool = plausible or candidates
    return min(pool, key=lambda candidate: abs((received_utc - candidate).total_seconds()))


def parse_fedwatch_html(payload: str, received: datetime) -> dict[str, Any]:
    parser = _RowsParser()
    parser.feed(payload)
    flattened = " ".join(html.unescape(re.sub(r"<[^>]+>", " ", payload)).split())
    event_time = _parse_cme_time(flattened, received)

    meeting_date: str | None = None
    contract: str | None = None
    mid_price: float | None = None
    ease = unchanged = hike = None
    target_probabilities: list[dict[str, Any]] = []

    for row in parser.rows:
        joined = " | ".join(row)
        contract_match = re.search(r"\bZQ[A-Z0-9]{2,4}\b", joined)
        date_match = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", joined)
        textual_date = re.search(r"\b(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})\b", joined)
        if (date_match or textual_date) and contract_match and meeting_date is None:
            if date_match:
                month, day, year = map(int, date_match.groups())
                meeting_date = f"{year:04d}-{month:02d}-{day:02d}"
            else:
                parsed_date = datetime.strptime(textual_date.group(1), "%d %b %Y")
                meeting_date = parsed_date.date().isoformat()
            contract = contract_match.group(0)
            if len(row) >= 4:
                try:
                    mid_price = float(row[3].replace(",", "."))
                except ValueError:
                    mid_price = None

        if len(row) == 3 and all(_percent(cell) is not None for cell in row):
            candidate = [_percent(cell) for cell in row]
            if candidate and abs(sum(value or 0.0 for value in candidate) - 1.0) < 0.02:
                ease, unchanged, hike = candidate

        band_match = re.fullmatch(r"(\d{3})\s*-\s*(\d{3})(?:\s*\(Current\))?", row[0]) if row else None
        if band_match and len(row) >= 2:
            probability = _percent(row[1])
            if probability is not None:
                target_probabilities.append(
                    {
                        "lower_bps": int(band_match.group(1)),
                        "upper_bps": int(band_match.group(2)),
                        "probability": probability,
                        "current": "Current" in row[0],
                    }
                )

    if meeting_date is None or ease is None or unchanged is None or hike is None:
        raise ValueError("FedWatch public table structure was not recognized")
    return {
        "event_time": event_time,
        "meeting_date": meeting_date,
        "contract": contract,
        "mid_price": mid_price,
        "ease_probability": ease,
        "unchanged_probability": unchanged,
        "hike_probability": hike,
        "target_probabilities": target_probabilities,
    }


class CmeFedWatchCollector(BaseCollector):
    """Public CME FedWatch snapshot with receipt-time availability.

    The public view is a current-data convenience path. An authenticated CME
    Market Data API remains preferable for production/licensed redistribution.
    """

    source = "cme_fedwatch_public"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch(coverage={"fedwatch": False})
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; crypto-quant-engine/0.1)",
            "Referer": PUBLIC_REFERER,
            "Accept-Language": "en-US,en;q=0.9",
        }
        try:
            wrapper_url = urljoin(self.base_url + "/", TOOL_PATH.lstrip("/"))
            wrapper = self.session.get(wrapper_url, headers=headers, timeout=self.timeout_seconds)
            wrapper.raise_for_status()
            received = utc_now()
            match = re.search(r"insid=(\d+)&amp;qsid=([0-9a-f-]+)", wrapper.text, re.IGNORECASE)
            if not match:
                raise ValueError("FedWatch session identifiers missing")
            instance_id, session_id = match.groups()
            view_url = urljoin(self.base_url + "/", VIEW_PATH.lstrip("/"))
            view = self.session.get(
                view_url,
                # Keep the duplicate empty marketing fields used by CME's own
                # public iframe. A dict would collapse them and the view rejects
                # the resulting session as an unknown view.
                params=[
                    ("viewitemid", "IntegratedFedWatchTool"),
                    ("userId", "lwolf"),
                    ("jobRole", ""),
                    ("company", ""),
                    ("companyType", ""),
                    ("userId", ""),
                    ("jobRole", ""),
                    ("company", ""),
                    ("companyType", ""),
                    ("insid", instance_id),
                    ("qsid", session_id),
                ],
                headers={**headers, "Referer": wrapper.url},
                timeout=self.timeout_seconds,
            )
            view.raise_for_status()
            received = utc_now()
            if self.raw_store:
                self.raw_store.append(self.source, TOOL_PATH, wrapper.text, received, {"stage": "session"})
                self.raw_store.append(self.source, VIEW_PATH, view.text, received, {"stage": "current_view"})
            parsed = parse_fedwatch_html(view.text, received)
            event_time = parsed.pop("event_time")
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="RATES",
                    asset="MACRO",
                    instrument=f"FEDWATCH_{parsed['meeting_date']}",
                    event_time=event_time,
                    exchange_time=event_time,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=max(0.0, (received - event_time).total_seconds()),
                    values=parsed,
                    metadata={
                        "provider": "CME Group FedWatch",
                        "method": "PUBLIC_FEDWATCH_VIEW",
                        "backtest_eligible": False,
                        "api_upgrade_available": True,
                        "attribution_required": "CME FedWatch",
                    },
                )
            )
            batch.coverage["fedwatch"] = True
        except (requests.RequestException, ValueError) as exc:
            batch.errors.append(f"fedwatch: {exc}")
        return batch
