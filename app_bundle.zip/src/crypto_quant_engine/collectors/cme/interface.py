from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from ...time import ensure_utc


@dataclass(frozen=True)
class DelayedCmeObservation:
    instrument: str
    exchange_time: datetime
    received_time: datetime
    documented_delay_seconds: int
    value: float
    unit: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "exchange_time", ensure_utc(self.exchange_time))
        object.__setattr__(self, "received_time", ensure_utc(self.received_time))
        if self.documented_delay_seconds < 0:
            raise ValueError("documented delay must be non-negative")

    @property
    def available_time(self) -> datetime:
        scheduled = self.exchange_time + timedelta(seconds=self.documented_delay_seconds)
        return max(scheduled, self.received_time)

    @property
    def information_age_seconds(self) -> float:
        return max(0.0, (self.received_time - self.exchange_time).total_seconds())

