from __future__ import annotations

import math
from typing import Any

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def summarize_stablecoin_market(payload: list[dict[str, Any]]) -> dict[str, float | int]:
    """Aggregate CoinGecko's USD stablecoin category without calling it supply."""
    usable: list[tuple[float, float]] = []
    for item in payload:
        try:
            market_cap = float(item.get("market_cap"))
            change_percent = float(item.get("market_cap_change_percentage_24h"))
        except (TypeError, ValueError):
            continue
        if not math.isfinite(market_cap) or market_cap < 0 or not math.isfinite(change_percent):
            continue
        denominator = 1.0 + change_percent / 100.0
        if denominator <= 0:
            continue
        usable.append((market_cap, market_cap - market_cap / denominator))
    if not usable:
        raise ValueError("no comparable USD stablecoin market caps")
    return {
        "stablecoin_market_cap_usd": sum(value for value, _ in usable),
        "stablecoin_market_cap_change_1d_usd": sum(change for _, change in usable),
        "stablecoin_market_asset_count": len(usable),
    }


class CoinGeckoStablecoinCollector(BaseCollector):
    """Independent current market-cap cross-check for the USD stablecoin universe."""

    source = "coingecko_stablecoin_market"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json(
                "/api/v3/coins/markets",
                {
                    "vs_currency": "usd",
                    "category": "stablecoins",
                    "order": "market_cap_desc",
                    "per_page": 250,
                    "page": 1,
                    "sparkline": "false",
                },
            )
            if not isinstance(payload, list):
                raise ValueError("unexpected CoinGecko stablecoin payload")
            values = summarize_stablecoin_market(payload)
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="STABLECOINS",
                    asset="MACRO",
                    instrument="USD_STABLECOIN_MARKET_CAP",
                    quote_currency="USD",
                    event_time=received,
                    exchange_time=received,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=0.0,
                    values=values,
                    metadata={
                        "provider": "CoinGecko",
                        "measure": "USD stablecoin category market capitalization",
                        "not_circulating_supply": True,
                        "not_exchange_flow": True,
                        "available_from_receipt_only": True,
                        "vintage_safe": False,
                        "backtest_eligible": False,
                    },
                )
            )
            batch.coverage["MACRO"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["MACRO"] = False
        return batch
