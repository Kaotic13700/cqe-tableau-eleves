from .defillama import DefiLlamaStablecoinCollector

__all__ = ["DefiLlamaStablecoinCollector"]
