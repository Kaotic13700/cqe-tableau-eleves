from __future__ import annotations

from typing import Any
import math
from datetime import datetime, timezone

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def _usd_amount(item: dict[str, Any], field: str) -> float:
    value = (item.get(field) or {}).get("peggedUSD")
    try:
        result = float(value)
        return result if math.isfinite(result) else math.nan
    except (TypeError, ValueError):
        return math.nan


def summarize_stablecoin_supply(payload: dict[str, Any]) -> dict[str, float | int]:
    """Summarize USD-pegged supply without treating it as exchange inflow."""
    assets = [item for item in payload.get("peggedAssets", []) if item.get("pegType") == "peggedUSD"]
    current_values = [_usd_amount(item, "circulating") for item in assets]
    current = sum(current_values) if current_values and all(map(math.isfinite, current_values)) else math.nan
    def comparable_change(field: str) -> tuple[float, int]:
        pairs = [(value, _usd_amount(item, field)) for item, value in zip(assets, current_values)]
        complete = [(now, before) for now, before in pairs if math.isfinite(now) and math.isfinite(before)]
        if not complete or len(complete) != len(assets):
            return math.nan, len(complete)
        return sum(now - before for now, before in complete), len(complete)
    change_day, day_count = comparable_change("circulatingPrevDay")
    change_week, week_count = comparable_change("circulatingPrevWeek")
    change_month, month_count = comparable_change("circulatingPrevMonth")
    return {
        "stablecoin_supply_usd": current,
        "stablecoin_supply_change_1d_usd": change_day,
        "stablecoin_supply_change_7d_usd": change_week,
        "stablecoin_supply_change_30d_usd": change_month,
        "stablecoin_asset_count": len(assets),
        "stablecoin_comparable_1d_count": day_count,
        "stablecoin_comparable_7d_count": week_count,
        "stablecoin_comparable_30d_count": month_count,
    }


def summarize_supply_history(payload, received):
    """Use one dated aggregate series, never mix its levels with token snapshots."""
    points = {}
    for item in payload:
        try:
            stamp = datetime.fromtimestamp(int(item['date']), timezone.utc)
            value = float(item['totalCirculating']['peggedUSD'])
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        if stamp <= received and math.isfinite(value) and value > 0:
            points[stamp] = value
    if not points:
        raise ValueError('no dated USD supply history')
    reference = max(points)
    if (received - reference).total_seconds() > 48 * 3600:
        raise ValueError('aggregate supply history older than 48 hours')
    result = {'stablecoin_supply_usd': points[reference]}
    from datetime import timedelta
    for days in (1, 7, 30):
        target = reference - timedelta(days=days)
        # Exact daily comparisons only: no silent change of the lookback.
        result[f'stablecoin_supply_change_{days}d_usd'] = (
            points[reference] - points[target] if target in points else math.nan
        )
    return result, reference


class DefiLlamaStablecoinCollector(BaseCollector):
    """Current aggregate supply proxy; provider history isn't assumed point-in-time."""

    source = "defillama_stablecoins"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json("/stablecoins", {"includePrices": "true"})
            values = summarize_stablecoin_supply(payload)
            reference = received
            method = 'token snapshots'
            if any(not math.isfinite(float(values[key])) for key in (
                'stablecoin_supply_change_1d_usd', 'stablecoin_supply_change_7d_usd', 'stablecoin_supply_change_30d_usd'
            )):
                try:
                    history, history_received = self.get_json('/stablecoincharts/all')
                    aggregate, reference = summarize_supply_history(history, history_received)
                    values.update(aggregate)
                    received = history_received
                    method = 'dated aggregate totalCirculating.peggedUSD'
                except Exception as exc:
                    batch.errors.append(f'aggregate history fallback: {exc}')
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="STABLECOINS",
                    asset="MACRO",
                    instrument="USD_PEGGED_TOTAL_SUPPLY",
                    quote_currency="USD",
                    event_time=reference,
                    exchange_time=reference,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=(received - reference).total_seconds(),
                    values=values,
                    metadata={
                        "provider": "DefiLlama",
                        "comparison_method": method,
                        "reference_time": reference.isoformat(),
                        "measure": "circulating supply of USD-pegged assets",
                        "not_exchange_flow": True,
                        "vintage_safe": False,
                        "backtest_eligible": False,
                    },
                )
            )
            batch.coverage["MACRO"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["MACRO"] = False
        return batch
