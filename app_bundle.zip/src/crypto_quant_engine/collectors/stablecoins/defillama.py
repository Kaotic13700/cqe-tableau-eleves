from __future__ import annotations

from typing import Any
import math

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def _usd_amount(item: dict[str, Any], field: str) -> float:
    value = (item.get(field) or {}).get("peggedUSD")
    try:
        result = float(value)
        return result if math.isfinite(result) else math.nan
    except (TypeError, ValueError):
        return math.nan


def summarize_stablecoin_supply(payload: dict[str, Any]) -> dict[str, float | int]:
    """Summarize USD-pegged supply without treating it as exchange inflow."""
    assets = [item for item in payload.get("peggedAssets", []) if item.get("pegType") == "peggedUSD"]
    current_values = [_usd_amount(item, "circulating") for item in assets]
    current = sum(current_values) if current_values and all(map(math.isfinite, current_values)) else math.nan
    def comparable_change(field: str) -> tuple[float, int]:
        pairs = [(value, _usd_amount(item, field)) for item, value in zip(assets, current_values)]
        complete = [(now, before) for now, before in pairs if math.isfinite(now) and math.isfinite(before)]
        if not complete or len(complete) != len(assets):
            return math.nan, len(complete)
        return sum(now - before for now, before in complete), len(complete)
    change_day, day_count = comparable_change("circulatingPrevDay")
    change_week, week_count = comparable_change("circulatingPrevWeek")
    change_month, month_count = comparable_change("circulatingPrevMonth")
    return {
        "stablecoin_supply_usd": current,
        "stablecoin_supply_change_1d_usd": change_day,
        "stablecoin_supply_change_7d_usd": change_week,
        "stablecoin_supply_change_30d_usd": change_month,
        "stablecoin_asset_count": len(assets),
        "stablecoin_comparable_1d_count": day_count,
        "stablecoin_comparable_7d_count": week_count,
        "stablecoin_comparable_30d_count": month_count,
    }


class DefiLlamaStablecoinCollector(BaseCollector):
    """Current aggregate supply proxy; provider history isn't assumed point-in-time."""

    source = "defillama_stablecoins"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json("/stablecoins", {"includePrices": "true"})
            values = summarize_stablecoin_supply(payload)
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="STABLECOINS",
                    asset="MACRO",
                    instrument="USD_PEGGED_TOTAL_SUPPLY",
                    quote_currency="USD",
                    event_time=received,
                    exchange_time=received,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=0.0,
                    values=values,
                    metadata={
                        "provider": "DefiLlama",
                        "measure": "circulating supply of USD-pegged assets",
                        "not_exchange_flow": True,
                        "vintage_safe": False,
                        "backtest_eligible": False,
                    },
                )
            )
            batch.coverage["MACRO"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["MACRO"] = False
        return batch
