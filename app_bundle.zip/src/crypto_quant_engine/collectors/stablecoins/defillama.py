from __future__ import annotations

from typing import Any

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def _usd_amount(item: dict[str, Any], field: str) -> float:
    value = (item.get(field) or {}).get("peggedUSD")
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def summarize_stablecoin_supply(payload: dict[str, Any]) -> dict[str, float | int]:
    """Summarize USD-pegged supply without treating it as exchange inflow."""
    assets = [item for item in payload.get("peggedAssets", []) if item.get("pegType") == "peggedUSD"]
    current = sum(_usd_amount(item, "circulating") for item in assets)
    previous_day = sum(_usd_amount(item, "circulatingPrevDay") for item in assets)
    previous_week = sum(_usd_amount(item, "circulatingPrevWeek") for item in assets)
    previous_month = sum(_usd_amount(item, "circulatingPrevMonth") for item in assets)
    return {
        "stablecoin_supply_usd": current,
        "stablecoin_supply_change_1d_usd": current - previous_day,
        "stablecoin_supply_change_7d_usd": current - previous_week,
        "stablecoin_supply_change_30d_usd": current - previous_month,
        "stablecoin_asset_count": len(assets),
    }


class DefiLlamaStablecoinCollector(BaseCollector):
    """Current aggregate supply proxy; provider history isn't assumed point-in-time."""

    source = "defillama_stablecoins"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json("/stablecoins", {"includePrices": "true"})
            values = summarize_stablecoin_supply(payload)
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="STABLECOINS",
                    asset="MACRO",
                    instrument="USD_PEGGED_TOTAL_SUPPLY",
                    quote_currency="USD",
                    event_time=received,
                    exchange_time=received,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=0.0,
                    values=values,
                    metadata={
                        "provider": "DefiLlama",
                        "measure": "circulating supply of USD-pegged assets",
                        "not_exchange_flow": True,
                        "vintage_safe": False,
                        "backtest_eligible": False,
                    },
                )
            )
            batch.coverage["MACRO"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["MACRO"] = False
        return batch
