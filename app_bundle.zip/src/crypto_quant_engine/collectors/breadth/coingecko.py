from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def parse_coingecko_global(payload: dict[str, Any], received_time: datetime) -> Observation:
    """Parse the public global-market snapshot without claiming historical availability."""

    data = payload.get("data") or {}
    percentages = data.get("market_cap_percentage") or {}
    market_caps = data.get("total_market_cap") or {}
    total_usd = float(market_caps["usd"])
    btc_share = float(percentages["btc"]) / 100.0
    eth_share = float(percentages["eth"]) / 100.0
    if total_usd <= 0 or not 0 < btc_share < 1 or not 0 <= eth_share < 1 or btc_share + eth_share >= 1:
        raise ValueError("invalid CoinGecko global market snapshot")

    provider_timestamp = datetime.fromtimestamp(int(data.get("updated_at") or 0), tz=timezone.utc)
    event_time = min(provider_timestamp, received_time) if provider_timestamp.year > 1970 else received_time
    btc_market_cap = total_usd * btc_share
    total3_market_cap = total_usd * (1.0 - btc_share - eth_share)
    return Observation(
        source="coingecko_global",
        data_family="MARKET_BREADTH",
        asset="MACRO",
        instrument="GLOBAL_CRYPTO_MARKET",
        quote_currency="USD",
        event_time=event_time,
        exchange_time=event_time,
        received_time=received_time,
        available_time=received_time,
        ingestion_time=utc_now(),
        information_age_seconds=max(0.0, (received_time - event_time).total_seconds()),
        values={
            "global_crypto_market_cap_usd": total_usd,
            "btc_dominance": btc_share,
            "eth_dominance": eth_share,
            "total3_market_cap_usd": total3_market_cap,
            "total3_btc": total3_market_cap / btc_market_cap,
        },
        metadata={
            "provider": "CoinGecko",
            "endpoint": "/api/v3/global",
            "provider_updated_at_observed": bool(data.get("updated_at")),
            "vintage_safe": False,
            "backtest_eligible": False,
        },
    )


class CoinGeckoMarketBreadthCollector(BaseCollector):
    source = "coingecko_global"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json("/api/v3/global")
            batch.observations.append(parse_coingecko_global(payload, received))
            batch.coverage["MACRO"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["MACRO"] = False
        return batch
