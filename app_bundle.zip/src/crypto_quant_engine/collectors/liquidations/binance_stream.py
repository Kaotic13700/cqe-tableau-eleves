from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timedelta
from typing import Any

from websockets.sync.client import connect

from ...schema import Observation
from ...storage import NormalizedStore, RawStore
from ...time import milliseconds_to_utc, utc_now


STREAM_URL = "wss://fstream.binance.com/market/ws/!forceOrder@arr"
SYMBOLS = {"BTCUSDT": "BTC", "ETHUSDT": "ETH"}
LOG = logging.getLogger("collector.binance_liquidation_stream")


def parse_force_order_message(payload: dict[str, Any], received_time: datetime) -> Observation | None:
    message = payload.get("data", payload)
    order = message.get("o") or {}
    symbol = str(order.get("s", ""))
    asset = SYMBOLS.get(symbol)
    if asset is None:
        return None
    side = str(order.get("S", "")).upper()
    if side not in {"BUY", "SELL"}:
        return None
    price = float(order.get("ap") or order.get("p") or 0.0)
    quantity = float(order.get("z") or order.get("q") or 0.0)
    if price <= 0 or quantity <= 0:
        return None
    notional = price * quantity
    event_ms = int(order.get("T") or message.get("E"))
    exchange_ms = int(message.get("E") or event_ms)
    event_time = milliseconds_to_utc(event_ms)
    exchange_time = milliseconds_to_utc(exchange_ms)
    long_notional = notional if side == "SELL" else None
    short_notional = notional if side == "BUY" else None
    return Observation(
        source="binance_liquidation_stream",
        data_family="LIQUIDATIONS",
        asset=asset,
        instrument=symbol,
        quote_currency="USDT",
        event_time=event_time,
        exchange_time=exchange_time,
        received_time=received_time,
        available_time=received_time,
        ingestion_time=utc_now(),
        information_age_seconds=max(0.0, (received_time - event_time).total_seconds()),
        values={
            "observed_long_liquidation_notional_usd": long_notional,
            "observed_short_liquidation_notional_usd": short_notional,
            "liquidation_order_count": 1,
            "liquidated_position_side": "LONG" if side == "SELL" else "SHORT",
            "execution_price": price,
            "filled_quantity_base": quantity,
        },
        metadata={
            "stream": "!forceOrder@arr",
            "snapshot_is_lower_bound": True,
            "largest_order_only_per_symbol_per_1000ms": True,
            "backtest_eligible": False,
        },
    )


def _coverage_observations(event_counts: dict[str, int], timestamp: datetime) -> list[Observation]:
    rows: list[Observation] = []
    for symbol, asset in SYMBOLS.items():
        rows.append(
            Observation(
                source="binance_liquidation_stream",
                data_family="LIQUIDATIONS",
                asset=asset,
                instrument=symbol,
                quote_currency="USDT",
                event_time=timestamp,
                exchange_time=timestamp,
                received_time=timestamp,
                available_time=timestamp,
                ingestion_time=utc_now(),
                information_age_seconds=0.0,
                transformation_version="monitor-v1",
                values={
                    "listener_heartbeat": True,
                    "liquidation_events_since_heartbeat": int(event_counts.get(asset, 0)),
                },
                metadata={
                    "stream": "!forceOrder@arr",
                    "coverage_window_seconds": 60,
                    "snapshot_is_lower_bound": True,
                    "backtest_eligible": False,
                },
            )
        )
    return rows


def listen_binance_liquidations(
    raw_store: RawStore,
    normalized_store: NormalizedStore,
    *,
    duration_seconds: int = 0,
    stream_url: str = STREAM_URL,
) -> dict[str, int]:
    """Persist a forward-only liquidation stream; zero duration means continuous."""
    started = time.monotonic()
    deadline = started + duration_seconds if duration_seconds > 0 else None
    next_heartbeat = time.monotonic() + 60
    totals = {"received": 0, "inserted": 0, "ignored": 0, "reconnects": 0}
    heartbeat_counts = {asset: 0 for asset in SYMBOLS.values()}
    while deadline is None or time.monotonic() < deadline:
        try:
            with connect(stream_url, open_timeout=20, ping_timeout=20, close_timeout=5) as socket:
                # A successful subscription is itself useful coverage evidence.  Persist it
                # immediately so a quiet market is represented as "no event observed"
                # instead of being confused with a disconnected source.  Event and
                # availability times remain the receipt time; this row is never eligible
                # for historical backtests.
                connected_at = utc_now()
                totals["inserted"] += normalized_store.insert(
                    _coverage_observations(heartbeat_counts, connected_at)
                )
                next_heartbeat = time.monotonic() + 60
                while deadline is None or time.monotonic() < deadline:
                    now = time.monotonic()
                    timeout = max(0.1, min(30.0, next_heartbeat - now))
                    if deadline is not None:
                        timeout = max(0.1, min(timeout, deadline - now))
                    try:
                        raw_message = socket.recv(timeout=timeout)
                    except TimeoutError:
                        raw_message = None
                    if raw_message is not None:
                        received = utc_now()
                        payload = json.loads(raw_message)
                        raw_store.append(
                            "binance_liquidation_stream",
                            "!forceOrder@arr",
                            payload,
                            received,
                            {"stream_url": stream_url},
                        )
                        totals["received"] += 1
                        observation = parse_force_order_message(payload, received)
                        if observation is None:
                            totals["ignored"] += 1
                        else:
                            totals["inserted"] += normalized_store.insert([observation])
                            heartbeat_counts[observation.asset] += 1
                    if time.monotonic() >= next_heartbeat:
                        timestamp = utc_now()
                        totals["inserted"] += normalized_store.insert(
                            _coverage_observations(heartbeat_counts, timestamp)
                        )
                        heartbeat_counts = {asset: 0 for asset in SYMBOLS.values()}
                        next_heartbeat = time.monotonic() + 60
        except Exception as exc:
            totals["reconnects"] += 1
            LOG.warning("liquidation stream reconnect after error: %s", exc)
            if deadline is not None and time.monotonic() >= deadline:
                break
            time.sleep(2)
    return totals
