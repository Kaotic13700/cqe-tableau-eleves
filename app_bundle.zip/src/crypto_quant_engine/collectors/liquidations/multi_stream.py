"""Public, forward-only liquidation feeds. No private account access required."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import time
import threading

import requests
from websockets.sync.client import connect

from ...schema import Observation
from ...time import milliseconds_to_utc, utc_now
from .binance_stream import listen_binance_liquidations

LOG = logging.getLogger(__name__)
FEEDS = {
    "bybit": ("wss://stream.bybit.com/v5/public/linear",
              {"op": "subscribe", "args": ["allLiquidation.BTCUSDT", "allLiquidation.ETHUSDT"]}),
    "okx": ("wss://ws.okx.com:8443/ws/v5/public",
            {"op": "subscribe", "args": [{"channel": "liquidation-orders", "instType": "SWAP"}]}),
    "bitget": ("wss://ws.bitget.com/v3/ws/public",
               {"op": "subscribe", "args": [{"instType": "usdt-futures", "topic": "liquidation"}]}),
    "gate": ("wss://fx-ws.gateio.ws/v4/ws/usdt",
             {"channel": "futures.public_liquidates", "event": "subscribe", "payload": ["BTC_USDT", "ETH_USDT"]}),
}
PRICE_BASIS = {"bybit": "prix de faillite × quantité exécutée",
               "okx": "prix de liquidation × contrats × valeur du contrat",
               "bitget": "montant en USDT communiqué par Bitget",
               "gate": "prix de l’ordre × contrats × multiplicateur"}


def _positive(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise ValueError("invalid liquidation size or price")
    return number


def parse_liquidations(venue, payload, received, contract_values=None):
    """Keep native source/units. Bybit and Bitget side is POSITION side."""
    result = []
    items = payload.get("result", []) if venue == "gate" and payload.get("event") == "update" else payload.get("data", [])
    for item in items:
        if venue == "okx":
            symbol = str(item.get("instId", ""))
            if symbol not in {"BTC-USDT-SWAP", "ETH-USDT-SWAP"}:
                continue
            details = item.get("details", [])
        elif venue == "gate":
            symbol = str(item.get("contract", ""))
            if symbol not in {"BTC_USDT", "ETH_USDT"}: continue
            details = [item]
        else:
            symbol = str(item.get("s" if venue == "bybit" else "symbol", ""))
            if symbol not in {"BTCUSDT", "ETHUSDT"}:
                continue
            details = [item]
        asset = "BTC" if symbol.startswith("BTC") else "ETH"
        for detail in details:
            if venue == "bybit":
                side = str(detail.get("S", "")).lower()
                if side not in {"buy", "sell"}: raise ValueError("unknown Bybit position side")
                long = side == "buy"
                price, quantity = _positive(detail["p"]), _positive(detail["v"])
                notional = price * quantity
                event = milliseconds_to_utc(detail["T"])
                exchange = milliseconds_to_utc(payload["ts"])
            elif venue == "bitget":
                side = str(detail.get("side", "")).lower()
                if side not in {"buy", "sell"}: raise ValueError("unknown Bitget position side")
                long = side == "buy"
                price = _positive(detail["price"])
                # amount is QUOTE currency: do not multiply by price again.
                notional = _positive(detail["amount"])
                event = milliseconds_to_utc(detail["ts"])
                exchange = milliseconds_to_utc(payload.get("ts", detail["ts"]))
            elif venue == "okx":
                side = str(detail.get("side", "")).lower()
                if side not in {"buy", "sell"}: raise ValueError("unknown OKX order side")
                long = side == "sell"
                position = str(detail.get("posSide", "net"))
                if position in {"long", "short"} and (position == "long") != long:
                    raise ValueError("inconsistent OKX position/order sides")
                price = _positive(detail["bkPx"])
                quantity = _positive(detail["sz"]) * _positive((contract_values or {})[symbol])
                notional = price * quantity
                event = exchange = milliseconds_to_utc(detail["ts"])
            elif venue == "gate":
                size = float(detail["size"])
                _positive(abs(size))
                long = size < 0  # negative order size = sell liquidation order
                price = _positive(detail["price"])
                notional = price * abs(size) * _positive((contract_values or {})[symbol])
                event = milliseconds_to_utc(detail["time"])
                exchange = milliseconds_to_utc(payload["time_ms"])
            else:
                raise ValueError("unsupported liquidation venue")
            if not math.isfinite(notional): raise ValueError("invalid liquidation notional")
            if event > received or exchange > received:
                raise ValueError("future exchange timestamp")
            fingerprint = hashlib.sha256(json.dumps(
                [venue, symbol, detail], sort_keys=True).encode()).hexdigest()
            result.append(Observation(
                source=f"{venue}_liquidation_stream", data_family="LIQUIDATIONS",
                asset=asset, instrument=symbol, quote_currency="USDT",
                event_time=event, exchange_time=exchange, received_time=received,
                available_time=received, ingestion_time=utc_now(),
                information_age_seconds=max(0, (received-event).total_seconds()),
                transformation_version="public-liquidations-multivenue-v1",
                values={"observed_long_liquidation_notional_usd": notional if long else None,
                        "observed_short_liquidation_notional_usd": None if long else notional,
                        "liquidation_order_count": 1, "liquidation_event_key": fingerprint,
                        "liquidation_reference_price": price,
                        "liquidated_position_side": "LONG" if long else "SHORT"},
                metadata={"provider": venue, "price_basis": PRICE_BASIS[venue],
                          "quote_unit": "USDT, USD proxy; not an FX conversion",
                          "partial_feed": True, "backtest_eligible": False,
                          "dedup_policy": "identical source event fingerprint; no global event ID"},
            ))
    return result


def coverage(venue, connected, timestamp, error=""):
    return [Observation(
        source=f"{venue}_liquidation_stream", data_family="LIQUIDATIONS", asset=asset,
        instrument=f"{asset}USDT", quote_currency="USDT",
        event_time=timestamp, exchange_time=timestamp, received_time=timestamp,
        available_time=timestamp, ingestion_time=utc_now(),
        transformation_version="liquidation-listener-status-v2",
        values={"listener_heartbeat": connected, "listener_connected": connected},
        metadata={"provider": venue, "price_basis": PRICE_BASIS[venue],
                  "exchange_timestamp_observed": False, "status_error": error[:250],
                  "backtest_eligible": False},
    ) for asset in ("BTC", "ETH")]


def _okx_contract_values(raw):
    response = requests.get("https://www.okx.com/api/v5/public/instruments",
                            params={"instType": "SWAP"}, timeout=20)
    response.raise_for_status()
    payload = response.json()
    received = utc_now()
    if str(payload.get("code")) != "0": raise ValueError("OKX instrument metadata failed")
    wanted = {"BTC-USDT-SWAP", "ETH-USDT-SWAP"}
    selected = [v for v in payload["data"] if v["instId"] in wanted]
    raw.append("okx_liquidation_stream", "/api/v5/public/instruments", selected, received)
    result = {}
    for item in selected:
        if item.get("ctValCcy") != item["instId"].split("-")[0] or item.get("ctType") != "linear":
            raise ValueError("unsupported OKX contract units")
        result[item["instId"]] = _positive(item["ctVal"]) * _positive(item.get("ctMult") or 1)
    if set(result) != wanted: raise ValueError("OKX contract metadata missing")
    return result


def _listen_public_liquidations(venue, raw, normalized, duration_seconds=0):
    deadline = time.monotonic()+duration_seconds if duration_seconds else float("inf")
    url, subscription = FEEDS[venue]
    inserted = 0
    while time.monotonic() < deadline:
        try:
            multipliers = _okx_contract_values(raw) if venue == "okx" else None
            if venue == "gate":
                multipliers = {}
                for symbol in ("BTC_USDT", "ETH_USDT"):
                    response = requests.get("https://api.gateio.ws/api/v4/futures/usdt/contracts/"+symbol, timeout=15)
                    response.raise_for_status()
                    instrument = response.json()
                    if instrument.get("type") != "direct": raise ValueError("unsupported Gate contract")
                    multipliers[symbol] = _positive(instrument["quanto_multiplier"])
                    raw.append("gate_liquidation_stream", "contract-metadata", instrument, utc_now())
            with connect(url, open_timeout=15, close_timeout=3, ping_interval=20, ping_timeout=20,
                         additional_headers={"X-Gate-Size-Decimal": "1"} if venue == "gate" else None) as ws:
                ws.send(json.dumps(dict(subscription, time=int(time.time())) if venue == "gate" else subscription))
                subscribed = False
                ack_deadline = time.monotonic()+20
                last_server = time.monotonic()
                next_ping = time.monotonic()+15
                next_status = 0
                while time.monotonic() < deadline:
                    now = time.monotonic()
                    if not subscribed and now > ack_deadline: raise TimeoutError("subscription not acknowledged")
                    if now-last_server > 45: raise TimeoutError("server heartbeat missing")
                    if now >= next_ping:
                        ping = json.dumps({"time":int(time.time()), "channel":"futures.ping"}) if venue == "gate" else json.dumps({"op":"ping"}) if venue == "bybit" else "ping"
                        ws.send(ping)
                        next_ping = now+15
                    try:
                        message = ws.recv(timeout=min(5, max(.1, deadline-now)))
                    except TimeoutError:
                        continue
                    payload = {} if message == "pong" else json.loads(message)
                    last_server = time.monotonic()
                    if payload.get("event") == "error" or payload.get("success") is False or payload.get("error"):
                        raise ValueError(str(payload))
                    if (payload.get("event") == "subscribe" and (venue != "gate" or payload.get("result", {}).get("status") == "success")) or (payload.get("op") == "subscribe" and payload.get("success") is True):
                        subscribed = True
                    if not subscribed: continue
                    observations = parse_liquidations(venue, payload, utc_now(), multipliers)
                    if observations:
                        # Archive only target BTC/ETH events, not every market on broad feeds.
                        raw.append(f"{venue}_liquidation_stream", "public-websocket", payload, utc_now())
                        inserted += normalized.insert(observations)
                    if time.monotonic() >= next_status:
                        inserted += normalized.insert(coverage(venue, True, utc_now()))
                        next_status = time.monotonic()+60
        except Exception as exc:
            LOG.warning("%s liquidation reconnect: %s", venue, exc)
            normalized.insert(coverage(venue, False, utc_now(), str(exc)))
            time.sleep(min(5, max(0, deadline-time.monotonic())))
    return {"source": venue, "inserted": inserted}


def listen_public_liquidations(venue, raw, normalized, duration_seconds=0):
    """One listener per venue and database, including across local processes."""
    lock_path = normalized.path.parent / (".liquidation-"+venue+".lock")
    with lock_path.open("a+b") as handle:
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return {"source": venue, "status": "already_listening"}
        try:
            return _listen_public_liquidations(venue, raw, normalized, duration_seconds)
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def listen_all_liquidations(raw, normalized, duration_seconds=0, include_binance=True):
    # Daemon threads do not register an infinite executor join at interpreter
    # shutdown (important when the hosting process is redeployed).
    results = {}
    def run(venue):
        while True:
            try:
                if venue == "binance":
                    results[venue] = listen_binance_liquidations(raw, normalized, duration_seconds=duration_seconds)
                else:
                    results[venue] = listen_public_liquidations(venue, raw, normalized, duration_seconds)
                return
            except Exception as exc:
                LOG.warning("%s listener restart after persistence error: %s", venue, exc)
                if duration_seconds:
                    results[venue] = {"error": str(exc)}
                    return
                time.sleep(5)
    threads = [threading.Thread(target=run,args=(venue,),name="liquidations-"+venue,daemon=True)
               for venue in (["binance"] if include_binance else []) + list(FEEDS)]
    for thread in threads: thread.start()
    for thread in threads: thread.join()
    return results
