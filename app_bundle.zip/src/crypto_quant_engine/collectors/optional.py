from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class UnavailableSource:
    name: str
    reason: str
    required_validation: tuple[str, ...]


ETF_FLOWS = UnavailableSource(
    "consolidated_etf_flows",
    "No official, consolidated, publication-time-stamped free API is configured in V1.",
    ("licensing", "publication timestamp", "historical revisions", "BTC and ETH coverage"),
)
CME = UnavailableSource(
    "cme_delayed",
    "No validated free API with exact delay and historical availability timestamps is configured.",
    ("delay", "contract units", "historical availability", "licensing"),
)
CROSS_ASSET_INTRADAY = UnavailableSource(
    "cross_asset_intraday",
    "No official multi-asset intraday public adapter is configured; macro FRED observations are supported separately.",
    ("timestamp semantics", "licensing", "adjustments", "market hours"),
)

