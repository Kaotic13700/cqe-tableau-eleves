from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable


# v3 intentionally starts a new append-only cursor series.  The former v2
# cursor could remain permanently behind the live market after a long hosted
# outage even though each bounded prefix was internally contiguous.  A new
# version seeds at the current public Binance window, excludes that initial
# window from flow features, and only publishes aggressor flow from the next
# complete, deduplicated interval.  Historical v2 observations remain intact.
BINANCE_CURSOR_TRANSFORMATION_VERSION = "binance-live-cursor-v3"


@dataclass(frozen=True)
class IncrementalTradeWindow:
    trades: tuple[dict[str, Any], ...]
    received_time: datetime
    previous_trade_id: int | None
    committed_trade_id: int | None
    observed_last_trade_id: int | None
    cursor_complete: bool
    cursor_initial_window: bool
    gap_detected: bool
    page_limit_hit: bool
    page_count: int

    @property
    def flow_is_deduplicated(self) -> bool:
        return self.cursor_complete and not self.gap_detected and not self.page_limit_hit

    @property
    def cursor_progress_is_safe(self) -> bool:
        """Whether the contiguous prefix may advance without claiming complete flow."""

        return bool(self.trades) and not self.gap_detected


def fetch_incremental_aggregate_trades(
    get_json: Callable[[str, dict[str, Any]], tuple[Any, datetime]],
    *,
    endpoint: str,
    symbol: str,
    previous_trade_id: int | None,
    max_pages: int = 20,
    page_size: int = 1000,
) -> IncrementalTradeWindow:
    """Fetch a restart-safe, non-overlapping Binance aggregate-trade window.

    For the first observation the endpoint's latest window establishes the
    cursor. Later calls use ``fromId=previous+1`` and page forward. An incomplete
    A discontinuous fetch deliberately keeps the committed cursor unchanged.
    A contiguous page-limited prefix may advance the cursor while its flow stays
    excluded; repeated bounded collections can therefore catch up instead of
    downloading the same first 20,000 trades forever.
    """

    if max_pages < 1:
        raise ValueError("max_pages must be positive")
    if page_size < 1 or page_size > 1000:
        raise ValueError("page_size must be between 1 and 1000")

    initial_window = previous_trade_id is None
    expected_id = None if initial_window else previous_trade_id + 1
    pages = 0
    received_times: list[datetime] = []
    by_id: dict[int, dict[str, Any]] = {}
    gap_detected = False
    page_limit_hit = False
    cursor_complete = False

    while pages < max_pages:
        parameters: dict[str, Any] = {"symbol": symbol, "limit": page_size}
        if expected_id is not None:
            parameters["fromId"] = expected_id
        payload, received = get_json(endpoint, parameters)
        pages += 1
        received_times.append(received)
        if not isinstance(payload, list):
            raise ValueError("unexpected Binance aggregate-trade response")

        page: list[dict[str, Any]] = []
        for item in payload:
            if not isinstance(item, dict) or "a" not in item:
                raise ValueError("aggregate trade is missing its stable trade id")
            trade_id = int(item["a"])
            if previous_trade_id is not None and trade_id <= previous_trade_id:
                continue
            page.append(item)
        page.sort(key=lambda item: int(item["a"]))

        if expected_id is not None and page and int(page[0]["a"]) != expected_id:
            gap_detected = True
            break
        for item in page:
            by_id[int(item["a"])] = item

        if not payload or len(payload) < page_size:
            cursor_complete = True
            break
        if not page:
            # A full page that did not advance the requested cursor cannot be
            # trusted; retry from the last committed id on the next collection.
            break
        expected_id = int(page[-1]["a"]) + 1

    if not cursor_complete and pages >= max_pages:
        page_limit_hit = True

    trades = tuple(by_id[key] for key in sorted(by_id))
    observed_last = int(trades[-1]["a"]) if trades else previous_trade_id
    safe_to_commit = bool(trades) and not gap_detected
    committed = observed_last if safe_to_commit else previous_trade_id
    if not received_times:
        raise RuntimeError("aggregate-trade fetch completed without a response timestamp")
    return IncrementalTradeWindow(
        trades=trades,
        received_time=max(received_times),
        previous_trade_id=previous_trade_id,
        committed_trade_id=committed,
        observed_last_trade_id=observed_last,
        cursor_complete=cursor_complete,
        cursor_initial_window=initial_window,
        gap_detected=gap_detected,
        page_limit_hit=page_limit_hit,
        page_count=pages,
    )
