from __future__ import annotations

import csv
import io
from datetime import timedelta
from typing import Any

import pandas as pd
import requests

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


class FredCsvCollector(BaseCollector):
    """Current FRED series collector. Rows are explicitly not vintage-safe."""

    source = "fred_current"

    def __init__(
        self,
        *args: Any,
        series: dict[str, dict[str, Any]],
        circuit_breaker_failures: int = 3,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.series = series
        self.circuit_breaker_failures = circuit_breaker_failures

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        consecutive_network_failures = 0
        series_items = list(self.series.items())
        for position, (series_id, settings) in enumerate(series_items):
            try:
                response = self.session.get(
                    self.base_url + "/graph/fredgraph.csv",
                    # The official FRED graph endpoint intermittently stalls when
                    # a custom observation start is supplied. The unfiltered CSV
                    # is still compact enough for a daily job and proved much
                    # more reliable; only the latest 800 valid rows are retained.
                    params={"id": series_id},
                    timeout=self.timeout_seconds,
                )
                response.raise_for_status()
                received = utc_now()
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        "/graph/fredgraph.csv",
                        response.text,
                        received,
                        {"series_id": series_id, "request_scope": "official_full_series"},
                    )
                rows = list(csv.DictReader(io.StringIO(response.text)))
                valid = [row for row in rows if row.get(series_id) not in (None, ".", "")]
                if not valid:
                    raise ValueError("no valid observations")
                row = valid[-1]
                date_key = "DATE" if "DATE" in row else "observation_date"
                event_time = pd.Timestamp(row[date_key], tz="UTC").to_pydatetime()
                history_tail = [
                    {
                        "event_time": pd.Timestamp(item[date_key], tz="UTC").isoformat(),
                        "value": float(item[series_id]),
                    }
                    for item in valid[-800:]
                ]
                delay = timedelta(hours=float(settings.get("publication_delay_hours", 24)))
                conservative_known_time = event_time + delay
                # Receipt proves availability now; current FRED does not prove when a historical vintage was available.
                available = received
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="MACRO",
                        asset="MACRO",
                        instrument=series_id,
                        event_time=event_time,
                        exchange_time=event_time,
                        received_time=received,
                        available_time=available,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - event_time).total_seconds()),
                        values={
                            "value": float(row[series_id]),
                            "dimension": settings.get("dimension"),
                            "region": settings.get("region"),
                            "central_bank": settings.get("central_bank"),
                            "role": settings.get("role"),
                            "label": settings.get("label"),
                            "unit": settings.get("unit"),
                            # Current-revision context is useful for a live macro
                            # dashboard, but is never eligible for a historical model.
                            "history_tail": history_tail,
                        },
                        metadata={
                            "provider": "FRED · Federal Reserve Bank of St. Louis",
                            "upstream_authority": settings.get("central_bank"),
                            "vintage_safe": False,
                            "backtest_eligible": False,
                            "configured_earliest_release_estimate": conservative_known_time.isoformat(),
                            "reason": "current FRED CSV may include revisions; use ALFRED vintages for historical modelling",
                        },
                    )
                )
                batch.coverage[series_id] = True
                consecutive_network_failures = 0
            except Exception as exc:
                batch.errors.append(f"{series_id}: {exc}")
                batch.coverage[series_id] = False
                if isinstance(exc, requests.RequestException):
                    consecutive_network_failures += 1
                else:
                    consecutive_network_failures = 0
                if consecutive_network_failures >= self.circuit_breaker_failures:
                    for remaining_id, _ in series_items[position + 1 :]:
                        batch.coverage[remaining_id] = False
                        batch.errors.append(
                            f"{remaining_id}: source circuit open after {consecutive_network_failures} network failures"
                        )
                    break
        return batch
