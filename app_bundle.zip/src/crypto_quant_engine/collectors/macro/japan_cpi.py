from __future__ import annotations

import html as html_module
import re
from datetime import datetime, timezone
from html.parser import HTMLParser

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


class _VisibleTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        if data.strip():
            self.parts.append(data.strip())


def parse_japan_cpi_release(html: str) -> dict[str, object]:
    """Parse the official Statistics Bureau headline CPI release."""

    parser = _VisibleTextParser()
    parser.feed(html)
    text = " ".join(html_module.unescape(part) for part in parser.parts)
    text = re.sub(r"\s+", " ", text)
    period = re.search(
        r"(?P<base>\d{4})年基準[^。]{0,80}?(?P<year>\d{4})年（令和\d+年）(?P<month>\d{1,2})月分"
        r"（(?P<release_year>\d{4})年(?P<release_month>\d{1,2})月(?P<release_day>\d{1,2})日公表）",
        text,
    )
    index_match = re.search(r"総合指数\s*は\s*\d{4}年を100として\s*(?P<index>\d+(?:\.\d+)?)", text)
    yoy_match = re.search(r"前年同月比は\s*(?P<yoy>\d+(?:\.\d+)?)[%％]の(?P<direction>上昇|低下)", text)
    if not period or not index_match or not yoy_match:
        raise ValueError("official Japan CPI headline could not be parsed")
    yoy = float(yoy_match.group("yoy"))
    if yoy_match.group("direction") == "低下":
        yoy = -yoy
    event_time = datetime(int(period.group("year")), int(period.group("month")), 1, tzinfo=timezone.utc)
    release_date = datetime(
        int(period.group("release_year")),
        int(period.group("release_month")),
        int(period.group("release_day")),
        tzinfo=timezone.utc,
    )
    return {
        "base_year": int(period.group("base")),
        "event_time": event_time,
        "release_date": release_date,
        "headline_index": float(index_match.group("index")),
        "headline_yoy_pct": yoy,
    }


class JapanStatisticsCpiCollector(BaseCollector):
    source = "japan_statistics_cpi"
    endpoint = "/data/cpi/sokuhou/tsuki/index-z.htm"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            response = self.session.get(
                self.base_url + self.endpoint,
                timeout=self.timeout_seconds,
                headers={"User-Agent": "crypto-quant-engine/0.1"},
            )
            response.raise_for_status()
            response.encoding = response.apparent_encoding or response.encoding
            received = utc_now()
            parsed = parse_japan_cpi_release(response.text)
            if self.raw_store:
                self.raw_store.append(
                    self.source,
                    self.endpoint,
                    response.text,
                    received,
                    {"status_code": response.status_code, "content_type": response.headers.get("Content-Type")},
                )
            event_time = parsed["event_time"]
            release_date = parsed["release_date"]
            batch.observations.append(
                Observation(
                    source=self.source,
                    data_family="MACRO",
                    asset="MACRO",
                    instrument="JAPAN_CPI_HEADLINE_YOY",
                    event_time=event_time,
                    exchange_time=release_date,
                    received_time=received,
                    available_time=received,
                    ingestion_time=utc_now(),
                    information_age_seconds=max(0.0, (received - release_date).total_seconds()),
                    values={
                        "value": parsed["headline_yoy_pct"],
                        "headline_index": parsed["headline_index"],
                        "base_year": parsed["base_year"],
                        "dimension": "inflation",
                        "region": "JAPAN",
                        "central_bank": "BOJ",
                        "role": "inflation_yoy",
                        "label": "Inflation générale du Japon",
                        "unit": "pct_yoy",
                        "history_tail": [
                            {"event_time": event_time.isoformat(), "value": parsed["headline_yoy_pct"]}
                        ],
                    },
                    metadata={
                        "provider": "Statistics Bureau of Japan",
                        "publication_time_observed": False,
                        "available_from_receipt_only": True,
                        "vintage_safe": False,
                        "backtest_eligible": False,
                    },
                )
            )
            batch.coverage["JAPAN_CPI"] = True
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage["JAPAN_CPI"] = False
        return batch
