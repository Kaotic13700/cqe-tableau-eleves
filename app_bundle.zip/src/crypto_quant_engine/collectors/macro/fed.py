from __future__ import annotations

import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin

import pandas as pd
import requests

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


CALENDAR_PATH = "/monetarypolicy/fomccalendars.htm"


class _FomcCalendarParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.meetings: list[dict[str, Any]] = []
        self.year: int | None = None
        self._heading_depth = 0
        self._heading_text: list[str] = []
        self._meeting_depth = 0
        self._meeting: dict[str, Any] | None = None
        self._capture: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").split())
        if tag == "div" and "panel-heading" in classes:
            self._heading_depth = 1
            self._heading_text = []
            return
        if self._heading_depth and tag == "div":
            self._heading_depth += 1
        if tag == "div" and "fomc-meeting" in classes:
            self._meeting_depth = 1
            self._meeting = {"year": self.year, "text": [], "links": []}
            return
        if self._meeting_depth:
            if tag == "div":
                self._meeting_depth += 1
            if "fomc-meeting__month" in classes:
                self._capture = "month"
                self._meeting["month"] = []
            elif "fomc-meeting__date" in classes:
                self._capture = "date"
                self._meeting["date"] = []
            if tag == "a" and attributes.get("href"):
                self._meeting["links"].append(attributes["href"])

    def handle_data(self, data: str) -> None:
        if self._heading_depth:
            self._heading_text.append(data)
        if self._meeting is not None:
            self._meeting["text"].append(data)
            if self._capture:
                self._meeting[self._capture].append(data)

    def handle_endtag(self, tag: str) -> None:
        if self._heading_depth and tag == "div":
            self._heading_depth -= 1
            if self._heading_depth == 0:
                match = re.search(r"(20\d{2})\s+FOMC", " ".join(self._heading_text))
                if match:
                    self.year = int(match.group(1))
        if self._meeting_depth and tag == "div":
            if self._meeting_depth == 2 and self._capture:
                self._capture = None
            self._meeting_depth -= 1
            if self._meeting_depth == 0 and self._meeting is not None:
                item = self._meeting
                item["month"] = " ".join(item.get("month", [])).strip()
                item["date"] = " ".join(item.get("date", [])).strip()
                item["text"] = " ".join(" ".join(item["text"]).split())
                self.meetings.append(item)
                self._meeting = None


class _VisibleTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.text: list[str] = []
        self._ignored = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "nav"}:
            self._ignored += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "nav"} and self._ignored:
            self._ignored -= 1

    def handle_data(self, data: str) -> None:
        if not self._ignored:
            self.text.append(data)


def _document_text(payload: str) -> str:
    parser = _VisibleTextParser()
    parser.feed(payload)
    return " ".join(" ".join(parser.text).split())


def _fractional_percent(value: str) -> float:
    value = value.strip().replace("–", "-")
    mixed = re.fullmatch(r"(\d+)-(\d+)/(\d+)", value)
    if mixed:
        return int(mixed.group(1)) + int(mixed.group(2)) / int(mixed.group(3))
    fraction = re.fullmatch(r"(\d+)/(\d+)", value)
    if fraction:
        return int(fraction.group(1)) / int(fraction.group(2))
    return float(value)


def parse_target_range(text: str) -> tuple[float, float] | None:
    match = re.search(
        r"target range for the federal funds rate at\s+([0-9]+(?:-[0-9]+/[0-9]+|/[0-9]+)?)\s+to\s+"
        r"([0-9]+(?:-[0-9]+/[0-9]+|/[0-9]+)?)\s+percent",
        text,
        re.IGNORECASE,
    )
    if not match:
        return None
    return _fractional_percent(match.group(1)), _fractional_percent(match.group(2))


HAWKISH_TERMS = (
    "inflation remains somewhat elevated",
    "upside risks to inflation",
    "restrictive stance",
    "not appropriate to reduce",
    "higher for longer",
)
DOVISH_TERMS = (
    "inflation has eased",
    "downside risks to employment",
    "appropriate to reduce",
    "less restrictive",
    "slowing pace",
)


def language_counts(text: str) -> tuple[int, int]:
    lowered = text.lower()
    return sum(lowered.count(term) for term in HAWKISH_TERMS), sum(
        lowered.count(term) for term in DOVISH_TERMS
    )


def parse_fomc_calendar(payload: str, base_url: str) -> list[dict[str, Any]]:
    parser = _FomcCalendarParser()
    parser.feed(payload)
    rows: list[dict[str, Any]] = []
    for item in parser.meetings:
        links = item.get("links", [])
        statement = next(
            (urljoin(base_url + "/", link) for link in links if re.search(r"monetary\d{8}a\.htm$", link)),
            None,
        )
        minutes = next(
            (urljoin(base_url + "/", link) for link in links if re.search(r"fomcminutes\d{8}\.htm$", link)),
            None,
        )
        encoded = re.search(r"(20\d{6})", statement or minutes or "")
        if encoded:
            meeting_date = pd.Timestamp(encoded.group(1), tz="UTC").date().isoformat()
        else:
            continue
        release = re.search(r"Released\s+([A-Za-z]+\s+\d{1,2},\s+20\d{2})", item["text"])
        rows.append(
            {
                "meeting_date": meeting_date,
                "has_sep": "*" in item.get("date", ""),
                "statement_url": statement,
                "minutes_url": minutes,
                "minutes_release_date": (
                    pd.Timestamp(release.group(1), tz="UTC").date().isoformat() if release else None
                ),
            }
        )
    return rows


class FedFomcCollector(BaseCollector):
    source = "federal_reserve_fomc"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch(coverage={"calendar": False, "statement": False, "minutes": False})
        try:
            response = self.session.get(
                self.base_url + CALENDAR_PATH,
                timeout=self.timeout_seconds,
                headers={"User-Agent": "crypto-quant-engine/0.1"},
            )
            response.raise_for_status()
            received = utc_now()
            if self.raw_store:
                self.raw_store.append(self.source, CALENDAR_PATH, response.text, received, {})
            meetings = parse_fomc_calendar(response.text, self.base_url)
            today = received.date().isoformat()
            released = [item for item in meetings if item["meeting_date"] <= today and item["statement_url"]]
            latest = max(released, key=lambda item: item["meeting_date"]) if released else None
            statement_text = minutes_text = ""
            targets_by_meeting: dict[str, tuple[float, float] | None] = {}
            # The target-range decision is an objective, auditable feature. Keep
            # the recent policy path; no linguistic classifier enters a model.
            recent_released = sorted(
                [item for item in released if item["meeting_date"] >= "2023-01-01"],
                key=lambda item: item["meeting_date"],
            )
            for item in recent_released:
                document = self.session.get(
                    item["statement_url"],
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1"},
                )
                document.raise_for_status()
                text = _document_text(document.text)
                targets_by_meeting[item["meeting_date"]] = parse_target_range(text)
                if latest and item["meeting_date"] == latest["meeting_date"]:
                    statement_text = text
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        item["statement_url"],
                        document.text,
                        received,
                        {"document": "statement", "meeting_date": item["meeting_date"]},
                    )
            batch.coverage["statement"] = bool(statement_text)
            if latest and latest.get("minutes_url"):
                document = self.session.get(
                    latest["minutes_url"],
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1"},
                )
                document.raise_for_status()
                minutes_text = _document_text(document.text)
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        latest["minutes_url"],
                        document.text,
                        received,
                        {"document": "minutes", "meeting_date": latest["meeting_date"]},
                    )
                batch.coverage["minutes"] = True
            statement_hawkish, statement_dovish = language_counts(statement_text)
            minutes_hawkish, minutes_dovish = language_counts(minutes_text)
            for item in meetings:
                meeting_time = pd.Timestamp(item["meeting_date"], tz="UTC").to_pydatetime()
                values = dict(item)
                target = targets_by_meeting.get(item["meeting_date"])
                values.update(
                    {
                        "target_lower_pct": target[0] if target else None,
                        "target_upper_pct": target[1] if target else None,
                    }
                )
                if latest and item["meeting_date"] == latest["meeting_date"]:
                    values.update(
                        {
                            "statement_hawkish_count": statement_hawkish,
                            "statement_dovish_count": statement_dovish,
                            "minutes_hawkish_count": minutes_hawkish,
                            "minutes_dovish_count": minutes_dovish,
                        }
                    )
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="FED",
                        asset="MACRO",
                        instrument=f"FOMC_{item['meeting_date']}",
                        event_time=meeting_time,
                        exchange_time=meeting_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - meeting_time).total_seconds()),
                        values=values,
                        metadata={
                            "official_source": True,
                            "backtest_eligible": False,
                            "reason": "calendar/documents retrieved now; historical document vintages are not archived locally",
                            "language_counts_exploratory": True,
                        },
                    )
                )
            batch.coverage["calendar"] = bool(meetings)
        except (requests.RequestException, ValueError) as exc:
            batch.errors.append(f"fomc: {exc}")
        return batch
