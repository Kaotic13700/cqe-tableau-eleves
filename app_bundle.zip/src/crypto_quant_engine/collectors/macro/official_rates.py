"""Séries monétaires officielles utilisées lorsque les relais FRED sont en retard."""

from __future__ import annotations

import csv
import io
import math
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def parse_ecb_m3_csv(payload: str) -> list[dict[str, object]]:
    """Accepte uniquement la série M3 annuelle et ses périodes publiées."""
    expected = "BSI.M.U2.Y.V.M30.X.I.U2.2300.Z01.A"
    rows: list[dict[str, object]] = []
    for row in csv.DictReader(io.StringIO(payload)):
        if row.get("KEY") != expected:
            raise ValueError("Série BCE M3 inattendue")
        period = pd.to_datetime(row.get("TIME_PERIOD"), utc=True, errors="coerce")
        try:
            value = float(row.get("OBS_VALUE", ""))
        except (TypeError, ValueError):
            continue
        if pd.notna(period) and math.isfinite(value):
            rows.append({"event_time": period.isoformat(), "value": value})
    if not rows:
        raise ValueError("Aucune observation M3 BCE publiée")
    return sorted(rows, key=lambda item: str(item["event_time"]))


def parse_boj_series(payload: dict[str, Any], *, code: str, frequency: str) -> list[dict[str, object]]:
    """Valide code, unité, fréquence, dates et valeurs de l'API BoJ."""
    if payload.get("STATUS") != 200 or not isinstance(payload.get("RESULTSET"), list):
        raise ValueError("Réponse BoJ invalide")
    series = next((item for item in payload["RESULTSET"] if item.get("SERIES_CODE") == code), None)
    expected_unit = "%" if frequency == "MONTHLY" else "percent per annum"
    if not series or series.get("FREQUENCY") != frequency or series.get("UNIT") != expected_unit:
        raise ValueError("Série BoJ, fréquence ou unité inattendue")
    values = series.get("VALUES", {})
    dates, numbers = values.get("SURVEY_DATES", []), values.get("VALUES", [])
    if len(dates) != len(numbers):
        raise ValueError("Dates et valeurs BoJ désalignées")
    rows: list[dict[str, object]] = []
    for date, number in zip(dates, numbers):
        if number is None:
            continue
        value = float(number)
        if not math.isfinite(value):
            continue
        stamp = datetime.strptime(str(date), "%Y%m" if frequency == "MONTHLY" else "%Y%m%d")
        rows.append({"event_time": stamp.replace(tzinfo=timezone.utc).isoformat(), "value": value})
    if not rows:
        raise ValueError("Aucune observation BoJ publiée")
    return sorted(rows, key=lambda item: str(item["event_time"]))


def _observation(*, source: str, instrument: str, event_time: str, received: datetime,
                 rows: list[dict[str, object]], value: float, region: str,
                 dimension: str, url: str) -> Observation:
    """La disponibilité est l'heure de réception, jamais la date de période."""
    event = pd.Timestamp(event_time).to_pydatetime()
    return Observation(
        source=source, data_family="MACRO", asset="MACRO", instrument=instrument,
        event_time=event, exchange_time=event, received_time=received,
        available_time=received, ingestion_time=utc_now(),
        information_age_seconds=max(0.0, (received - event).total_seconds()),
        values={"value": value, "history_tail": rows, "dimension": dimension,
                "region": region, "unit": "pct" if dimension == "policy" else "pct_yoy"},
        metadata={"provider": source, "source_url": url, "vintage_safe": False,
                  "backtest_eligible": False, "available_from_receipt_only": True},
    )


class EcbM3Collector(BaseCollector):
    source = "ecb_data_portal"
    endpoint = "/service/data/BSI/M.U2.Y.V.M30.X.I.U2.2300.Z01.A"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        instrument = "ECB_M3_YOY"
        try:
            response = self.session.get(self.base_url + self.endpoint,
                                        params={"format": "csvdata", "lastNObservations": 24},
                                        timeout=self.timeout_seconds)
            response.raise_for_status()
            received = utc_now()
            if self.raw_store:
                self.raw_store.append(self.source, self.endpoint, response.text, received,
                                      {"status_code": response.status_code})
            rows = [row for row in parse_ecb_m3_csv(response.text)
                    if pd.Timestamp(row["event_time"]) <= received]
            if not rows:
                raise ValueError("Aucune période BCE non future")
            last = rows[-1]
            batch.observations.append(_observation(
                source=self.source, instrument=instrument, event_time=str(last["event_time"]),
                received=received, rows=rows, value=float(last["value"]), region="EURO_AREA",
                dimension="liquidity", url="https://data.ecb.europa.eu/data/datasets/BSI",
            ))
            batch.coverage[instrument] = True
        except Exception as exc:
            batch.errors.append(f"{instrument}: {exc}")
            batch.coverage[instrument] = False
        return batch


class BojOfficialCollector(BaseCollector):
    source = "boj_time_series"
    endpoint = "/api/v1/getDataCode"
    series = (("MD02", "MAM1YAM3M3MO", "MONTHLY", "BOJ_M3_YOY", "liquidity"),
              ("FM01", "STRDCLUCON", "DAILY", "BOJ_CALL_RATE", "policy"))

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for database, code, frequency, instrument, dimension in self.series:
            try:
                # L'API BoJ accepte un mois de départ pour la série mensuelle.
                params = {"format": "json", "lang": "en", "db": database, "code": code}
                if frequency == "MONTHLY":
                    params["startDate"] = "202301"
                payload, received = self.get_json(self.endpoint, params)
                rows = [row for row in parse_boj_series(payload, code=code, frequency=frequency)
                        if pd.Timestamp(row["event_time"]) <= received]
                if not rows:
                    raise ValueError("Aucune période BoJ non future")
                last = rows[-1]
                batch.observations.append(_observation(
                    source=self.source, instrument=instrument, event_time=str(last["event_time"]),
                    received=received, rows=rows[-800:], value=float(last["value"]), region="JAPAN",
                    dimension=dimension, url="https://www.stat-search.boj.or.jp/index_en.html",
                ))
                batch.coverage[instrument] = True
            except Exception as exc:
                batch.errors.append(f"{instrument}: {exc}")
                batch.coverage[instrument] = False
        return batch
