from __future__ import annotations

import math
from typing import Any

import pandas as pd

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


def parse_eurostat_inflation(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Read published annual rates, including flagged flash estimates, not an index YoY."""
    if payload.get("id") != ["freq", "unit", "coicop18", "geo", "time"]:
        raise ValueError("unexpected Eurostat dimensions")
    if payload.get("size", [])[:4] != [1, 1, 1, 1]:
        raise ValueError("Eurostat response is not one inflation series")
    dimensions = payload["dimension"]
    for name, expected in (("freq", "M"), ("unit", "RCH_A"), ("coicop18", "TOTAL"), ("geo", "EA")):
        if dimensions[name]["category"]["index"] != {expected: 0}:
            raise ValueError(f"unexpected Eurostat {name}")
    values, status = payload.get("value", {}), payload.get("status", {})
    rows = []
    for period, index in dimensions["time"]["category"]["index"].items():
        value = values.get(str(index)) if isinstance(values, dict) else values[index]
        if value is None or not math.isfinite(float(value)):
            continue
        flag = status.get(str(index), "") if isinstance(status, dict) else status[index]
        rows.append({"event_time": pd.Timestamp(period, tz="UTC").isoformat(), "value": float(value), "status": flag or ""})
    if not rows:
        raise ValueError("no published Eurostat inflation values")
    return sorted(rows, key=lambda item: item["event_time"])


class EurostatInflationCollector(BaseCollector):
    source = "eurostat_inflation"
    instrument = "EURO_AREA_HICP_YOY"
    endpoint = "/eurostat/api/dissemination/statistics/1.0/data/prc_hicp_minr"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self.get_json(self.endpoint, {
                "lang": "EN", "freq": "M", "unit": "RCH_A", "coicop18": "TOTAL",
                "geo": "EA", "lastTimePeriod": 24,
            })
            rows = parse_eurostat_inflation(payload)
            rows = [row for row in rows if pd.Timestamp(row["event_time"]) <= received]
            if not rows:
                raise ValueError("Eurostat has no non-future observation")
            latest = rows[-1]
            event = pd.Timestamp(latest["event_time"]).to_pydatetime()
            updated = pd.to_datetime(payload.get("updated"), utc=True, errors="coerce")
            updated_iso = updated.isoformat() if pd.notna(updated) else None
            batch.observations.append(Observation(
                source=self.source, data_family="MACRO", asset="MACRO", instrument=self.instrument,
                event_time=event, exchange_time=updated.to_pydatetime() if pd.notna(updated) else received,
                received_time=received, available_time=received, ingestion_time=utc_now(),
                information_age_seconds=max(0.0, (received - event).total_seconds()),
                transformation_version="eurostat-hicp-rate-v1",
                values={"value": latest["value"], "dimension": "inflation", "region": "EURO_AREA",
                        "central_bank": "ECB", "role": "inflation_yoy", "unit": "pct_yoy",
                        "label": "IPCH zone euro (composition évolutive)", "history_tail": rows,
                        "release_status": "FLASH_ESTIMATE" if "e" in latest["status"] else "PROVISIONAL" if "p" in latest["status"] else "PUBLISHED",
                        "source_status": latest["status"], "source_updated_time": updated_iso},
                metadata={"provider": "Eurostat", "vintage_safe": False, "backtest_eligible": False,
                          "available_from_receipt_only": True, "publication_time_observed": False,
                          "source_updated_is_publication_time": False,
                          "source_url": "https://ec.europa.eu/eurostat/databrowser/view/prc_hicp_minr/default/table?lang=en"},
            ))
            batch.coverage[self.instrument] = True
        except Exception as exc:
            batch.errors.append(f"{self.instrument}: {exc}")
            batch.coverage[self.instrument] = False
        return batch
