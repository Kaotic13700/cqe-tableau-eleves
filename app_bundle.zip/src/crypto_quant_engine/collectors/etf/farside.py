from __future__ import annotations

import random
import time
from datetime import datetime, time as datetime_time, timezone
from html.parser import HTMLParser
from typing import Any

import requests

from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch, CollectorError


class _EtfTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_table = False
        self.in_cell = False
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if tag == "table" and "etf" in str(attributes.get("class", "")).split():
            self.in_table = True
        elif self.in_table and tag == "tr":
            if self._row is None or not self._row:
                self._row = []
        elif self.in_table and tag in {"td", "th"}:
            self.in_cell = True
            self._cell = []

    def handle_data(self, data: str) -> None:
        if self.in_table and self.in_cell:
            self._cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        if self.in_table and tag in {"td", "th"} and self._row is not None:
            self._row.append(" ".join("".join(self._cell).split()))
            self.in_cell = False
        elif self.in_table and tag == "tr" and self._row:
            self.rows.append(self._row)
            self._row = None
        elif self.in_table and tag == "table":
            self.in_table = False


def _amount_usd_millions(text: str) -> float | None:
    value = text.strip().replace(",", "").replace("$", "")
    if value in {"", "-", "—", "–"}:
        return None
    negative = value.startswith("(") and value.endswith(")")
    if negative:
        value = value[1:-1]
    try:
        amount = float(value)
    except ValueError:
        return None
    return -amount if negative else amount


def parse_farside_etf_html(html: str) -> list[dict[str, Any]]:
    parser = _EtfTableParser()
    parser.feed(html)
    if not parser.rows:
        return []
    header = parser.rows[0]
    data_start = 1
    if "Date" not in header or "Total" not in header:
        # The Ethereum table uses a two-line header: provider names first,
        # tickers second, with intentionally blank Date/Total cells.
        parent_index = next(
            (index for index, row in enumerate(parser.rows[:4]) if "Total" in row),
            None,
        )
        if parent_index is None:
            return []
        parent = parser.rows[parent_index]
        secondary = parser.rows[parent_index + 1] if parent_index + 1 < len(parser.rows) else []
        if len(secondary) != len(parent):
            return []
        header = [
            "Date" if index == 0 else "Total" if index == len(parent) - 1 else secondary[index] or parent[index]
            for index in range(len(parent))
        ]
        data_start = parent_index + 2
    date_index = header.index("Date")
    total_index = header.index("Total")
    output: list[dict[str, Any]] = []
    for cells in parser.rows[data_start:]:
        if len(cells) <= max(date_index, total_index):
            continue
        try:
            trading_date = datetime.strptime(cells[date_index], "%d %b %Y").date()
        except ValueError:
            continue
        total = _amount_usd_millions(cells[total_index])
        if total is None:
            continue
        funds = {
            name: _amount_usd_millions(cells[index])
            for index, name in enumerate(header)
            if index < len(cells) and name not in {"Date", "Total"}
        }
        # Farside can expose the current trading date before any fund has
        # published a number, with an aggregate placeholder equal to zero.
        # It is unknown rather than a confirmed zero flow.
        if not any(value is not None for value in funds.values()):
            continue
        output.append({"trading_date": trading_date, "daily_net_flow_usd": total * 1_000_000, "funds": funds})
    return sorted(output, key=lambda row: row["trading_date"])


class FarsideEtfFlowCollector(BaseCollector):
    """Public daily aggregate used only from receipt time, never as vintage-safe history."""

    source = "farside_etf_flows_public"
    endpoints = {
        "BTC": "/bitcoin-etf-flow-all-data/",
        "ETH": "/ethereum-etf-flow-all-data/",
    }
    recent_history_rows = 35

    def _get_html(self, endpoint: str) -> tuple[str, datetime]:
        last_error: Exception | None = None
        for attempt in range(self.max_attempts):
            try:
                response = self.session.get(
                    self.base_url + endpoint,
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1"},
                )
                response.raise_for_status()
                received = utc_now()
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        endpoint,
                        response.text,
                        received,
                        {"status_code": response.status_code, "content_type": response.headers.get("Content-Type")},
                    )
                return response.text, received
            except requests.RequestException as exc:
                last_error = exc
                if attempt + 1 < self.max_attempts:
                    time.sleep(self.backoff_seconds * (2**attempt) * (1 + random.random() * 0.1))
        raise CollectorError(f"{self.source} failed after {self.max_attempts} attempts: {last_error}")

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset, endpoint in self.endpoints.items():
            try:
                html, received = self._get_html(endpoint)
                rows = parse_farside_etf_html(html)
                if not rows:
                    raise ValueError("no dated ETF flow row parsed")
                # A single daily row kept the 3/5/10-day dashboard fields empty.
                # The public table contains the recent history, so ingest it as
                # current-revision context.  Every row remains available only
                # from this receipt time and is excluded from historical tests.
                for item in rows[-self.recent_history_rows :]:
                    event_time = datetime.combine(item["trading_date"], datetime_time.min, tzinfo=timezone.utc)
                    batch.observations.append(Observation(
                        source=self.source,
                        data_family="ETF",
                        asset=asset,
                        instrument=f"US_SPOT_{asset}_ETF_AGGREGATE",
                        quote_currency="USD",
                        event_time=event_time,
                        exchange_time=event_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - event_time).total_seconds()),
                        values={
                            "trading_date": item["trading_date"].isoformat(),
                            "daily_net_flow_usd": item["daily_net_flow_usd"],
                            "fund_flows_usd_millions": item["funds"],
                        },
                        metadata={
                            "provider": "Farside Investors",
                            "publication_time_observed": False,
                            "available_from_receipt_only": True,
                            "vintage_safe": False,
                            "backtest_eligible": False,
                        },
                    ))
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
