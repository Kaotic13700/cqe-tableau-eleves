from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

from ...constants import ASSETS
from ...time import ensure_utc


@dataclass(frozen=True)
class PublishedEtfFlow:
    """Provider-neutral contract. Trading date is deliberately separate from publication time."""

    asset: str
    trading_date: date
    daily_net_flow_usd: float
    publication_time: datetime
    received_time: datetime
    source: str

    def __post_init__(self) -> None:
        if self.asset not in ASSETS:
            raise ValueError("ETF flow asset must be BTC or ETH")
        object.__setattr__(self, "publication_time", ensure_utc(self.publication_time))
        object.__setattr__(self, "received_time", ensure_utc(self.received_time))
        if self.received_time < self.publication_time:
            raise ValueError("received_time cannot precede publication_time")

    @property
    def available_time(self) -> datetime:
        return max(self.publication_time, self.received_time)

