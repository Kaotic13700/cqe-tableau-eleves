from __future__ import annotations

import logging
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import requests

from ..schema import Observation
from ..storage.raw import RawStore
from ..time import utc_now


class CollectorError(RuntimeError):
    pass


@dataclass
class CollectionBatch:
    observations: list[Observation] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    coverage: dict[str, bool] = field(default_factory=dict)

    @property
    def degraded(self) -> bool:
        return bool(self.errors) or not all(self.coverage.values())


class BaseCollector(ABC):
    source: str

    def __init__(
        self,
        base_url: str,
        raw_store: RawStore | None = None,
        timeout_seconds: float = 20,
        max_attempts: int = 3,
        backoff_seconds: float = 0.5,
        session: requests.Session | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.raw_store = raw_store
        self.timeout_seconds = timeout_seconds
        self.max_attempts = max_attempts
        self.backoff_seconds = backoff_seconds
        self.session = session or requests.Session()
        self.log = logging.getLogger(f"collector.{self.source}")

    def get_json(self, endpoint: str, params: dict[str, Any] | None = None) -> tuple[Any, Any]:
        last_error: Exception | None = None
        for attempt in range(self.max_attempts):
            try:
                response = self.session.get(
                    self.base_url + endpoint,
                    params=params,
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1"},
                )
                response.raise_for_status()
                received_time = utc_now()
                payload = response.json()
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        endpoint,
                        payload,
                        received_time,
                        {"params": params or {}, "status_code": response.status_code},
                    )
                return payload, received_time
            except (requests.RequestException, ValueError) as exc:
                last_error = exc
                self.log.warning("attempt %s failed for %s: %s", attempt + 1, endpoint, exc)
                if attempt + 1 < self.max_attempts:
                    delay = self.backoff_seconds * (2**attempt) * (1 + random.random() * 0.1)
                    time.sleep(delay)
        raise CollectorError(f"{self.source} failed after {self.max_attempts} attempts: {last_error}")

    @abstractmethod
    def collect(self) -> CollectionBatch:
        raise NotImplementedError

