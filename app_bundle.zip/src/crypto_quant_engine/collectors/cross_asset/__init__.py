from .interface import CrossAssetObservation

__all__ = ["CrossAssetObservation"]

