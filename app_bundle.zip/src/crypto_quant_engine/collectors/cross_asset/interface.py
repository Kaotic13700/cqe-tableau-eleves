from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ...time import ensure_utc


@dataclass(frozen=True)
class CrossAssetObservation:
    instrument: str
    price: float
    available_time: datetime
    source: str
    unit: str
    market_open: bool

    def __post_init__(self) -> None:
        object.__setattr__(self, "available_time", ensure_utc(self.available_time))
        if self.price <= 0:
            raise ValueError("cross-asset price must be positive")

