from __future__ import annotations

from typing import Any

from ...constants import ASSETS
from ...schema import Observation
from ...storage.normalized import NormalizedStore
from ...time import milliseconds_to_utc, utc_now
from ..base import BaseCollector, CollectionBatch
from ..binance_trades import (
    BINANCE_CURSOR_TRANSFORMATION_VERSION,
    fetch_incremental_aggregate_trades,
)


class BinancePerpetualCollector(BaseCollector):
    source = "binance_futures"

    def __init__(
        self,
        *args: Any,
        normalized_store: NormalizedStore | None = None,
        max_trade_pages: int = 20,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.normalized_store = normalized_store
        self.max_trade_pages = max_trade_pages

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            symbol = f"{asset}USDT"
            try:
                premium, premium_received = self.get_json("/fapi/v1/premiumIndex", {"symbol": symbol})
                oi, oi_received = self.get_json("/fapi/v1/openInterest", {"symbol": symbol})
                previous = (
                    self.normalized_store.latest_payload(
                        source=self.source,
                        data_family="PERPS",
                        asset=asset,
                        instrument=symbol,
                        transformation_version=BINANCE_CURSOR_TRANSFORMATION_VERSION,
                    )
                    if self.normalized_store is not None
                    else None
                )
                previous_id = (
                    previous.get("values", {}).get("last_aggregate_trade_id") if previous is not None else None
                )
                trade_window = fetch_incremental_aggregate_trades(
                    self.get_json,
                    endpoint="/fapi/v1/aggTrades",
                    symbol=symbol,
                    previous_trade_id=int(previous_id) if previous_id is not None else None,
                    max_pages=self.max_trade_pages,
                )
                trades = trade_window.trades
                received = max(premium_received, oi_received, trade_window.received_time)
                trade_times = [milliseconds_to_utc(item["T"]) for item in trades]
                exchange_time = max(
                    milliseconds_to_utc(premium["time"]),
                    milliseconds_to_utc(oi["time"]),
                    max(trade_times, default=received),
                )
                last_trade_time = max(trade_times, default=received)
                interval_start = (
                    previous["exchange_time"]
                    if previous is not None
                    else (min(trade_times) if trade_times else last_trade_time)
                )
                trade_interval_seconds = max(0.0, (last_trade_time - interval_start).total_seconds())
                trade_window_over_30m = trade_interval_seconds > 1_800
                previous_cursor_complete = bool(
                    previous is not None
                    and previous.get("values", {}).get("trade_cursor_complete", False)
                )
                trade_flow_interval_eligible = (
                    trade_window.flow_is_deduplicated
                    and not trade_window.cursor_initial_window
                    and previous_cursor_complete
                    and not trade_window_over_30m
                )
                mark_price = float(premium["markPrice"])
                index_price = float(premium["indexPrice"])
                oi_base = float(oi["openInterest"])
                aggressive_buy = sum(float(item["q"]) for item in trades if not bool(item["m"]))
                aggressive_sell = sum(float(item["q"]) for item in trades if bool(item["m"]))
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="PERPS",
                        asset=asset,
                        instrument=symbol,
                        quote_currency="USDT",
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "perpetual_price": mark_price,
                            "index_price": index_price,
                            "basis_fraction": mark_price / index_price - 1 if index_price else None,
                            "funding_rate": float(premium["lastFundingRate"]),
                            "predicted_funding_rate": None,
                            "open_interest_base": oi_base,
                            "open_interest_notional_usd": oi_base * mark_price,
                            "aggressive_buy_volume_base": aggressive_buy,
                            "aggressive_sell_volume_base": aggressive_sell,
                            "volume_base": aggressive_buy + aggressive_sell,
                            "last_aggregate_trade_id": trade_window.committed_trade_id,
                            "observed_last_aggregate_trade_id": trade_window.observed_last_trade_id,
                            "trade_flow_deduplicated": trade_window.flow_is_deduplicated,
                            "trade_flow_interval_eligible": trade_flow_interval_eligible,
                            "trade_flow_interval_seconds": trade_interval_seconds,
                            "trade_flow_window_over_30m": trade_window_over_30m,
                            "trade_gap_detected": trade_window.gap_detected,
                            "trade_cursor_complete": trade_window.cursor_complete,
                            "trade_cursor_page_limit_hit": trade_window.page_limit_hit,
                            "long_liquidations_notional_usd": None,
                            "short_liquidations_notional_usd": None,
                        },
                        metadata={
                            "aggressor_convention": "aggTrades.m=false => buyer taker; m=true => seller taker",
                            "liquidations": "not collected: public force-order endpoint requires authentication",
                            "trade_cursor_initial_window": trade_window.cursor_initial_window,
                            "trade_cursor_previous_id": trade_window.previous_trade_id,
                            "trade_cursor_pages": trade_window.page_count,
                            "trade_flow_scope": "incremental_trade_ids_since_last_committed_observation",
                        },
                        transformation_version=BINANCE_CURSOR_TRANSFORMATION_VERSION,
                    )
                )
                batch.coverage[asset] = True
                if not trade_window.flow_is_deduplicated:
                    progress = (
                        "cursor advanced through a contiguous prefix for bounded catch-up"
                        if trade_window.cursor_progress_is_safe
                        else "cursor not advanced"
                    )
                    batch.errors.append(
                        f"{asset}: aggregate-trade cursor incomplete; flow excluded and {progress}"
                    )
                elif trade_window_over_30m:
                    batch.errors.append(
                        f"{asset}: aggregate-trade interval exceeds 30 minutes; flow captured but excluded"
                    )
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
