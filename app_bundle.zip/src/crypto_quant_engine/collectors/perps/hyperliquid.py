from __future__ import annotations

import random
import time
from typing import Any

import requests

from ...constants import ASSETS
from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch, CollectorError


def parse_hyperliquid_meta_contexts(payload: Any, received_time: Any) -> list[Observation]:
    """Parse the public perp snapshot without inventing an exchange timestamp.

    Hyperliquid's ``metaAndAssetCtxs`` response is ordered: each context matches
    the coin at the same position in ``universe``.  The response does not expose
    a snapshot timestamp, so receipt time is conservatively used for every
    temporal field and the limitation is explicit in metadata.
    """

    if not isinstance(payload, list) or len(payload) != 2:
        raise ValueError("unexpected Hyperliquid metaAndAssetCtxs response")
    meta, contexts = payload
    universe = meta.get("universe", []) if isinstance(meta, dict) else []
    if not isinstance(universe, list) or not isinstance(contexts, list) or len(universe) != len(contexts):
        raise ValueError("Hyperliquid universe/context length mismatch")

    observations: list[Observation] = []
    for instrument, context in zip(universe, contexts, strict=True):
        asset = str(instrument.get("name", "")).upper() if isinstance(instrument, dict) else ""
        if asset not in ASSETS or not isinstance(context, dict):
            continue
        mark_price = float(context["markPx"])
        oracle_price = float(context["oraclePx"])
        open_interest_base = float(context["openInterest"])
        volume_24h_usd = float(context.get("dayNtlVlm") or 0.0)
        observations.append(
            Observation(
                source="hyperliquid_perps",
                data_family="PERPS",
                asset=asset,
                instrument=f"{asset}-PERP",
                quote_currency="USD",
                event_time=received_time,
                exchange_time=received_time,
                received_time=received_time,
                available_time=received_time,
                ingestion_time=utc_now(),
                information_age_seconds=0.0,
                values={
                    "perpetual_price": mark_price,
                    "index_price": oracle_price,
                    "basis_fraction": mark_price / oracle_price - 1.0 if oracle_price else None,
                    "funding_rate": float(context["funding"]),
                    "predicted_funding_rate": None,
                    "open_interest_base": open_interest_base,
                    "open_interest_notional_usd": open_interest_base * mark_price,
                    "volume_24h_usd": volume_24h_usd,
                    # The public snapshot has no taker-side split.  A null is
                    # materially different from a fabricated zero.
                    "aggressive_buy_volume_base": None,
                    "aggressive_sell_volume_base": None,
                    "volume_base": None,
                    "long_liquidations_notional_usd": None,
                    "short_liquidations_notional_usd": None,
                },
                metadata={
                    "provider": "Hyperliquid",
                    "venue_type": "DEX",
                    "api_method": "metaAndAssetCtxs",
                    "exchange_timestamp_observed": False,
                    "timestamp_policy": "receipt_time_used_for_snapshot_without_exchange_timestamp",
                    "backtest_eligible": False,
                },
            )
        )
    return observations


class HyperliquidPerpetualCollector(BaseCollector):
    source = "hyperliquid_perps"

    def _post_info(self) -> tuple[Any, Any]:
        last_error: Exception | None = None
        request_payload = {"type": "metaAndAssetCtxs"}
        for attempt in range(self.max_attempts):
            try:
                response = self.session.post(
                    self.base_url + "/info",
                    json=request_payload,
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1", "Content-Type": "application/json"},
                )
                response.raise_for_status()
                received = utc_now()
                payload = response.json()
                if self.raw_store:
                    self.raw_store.append(
                        self.source,
                        "/info",
                        payload,
                        received,
                        {"request": request_payload, "status_code": response.status_code},
                    )
                return payload, received
            except (requests.RequestException, ValueError) as exc:
                last_error = exc
                if attempt + 1 < self.max_attempts:
                    time.sleep(self.backoff_seconds * (2**attempt) * (1 + random.random() * 0.1))
        raise CollectorError(f"{self.source} failed after {self.max_attempts} attempts: {last_error}")

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        try:
            payload, received = self._post_info()
            batch.observations.extend(parse_hyperliquid_meta_contexts(payload, received))
            for asset in ASSETS:
                batch.coverage[asset] = any(item.asset == asset for item in batch.observations)
                if not batch.coverage[asset]:
                    batch.errors.append(f"{asset}: missing from Hyperliquid public universe")
        except Exception as exc:
            batch.errors.append(str(exc))
            batch.coverage.update({asset: False for asset in ASSETS})
        return batch
