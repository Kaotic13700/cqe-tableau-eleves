from __future__ import annotations

from typing import Any
from datetime import timedelta
import math

from ...constants import ASSETS
from ...schema import Observation
from ...time import milliseconds_to_utc, utc_now
from ..base import BaseCollector, CollectionBatch


def closed_taker_interval(payload: Any, received: Any) -> dict[str, Any]:
    """Use only the immediately preceding closed 15m bar, in base currency.

    OKX returns [timestamp, sellVol, buyVol] with unit=0 (crypto).
    Conservatively allow availability only after timestamp + 15 minutes;
    HTTP receipt remains the actual available_time, never the bar timestamp.
    Requiring the preceding bar prevents stale intervals being counted again
    in subsequent collection buckets. Duplicate/conflicting bars fail closed.
    """
    if not isinstance(payload, dict) or str(payload.get("code")) != "0":
        raise ValueError("OKX taker volume response failed")
    boundary = received.replace(minute=received.minute // 15 * 15, second=0, microsecond=0)
    start = boundary - timedelta(minutes=15)
    matches = [row for row in payload.get("data", [])
               if isinstance(row, list) and len(row) == 3
               and milliseconds_to_utc(row[0]) == start]
    if len(matches) != 1:
        raise ValueError("OKX latest closed taker interval missing or duplicated")
    sell, buy = float(matches[0][1]), float(matches[0][2])
    if not all(math.isfinite(value) and value >= 0 for value in (sell, buy)):
        raise ValueError("OKX invalid taker volumes")
    return {
        "aggressive_buy_volume_base": buy,
        "aggressive_sell_volume_base": sell,
        "volume_base": buy + sell,
        "trade_flow_deduplicated": True,
        "trade_flow_interval_eligible": True,
        "trade_gap_detected": False,
        "trade_flow_interval_start": start.isoformat(),
        "trade_flow_interval_end": boundary.isoformat(),
    }


class OkxPerpetualCollector(BaseCollector):
    """Collect public OKX USDT-swap state as a CEX fallback to Binance."""

    source = "okx_perps"

    @staticmethod
    def _first(payload: Any, label: str) -> dict[str, Any]:
        if not isinstance(payload, dict) or str(payload.get("code")) != "0":
            raise ValueError(f"OKX {label} error: {payload}")
        data = payload.get("data")
        if not isinstance(data, list) or not data or not isinstance(data[0], dict):
            raise ValueError(f"OKX {label} response is empty")
        return data[0]

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            instrument = f"{asset}-USDT-SWAP"
            index_instrument = f"{asset}-USDT"
            try:
                ticker_payload, ticker_received = self.get_json(
                    "/api/v5/market/ticker", {"instId": instrument}
                )
                mark_payload, mark_received = self.get_json(
                    "/api/v5/public/mark-price", {"instType": "SWAP", "instId": instrument}
                )
                index_payload, index_received = self.get_json(
                    "/api/v5/market/index-tickers", {"instId": index_instrument}
                )
                oi_payload, oi_received = self.get_json(
                    "/api/v5/public/open-interest", {"instType": "SWAP", "instId": instrument}
                )
                funding_payload, funding_received = self.get_json(
                    "/api/v5/public/funding-rate", {"instId": instrument}
                )
                ticker = self._first(ticker_payload, "ticker")
                mark = self._first(mark_payload, "mark price")
                index = self._first(index_payload, "index ticker")
                oi = self._first(oi_payload, "open interest")
                funding = self._first(funding_payload, "funding rate")
                flow = {}
                flow_received = funding_received
                flow_limitation = ""
                try:
                    flow_payload, flow_received = self.get_json(
                        "/api/v5/rubik/stat/taker-volume-contract",
                        {"instId": instrument, "period": "15m", "unit": "0", "limit": "4"},
                    )
                    flow = closed_taker_interval(flow_payload, flow_received)
                except Exception as exc:
                    flow_limitation = str(exc)
                    batch.errors.append(f"{asset}: taker flow unavailable: {exc}")
                received = max(
                    ticker_received,
                    mark_received,
                    index_received,
                    oi_received,
                    funding_received,
                    flow_received,
                )
                source_times = [
                    milliseconds_to_utc(item["ts"])
                    for item in (ticker, mark, index, oi)
                    if item.get("ts") not in (None, "")
                ]
                exchange_time = max(source_times, default=received)
                mark_price = float(mark["markPx"])
                index_price = float(index["idxPx"])
                oi_base = float(oi.get("oiCcy") or 0.0)
                oi_notional = float(oi.get("oiUsd") or 0.0) or oi_base * mark_price
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="PERPS",
                        asset=asset,
                        instrument=instrument,
                        quote_currency="USDT",
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        transformation_version="okx-perps-closed-taker-v2",
                        values={
                            "perpetual_price": mark_price,
                            "last_trade_price": float(ticker["last"]),
                            "index_price": index_price,
                            "basis_fraction": mark_price / index_price - 1.0 if index_price else None,
                            "funding_rate": float(funding["fundingRate"]),
                            "predicted_funding_rate": (
                                float(funding["nextFundingRate"])
                                if funding.get("nextFundingRate") not in (None, "")
                                else None
                            ),
                            "open_interest_base": oi_base,
                            "open_interest_notional_usd": oi_notional,
                            "volume_24h_usd": float(ticker.get("volCcy24h") or 0.0) * mark_price,
                            "aggressive_buy_volume_base": None,
                            "aggressive_sell_volume_base": None,
                            "volume_base": None,
                            "trade_flow_deduplicated": False,
                            "trade_flow_interval_eligible": False,
                            "trade_gap_detected": False,
                            "long_liquidations_notional_usd": None,
                            "short_liquidations_notional_usd": None,
                            **flow,
                        },
                        metadata={
                            "provider": "OKX",
                            "venue_type": "CEX",
                            "api_scope": "public ticker/mark/index/open-interest/funding",
                            "exchange_timestamp_observed": True,
                            "funding_available_time_policy": "HTTP receipt time",
                            "flow_limitation": flow_limitation,
                            "flow_source": "OKX /api/v5/rubik/stat/taker-volume-contract",
                            "flow_unit": "base currency (unit=0)",
                            "flow_period": "15m closed; conservative timestamp+15m cutoff",
                            "backtest_eligible": False,
                        },
                    )
                )
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
