from __future__ import annotations

from typing import Any

from ...constants import ASSETS
from ...schema import Observation
from ...time import milliseconds_to_utc, utc_now
from ..base import BaseCollector, CollectionBatch


class OkxPerpetualCollector(BaseCollector):
    """Collect public OKX USDT-swap state as a CEX fallback to Binance."""

    source = "okx_perps"

    @staticmethod
    def _first(payload: Any, label: str) -> dict[str, Any]:
        if not isinstance(payload, dict) or str(payload.get("code")) != "0":
            raise ValueError(f"OKX {label} error: {payload}")
        data = payload.get("data")
        if not isinstance(data, list) or not data or not isinstance(data[0], dict):
            raise ValueError(f"OKX {label} response is empty")
        return data[0]

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            instrument = f"{asset}-USDT-SWAP"
            index_instrument = f"{asset}-USDT"
            try:
                ticker_payload, ticker_received = self.get_json(
                    "/api/v5/market/ticker", {"instId": instrument}
                )
                mark_payload, mark_received = self.get_json(
                    "/api/v5/public/mark-price", {"instType": "SWAP", "instId": instrument}
                )
                index_payload, index_received = self.get_json(
                    "/api/v5/market/index-tickers", {"instId": index_instrument}
                )
                oi_payload, oi_received = self.get_json(
                    "/api/v5/public/open-interest", {"instType": "SWAP", "instId": instrument}
                )
                funding_payload, funding_received = self.get_json(
                    "/api/v5/public/funding-rate", {"instId": instrument}
                )
                ticker = self._first(ticker_payload, "ticker")
                mark = self._first(mark_payload, "mark price")
                index = self._first(index_payload, "index ticker")
                oi = self._first(oi_payload, "open interest")
                funding = self._first(funding_payload, "funding rate")
                received = max(
                    ticker_received,
                    mark_received,
                    index_received,
                    oi_received,
                    funding_received,
                )
                source_times = [
                    milliseconds_to_utc(item["ts"])
                    for item in (ticker, mark, index, oi)
                    if item.get("ts") not in (None, "")
                ]
                exchange_time = max(source_times, default=received)
                mark_price = float(mark["markPx"])
                index_price = float(index["idxPx"])
                oi_base = float(oi.get("oiCcy") or 0.0)
                oi_notional = float(oi.get("oiUsd") or 0.0) or oi_base * mark_price
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="PERPS",
                        asset=asset,
                        instrument=instrument,
                        quote_currency="USDT",
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "perpetual_price": mark_price,
                            "last_trade_price": float(ticker["last"]),
                            "index_price": index_price,
                            "basis_fraction": mark_price / index_price - 1.0 if index_price else None,
                            "funding_rate": float(funding["fundingRate"]),
                            "predicted_funding_rate": (
                                float(funding["nextFundingRate"])
                                if funding.get("nextFundingRate") not in (None, "")
                                else None
                            ),
                            "open_interest_base": oi_base,
                            "open_interest_notional_usd": oi_notional,
                            "volume_24h_usd": float(ticker.get("volCcy24h") or 0.0) * mark_price,
                            "aggressive_buy_volume_base": None,
                            "aggressive_sell_volume_base": None,
                            "volume_base": None,
                            "trade_flow_deduplicated": False,
                            "trade_flow_interval_eligible": False,
                            "trade_gap_detected": False,
                            "long_liquidations_notional_usd": None,
                            "short_liquidations_notional_usd": None,
                        },
                        metadata={
                            "provider": "OKX",
                            "venue_type": "CEX",
                            "api_scope": "public ticker/mark/index/open-interest/funding",
                            "exchange_timestamp_observed": True,
                            "funding_available_time_policy": "HTTP receipt time",
                            "flow_limitation": "no complete deduplicated taker interval in this snapshot",
                            "backtest_eligible": False,
                        },
                    )
                )
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
