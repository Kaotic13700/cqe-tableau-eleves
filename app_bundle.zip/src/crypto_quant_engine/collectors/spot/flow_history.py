"""Public OKX taker statistics: current context, never backdated observations."""
from datetime import timedelta
import numpy as np
import pandas as pd

from ..base import BaseCollector, CollectionBatch
from ...schema import Observation
from ...time import utc_now


def summarize(payload, received):
    if payload.get("code") != "0":
        raise ValueError(f"OKX statistics: {payload.get('msg')}")
    frame = pd.DataFrame(payload.get("data", []), columns=["time", "sell", "buy"])
    if frame.empty:
        raise ValueError("No taker history")
    frame["time"] = pd.to_datetime(pd.to_numeric(frame["time"]), unit="ms", utc=True)
    for col in ("sell", "buy"):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame[np.isfinite(frame["sell"]) & np.isfinite(frame["buy"])
                  & frame["sell"].ge(0) & frame["buy"].ge(0)]
    # Conservatively wait a full period after the API timestamp.
    frame = frame[frame["time"] + pd.Timedelta(minutes=5) <= pd.Timestamp(received)]
    frame = frame.sort_values("time").drop_duplicates("time")
    frame["bucket"] = frame["time"].dt.floor("15min")
    bars = frame.groupby("bucket").agg(sell=("sell", "sum"), buy=("buy", "sum"), n=("time", "size"))
    bars = bars[bars.n.eq(3)]
    if bars.empty:
        raise ValueError("No complete 15-minute interval")
    end = bars.index[-1] + pd.Timedelta(minutes=15)
    if pd.Timestamp(received) - end > pd.Timedelta(minutes=30):
        raise ValueError("Stale taker history")
    # A gap is not an observation. Never compress time when standardizing.
    bars = bars.reindex(pd.date_range(bars.index.min(), bars.index.max(), freq="15min"))
    delta = bars.buy - bars.sell
    prior = delta.iloc[:-1].tail(96)
    std = prior.std(ddof=1)
    z = (delta.iloc[-1] - prior.mean()) / std if prior.count() >= 32 and std > 0 else None
    total = bars.buy.iloc[-1] + bars.sell.iloc[-1]
    return {"recovered_spot_imbalance": float(delta.iloc[-1] / total) if total > 0 else None,
            "recovered_spot_z": float(z) if z is not None else None,
            "spot_flow_context_source": "OKX · statistiques taker SPOT · intervalle clos 15 min",
            "spot_flow_context_end": end.isoformat(),
            "spot_flow_context_prior_count": int(prior.count())}, end.to_pydatetime()


class SpotFlowHistoryCollector(BaseCollector):
    source = "okx_spot_flow_history"

    def collect(self):
        batch = CollectionBatch()
        for asset in ("BTC", "ETH"):
            try:
                payload, received = self.get_json("/api/v5/rubik/stat/taker-volume", {
                    "ccy": asset, "instType": "SPOT", "period": "5m",
                    "begin": int((utc_now() - timedelta(hours=47)).timestamp() * 1000)})
                values, end = summarize(payload, received)
                batch.observations.append(Observation(
                    source=self.source, data_family="SPOT_FLOW_HISTORY", asset=asset,
                    instrument=f"{asset}-SPOT-TAKER-STATISTICS", event_time=end, exchange_time=end,
                    received_time=received, available_time=received, ingestion_time=utc_now(),
                    values=values, transformation_version="okx-closed-spot-context-v1",
                    metadata={"backtest_eligible": False, "period": "15min",
                              "timestamp_policy": "API timestamp plus full period; receipt availability"}))
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
