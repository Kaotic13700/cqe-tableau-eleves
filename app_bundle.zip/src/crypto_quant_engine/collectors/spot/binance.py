from __future__ import annotations

from typing import Any

from ...constants import ASSETS
from ...schema import Observation
from ...storage.normalized import NormalizedStore
from ...time import milliseconds_to_utc, utc_now
from ..base import BaseCollector, CollectionBatch
from ..binance_trades import (
    BINANCE_CURSOR_TRANSFORMATION_VERSION,
    fetch_incremental_aggregate_trades,
)


class BinanceSpotCollector(BaseCollector):
    source = "binance"

    def __init__(
        self,
        *args: Any,
        quote_currency: str = "USDT",
        depth_levels: int = 20,
        normalized_store: NormalizedStore | None = None,
        max_trade_pages: int = 20,
        hosted_book_only: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.quote_currency = quote_currency
        self.depth_levels = depth_levels
        self.normalized_store = normalized_store
        self.max_trade_pages = max_trade_pages
        self.hosted_book_only = hosted_book_only

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            symbol = f"{asset}{self.quote_currency}"
            try:
                book, book_received = self.get_json("/api/v3/depth", {"symbol": symbol, "limit": self.depth_levels})
                if self.hosted_book_only:
                    # Binance public quotes are reachable, but a high-volume
                    # aggregate-trade catch-up cannot fit the hosted budget.
                    # Never interpret a partial cursor as buy/sell flow.
                    best_bid = float(book["bids"][0][0]) if book.get("bids") else None
                    best_ask = float(book["asks"][0][0]) if book.get("asks") else None
                    mid = (best_bid + best_ask) / 2 if best_bid is not None and best_ask is not None else None
                    if mid is None:
                        raise ValueError("Binance public order book has no two-sided quote")
                    latest_trades, trade_received = self.get_json("/api/v3/trades", {"symbol": symbol, "limit": 1})
                    if not latest_trades or "time" not in latest_trades[-1]:
                        raise ValueError("Binance recent trade lacks an exchange timestamp")
                    exchange_time = milliseconds_to_utc(latest_trades[-1]["time"])
                    received = max(book_received, trade_received)
                    batch.observations.append(Observation(
                        source=self.source, data_family="SPOT", asset=asset, instrument=symbol,
                        quote_currency=self.quote_currency, event_time=exchange_time,
                        exchange_time=exchange_time, received_time=received,
                        available_time=received, ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={"price": float(latest_trades[-1]["price"]), "best_bid": best_bid, "best_ask": best_ask,
                                "mid_price": mid, "spread": best_ask - best_bid,
                                "bid_depth_notional": sum(float(p) * float(q) for p, q in book.get("bids", [])),
                                "ask_depth_notional": sum(float(p) * float(q) for p, q in book.get("asks", [])),
                                "depth_levels": self.depth_levels, "trade_flow_interval_eligible": False},
                        metadata={"price_scope": "last_public_trade", "trade_flow_scope": "not_collected_on_hosted_runtime",
                                  "book_time_scope": "receipt_only"},
                        transformation_version="binance-hosted-quote-v1",
                    ))
                    batch.coverage[asset] = True
                    continue
                previous = (
                    self.normalized_store.latest_payload(
                        source=self.source,
                        data_family="SPOT",
                        asset=asset,
                        instrument=symbol,
                        transformation_version=BINANCE_CURSOR_TRANSFORMATION_VERSION,
                    )
                    if self.normalized_store is not None
                    else None
                )
                previous_id = (
                    previous.get("values", {}).get("last_aggregate_trade_id") if previous is not None else None
                )
                trade_window = fetch_incremental_aggregate_trades(
                    self.get_json,
                    endpoint="/api/v3/aggTrades",
                    symbol=symbol,
                    previous_trade_id=int(previous_id) if previous_id is not None else None,
                    max_pages=self.max_trade_pages,
                )
                trades = trade_window.trades
                received = max(book_received, trade_window.received_time)
                trade_times = [milliseconds_to_utc(item["T"]) for item in trades]
                exchange_time = max(
                    trade_times,
                    default=received,
                )
                interval_start = (
                    previous["exchange_time"]
                    if previous is not None
                    else (min(trade_times) if trade_times else exchange_time)
                )
                trade_interval_seconds = max(0.0, (exchange_time - interval_start).total_seconds())
                trade_window_over_30m = trade_interval_seconds > 1_800
                previous_cursor_complete = bool(
                    previous is not None
                    and previous.get("values", {}).get("trade_cursor_complete", False)
                )
                trade_flow_interval_eligible = (
                    trade_window.flow_is_deduplicated
                    and not trade_window.cursor_initial_window
                    and previous_cursor_complete
                    and not trade_window_over_30m
                )
                aggressive_buy = sum(float(item["q"]) for item in trades if not bool(item["m"]))
                aggressive_sell = sum(float(item["q"]) for item in trades if bool(item["m"]))
                bid_depth = sum(float(price) * float(quantity) for price, quantity in book.get("bids", []))
                ask_depth = sum(float(price) * float(quantity) for price, quantity in book.get("asks", []))
                best_bid = float(book["bids"][0][0]) if book.get("bids") else None
                best_ask = float(book["asks"][0][0]) if book.get("asks") else None
                mid = (best_bid + best_ask) / 2 if best_bid is not None and best_ask is not None else None
                ingestion = utc_now()
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="SPOT",
                        asset=asset,
                        instrument=symbol,
                        quote_currency=self.quote_currency,
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=ingestion,
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "price": float(trades[-1]["p"]) if trades else mid,
                            "best_bid": best_bid,
                            "best_ask": best_ask,
                            "mid_price": mid,
                            "spread": best_ask - best_bid if mid is not None else None,
                            "trade_volume_base": aggressive_buy + aggressive_sell,
                            "aggressive_buy_volume_base": aggressive_buy,
                            "aggressive_sell_volume_base": aggressive_sell,
                            "trade_count": len(trades),
                            "last_aggregate_trade_id": trade_window.committed_trade_id,
                            "observed_last_aggregate_trade_id": trade_window.observed_last_trade_id,
                            "trade_flow_deduplicated": trade_window.flow_is_deduplicated,
                            "trade_flow_interval_eligible": trade_flow_interval_eligible,
                            "trade_flow_interval_seconds": trade_interval_seconds,
                            "trade_flow_window_over_30m": trade_window_over_30m,
                            "trade_gap_detected": trade_window.gap_detected,
                            "trade_cursor_complete": trade_window.cursor_complete,
                            "trade_cursor_page_limit_hit": trade_window.page_limit_hit,
                            "bid_depth_notional": bid_depth,
                            "ask_depth_notional": ask_depth,
                            "depth_levels": self.depth_levels,
                        },
                        metadata={
                            "aggressor_convention": "aggTrades.m=false => buyer taker; m=true => seller taker",
                            "depth_scope": f"top_{self.depth_levels}_levels",
                            "trade_cursor_initial_window": trade_window.cursor_initial_window,
                            "trade_cursor_previous_id": trade_window.previous_trade_id,
                            "trade_cursor_pages": trade_window.page_count,
                            "trade_flow_scope": "incremental_trade_ids_since_last_committed_observation",
                        },
                        transformation_version=BINANCE_CURSOR_TRANSFORMATION_VERSION,
                    )
                )
                batch.coverage[asset] = True
                if not trade_window.flow_is_deduplicated:
                    progress = (
                        "cursor advanced through a contiguous prefix for bounded catch-up"
                        if trade_window.cursor_progress_is_safe
                        else "cursor not advanced"
                    )
                    batch.errors.append(
                        f"{asset}: aggregate-trade cursor incomplete; flow excluded and {progress}"
                    )
                elif trade_window_over_30m:
                    batch.errors.append(
                        f"{asset}: aggregate-trade interval exceeds 30 minutes; flow captured but excluded"
                    )
            except Exception as exc:  # collector isolation is intentional
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
