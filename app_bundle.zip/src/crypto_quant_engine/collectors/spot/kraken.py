from __future__ import annotations

from typing import Any

import pandas as pd

from ...constants import ASSETS
from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


class KrakenSpotCollector(BaseCollector):
    source = "kraken"
    pairs = {"BTC": "XBTUSD", "ETH": "ETHUSD"}

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset, pair in self.pairs.items():
            try:
                book_payload, book_received = self.get_json("/0/public/Depth", {"pair": pair, "count": 25})
                trade_payload, trade_received = self.get_json("/0/public/Trades", {"pair": pair})
                if book_payload.get("error") or trade_payload.get("error"):
                    raise ValueError(f"Kraken error: {book_payload.get('error')} {trade_payload.get('error')}")
                book = next(iter(book_payload["result"].values()))
                trade_key = next(key for key in trade_payload["result"] if key != "last")
                trades = trade_payload["result"][trade_key]
                received = max(book_received, trade_received)
                exchange_time = max(
                    [pd.Timestamp(float(item[2]), unit="s", tz="UTC").to_pydatetime(warn=False) for item in trades],
                    default=received,
                )
                # Kraken side `b`/`s` is taker side.
                aggressive_buy = sum(float(item[1]) for item in trades if item[3] == "b")
                aggressive_sell = sum(float(item[1]) for item in trades if item[3] == "s")
                bids, asks = book.get("bids", []), book.get("asks", [])
                best_bid = float(bids[0][0]) if bids else None
                best_ask = float(asks[0][0]) if asks else None
                mid = (best_bid + best_ask) / 2 if best_bid is not None and best_ask is not None else None
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="SPOT",
                        asset=asset,
                        instrument=pair,
                        quote_currency="USD",
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "price": float(trades[-1][0]) if trades else mid,
                            "best_bid": best_bid,
                            "best_ask": best_ask,
                            "mid_price": mid,
                            "spread": best_ask - best_bid if mid is not None else None,
                            "trade_volume_base": aggressive_buy + aggressive_sell,
                            "aggressive_buy_volume_base": aggressive_buy,
                            "aggressive_sell_volume_base": aggressive_sell,
                            "trade_count": len(trades),
                            "bid_depth_notional": sum(float(row[0]) * float(row[1]) for row in bids),
                            "ask_depth_notional": sum(float(row[0]) * float(row[1]) for row in asks),
                        },
                        metadata={"aggressor_convention": "Trades side b/s is taker side"},
                    )
                )
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
