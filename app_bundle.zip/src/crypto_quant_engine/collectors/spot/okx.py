from __future__ import annotations

from typing import Any

from ...constants import ASSETS
from ...schema import Observation
from ...time import milliseconds_to_utc, utc_now
from ..base import BaseCollector, CollectionBatch


class OkxSpotCollector(BaseCollector):
    source = "okx"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            instrument = f"{asset}-USDT"
            try:
                book_payload, book_received = self.get_json("/api/v5/market/books", {"instId": instrument, "sz": 20})
                trade_payload, trade_received = self.get_json("/api/v5/market/trades", {"instId": instrument, "limit": 100})
                book = book_payload["data"][0]
                trades = trade_payload["data"]
                received = max(book_received, trade_received)
                exchange_time = max(
                    [milliseconds_to_utc(item["ts"]) for item in trades],
                    default=milliseconds_to_utc(book["ts"]),
                )
                aggressive_buy = sum(float(item["sz"]) for item in trades if item["side"] == "buy")
                aggressive_sell = sum(float(item["sz"]) for item in trades if item["side"] == "sell")
                bids, asks = book.get("bids", []), book.get("asks", [])
                best_bid = float(bids[0][0]) if bids else None
                best_ask = float(asks[0][0]) if asks else None
                mid = (best_bid + best_ask) / 2 if best_bid is not None and best_ask is not None else None
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="SPOT",
                        asset=asset,
                        instrument=instrument,
                        quote_currency="USDT",
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "price": float(trades[0]["px"]) if trades else mid,
                            "best_bid": best_bid,
                            "best_ask": best_ask,
                            "mid_price": mid,
                            "spread": best_ask - best_bid if mid is not None else None,
                            "trade_volume_base": aggressive_buy + aggressive_sell,
                            "aggressive_buy_volume_base": aggressive_buy,
                            "aggressive_sell_volume_base": aggressive_sell,
                            "trade_count": len(trades),
                            "bid_depth_notional": sum(float(row[0]) * float(row[1]) for row in bids),
                            "ask_depth_notional": sum(float(row[0]) * float(row[1]) for row in asks),
                        },
                        metadata={"aggressor_convention": "market trades side is taker side"},
                    )
                )
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch

