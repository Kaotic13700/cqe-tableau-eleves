from __future__ import annotations

from typing import Any

import pandas as pd

from ...constants import ASSETS
from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


class CoinbaseSpotCollector(BaseCollector):
    source = "coinbase"

    def __init__(self, *args: Any, quote_currency: str = "USD", **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.quote_currency = quote_currency

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            product = f"{asset}-{self.quote_currency}"
            try:
                book, book_received = self.get_json(f"/products/{product}/book", {"level": 2})
                trades, trades_received = self.get_json(f"/products/{product}/trades", {"limit": 1000})
                received = max(book_received, trades_received)
                times = [pd.Timestamp(item["time"]).to_pydatetime() for item in trades if item.get("time")]
                exchange_time = max(times, default=received)
                # Coinbase `side` is the maker side. A sell maker implies an aggressive buy.
                aggressive_buy = sum(float(item["size"]) for item in trades if item.get("side") == "sell")
                aggressive_sell = sum(float(item["size"]) for item in trades if item.get("side") == "buy")
                bids = book.get("bids", [])
                asks = book.get("asks", [])
                best_bid = float(bids[0][0]) if bids else None
                best_ask = float(asks[0][0]) if asks else None
                mid = (best_bid + best_ask) / 2 if best_bid is not None and best_ask is not None else None
                bid_depth = sum(float(row[0]) * float(row[1]) for row in bids)
                ask_depth = sum(float(row[0]) * float(row[1]) for row in asks)
                batch.observations.append(
                    Observation(
                        source=self.source,
                        data_family="SPOT",
                        asset=asset,
                        instrument=product,
                        quote_currency=self.quote_currency,
                        event_time=exchange_time,
                        exchange_time=exchange_time,
                        received_time=received,
                        available_time=received,
                        ingestion_time=utc_now(),
                        information_age_seconds=max(0.0, (received - exchange_time).total_seconds()),
                        values={
                            "price": float(trades[0]["price"]) if trades else mid,
                            "best_bid": best_bid,
                            "best_ask": best_ask,
                            "mid_price": mid,
                            "spread": best_ask - best_bid if mid is not None else None,
                            "trade_volume_base": aggressive_buy + aggressive_sell,
                            "aggressive_buy_volume_base": aggressive_buy,
                            "aggressive_sell_volume_base": aggressive_sell,
                            "trade_count": len(trades),
                            "bid_depth_notional": bid_depth,
                            "ask_depth_notional": ask_depth,
                        },
                        metadata={"aggressor_convention": "trade.side is maker side"},
                    )
                )
                batch.coverage[asset] = True
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch

