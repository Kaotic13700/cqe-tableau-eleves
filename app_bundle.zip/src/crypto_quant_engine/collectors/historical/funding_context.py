"""Settled funding histories, retrieved now, never backdated into model history."""
import json
import math
import sqlite3
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests
import pandas as pd
from ..base import CollectionBatch
from ...schema import Observation

VENUES = ("bybit", "okx", "hyperliquid")


def parse_rows(venue, payload):
    if venue == "bybit":
        if payload.get("retCode") != 0:
            raise ValueError("Bybit funding response rejected")
        return [(int(x["fundingRateTimestamp"]), float(x["fundingRate"])) for x in payload["result"]["list"]]
    if venue == "okx":
        if payload.get("code") != "0":
            raise ValueError("OKX funding response rejected")
        return [(int(x["fundingTime"]), float(x["realizedRate"])) for x in payload["data"]]
    return [(int(x["time"]), float(x["fundingRate"])) for x in payload]


class FundingHistoryCollector:
    source = "settled_funding_history"

    def __init__(self, raw_store):
        self.raw_store = raw_store

    def _fetch(self, venue, asset):
        end = int(datetime.now(timezone.utc).timestamp()*1000)
        start = end - 32*86400000
        cursor = start if venue == "hyperliquid" else end
        points = {}
        for _ in range(12):
            if venue == "hyperliquid":
                url = "https://api.hyperliquid.xyz/info"
                response = requests.post(url, json={"type":"fundingHistory", "coin":asset,
                    "startTime":cursor,"endTime":end}, timeout=15)
            elif venue == "bybit":
                url = "https://api.bybit.com/v5/market/funding/history"
                response = requests.get(url, params={"category":"linear","symbol":asset+"USDT",
                    "startTime":start,"endTime":cursor,"limit":200}, timeout=15)
            else:
                url = "https://www.okx.com/api/v5/public/funding-rate-history"
                response = requests.get(url, params={"instId":asset+"-USDT-SWAP","after":cursor,"limit":100}, timeout=15)
            response.raise_for_status()
            received = datetime.now(timezone.utc)
            payload = response.json()
            self.raw_store.append(self.source+"_"+venue,url,payload,received,{"asset":asset})
            rows = parse_rows(venue,payload)
            if not rows:
                break
            old = len(points)
            points.update({t:r for t,r in rows if start <= t <= end and math.isfinite(r)})
            if venue == "hyperliquid":
                cursor = max(t for t,_ in rows)+1
                if cursor >= end or len(points)==old:
                    break
            else:
                cursor = min(t for t,_ in rows)-1
                if cursor <= start or len(points)==old:
                    break
        if len(points) < 2:
            raise ValueError(f"{venue}/{asset}: fewer than two funding settlements")
        now = datetime.now(timezone.utc)
        return Observation(source=self.source+"_"+venue, data_family="FUNDING_HISTORY",asset=asset,
            instrument=asset+"-PERP",event_time=datetime.fromtimestamp(max(points)/1000,timezone.utc),
            exchange_time=datetime.fromtimestamp(max(points)/1000,timezone.utc),received_time=now,
            available_time=now,ingestion_time=now,values={"settlements":sorted(points.items())},
            transformation_version="settled-funding-context-v1",
            metadata={"venue":venue,"backtest_eligible":False,"unit":"fraction per settlement",
                      "scope":"realized funding only; not historical basis or order book"})

    def collect(self):
        batch = CollectionBatch()
        with ThreadPoolExecutor(max_workers=3) as pool:
            jobs = {(v,a):pool.submit(self._fetch,v,a) for v in VENUES for a in ("BTC","ETH")}
            for (v,a), job in jobs.items():
                try:
                    batch.observations.append(job.result())
                except Exception as exc:
                    batch.errors.append(f"{v}/{a}: {exc}")
        return batch


def read_context(path, asset, cutoff):
    if not Path(path).exists() or pd.isna(pd.to_datetime(cutoff,utc=True,errors="coerce")):
        return {}
    now = pd.Timestamp(cutoff)
    with sqlite3.connect(Path(path).resolve().as_uri()+"?mode=ro",uri=True,timeout=15) as db:
        rows = db.execute("SELECT source,available_time,values_json FROM observations WHERE data_family='FUNDING_HISTORY' AND asset=? AND julianday(available_time)<=julianday(?) ORDER BY available_time DESC LIMIT 100",(asset,str(now))).fetchall()
    result = {}
    for source,available,payload in rows:
        venue = source.removeprefix("settled_funding_history_")
        if venue not in result and now-pd.Timestamp(available)<=pd.Timedelta(hours=24):
            result[venue] = {"available_time":available,**json.loads(payload)}
    return result


def summarize(context, cutoff, days, venues):
    now = pd.Timestamp(cutoff)
    end = int(now.timestamp()*1000)
    start = end-int(days*86400000)
    summaries = []
    for venue in venues:
        item=context.get(venue)
        if not item or pd.Timestamp(item["available_time"])>now:
            continue
        points=sorted({int(t):float(r) for t,r in item["settlements"] if int(t)<=end and math.isfinite(float(r))}.items())
        rates=[]
        # Include the most recent settled interval when no settlement falls
        # inside a 4h window. Explicit actual dates prevent calling it 4h data.
        for (previous,_),(timestamp,rate) in zip(points,points[1:]):
            hours=(timestamp-previous)/3600000
            if 0<hours<=12 and (timestamp>=start or timestamp==points[-1][0]):
                rates.append((previous,timestamp,rate,hours))
        if not rates or end-rates[-1][1]>12*3600000:
            continue
        summaries.append({"venue":venue,"hourly_rate":sum(x[2] for x in rates)/sum(x[3] for x in rates),
                          "count":len(rates),"start":rates[0][0],"end":rates[-1][1]})
    return summaries
