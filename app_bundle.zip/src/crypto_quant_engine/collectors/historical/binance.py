from __future__ import annotations

import bisect
import logging
import random
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from typing import Any, Iterable

import requests

from ...schema import Observation
from ...storage import NormalizedStore, RawStore
from ...time import ensure_utc, milliseconds_to_utc, utc_now


INTERVAL_MILLISECONDS = 15 * 60 * 1000
TRANSFORMATION_VERSION = "binance-historical-klines-v1"


@dataclass(frozen=True)
class BackfillReport:
    asset: str
    data_family: str
    requested_start: str
    effective_start: str
    end: str
    pages: int
    received: int
    inserted: int
    duplicates: int
    status: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class BinanceHistoricalBackfill:
    """Resumable official Binance 15-minute spot/perpetual kline backfill.

    Historical observations keep the time at which the completed bar became
    public as ``available_time``. The later local download remains visible in
    ``received_time`` and ``ingestion_time``. Raw API pages are append-only.
    """

    def __init__(
        self,
        *,
        spot_base_url: str,
        futures_base_url: str,
        raw_store: RawStore,
        normalized_store: NormalizedStore,
        timeout_seconds: float = 30,
        max_attempts: int = 5,
        backoff_seconds: float = 0.75,
        request_pause_seconds: float = 0.03,
        session: requests.Session | None = None,
    ) -> None:
        self.spot_base_url = spot_base_url.rstrip("/")
        self.futures_base_url = futures_base_url.rstrip("/")
        self.raw_store = raw_store
        self.normalized_store = normalized_store
        self.timeout_seconds = timeout_seconds
        self.max_attempts = max_attempts
        self.backoff_seconds = backoff_seconds
        self.request_pause_seconds = request_pause_seconds
        self.session = session or requests.Session()
        self.log = logging.getLogger("collector.binance_historical")

    def _get_json(
        self,
        *,
        base_url: str,
        endpoint: str,
        params: dict[str, Any],
        raw_source: str,
    ) -> tuple[Any, datetime]:
        last_error: Exception | None = None
        for attempt in range(self.max_attempts):
            try:
                response = self.session.get(
                    base_url + endpoint,
                    params=params,
                    timeout=self.timeout_seconds,
                    headers={"User-Agent": "crypto-quant-engine/0.1 historical-research"},
                )
                response.raise_for_status()
                received = utc_now()
                payload = response.json()
                self.raw_store.append(
                    raw_source,
                    endpoint,
                    payload,
                    received,
                    {"params": params, "status_code": response.status_code, "base_url": base_url},
                )
                if self.request_pause_seconds:
                    time.sleep(self.request_pause_seconds)
                return payload, received
            except (requests.RequestException, ValueError) as exc:
                last_error = exc
                if attempt + 1 < self.max_attempts:
                    delay = self.backoff_seconds * (2**attempt) * (1 + random.random() * 0.1)
                    time.sleep(delay)
        raise RuntimeError(f"Binance historical request failed for {endpoint}: {last_error}")

    def _funding_history(self, asset: str, start: datetime, end: datetime) -> list[tuple[int, float]]:
        cursor = int(start.timestamp() * 1000)
        end_ms = int(end.timestamp() * 1000)
        rows: list[tuple[int, float]] = []
        while cursor < end_ms:
            payload, _ = self._get_json(
                base_url=self.futures_base_url,
                endpoint="/fapi/v1/fundingRate",
                params={"symbol": f"{asset}USDT", "startTime": cursor, "endTime": end_ms, "limit": 1000},
                raw_source="binance_futures_historical",
            )
            if not payload:
                break
            for item in payload:
                funding_time = int(item["fundingTime"])
                rows.append((funding_time, float(item["fundingRate"])))
            next_cursor = int(payload[-1]["fundingTime"]) + 1
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            if len(payload) < 1000:
                break
        return sorted(set(rows))

    @staticmethod
    def _latest_funding(
        funding_times: list[int], funding_values: list[float], available_time_ms: int
    ) -> float | None:
        position = bisect.bisect_right(funding_times, available_time_ms) - 1
        return funding_values[position] if position >= 0 else None

    @staticmethod
    def _observation_from_kline(
        *,
        row: list[Any],
        received_time: datetime,
        asset: str,
        data_family: str,
        funding_rate: float | None = None,
    ) -> Observation:
        close_time = milliseconds_to_utc(int(row[6]))
        available_time = close_time + timedelta(milliseconds=1)
        ingestion_time = utc_now()
        volume = float(row[5])
        taker_buy = float(row[9])
        common = {
            "open": float(row[1]),
            "high": float(row[2]),
            "low": float(row[3]),
            "close": float(row[4]),
            "volume_base": volume,
            "quote_volume": float(row[7]),
            "trade_count": int(row[8]),
            "aggressive_buy_volume_base": taker_buy,
            "aggressive_sell_volume_base": max(0.0, volume - taker_buy),
        }
        if data_family == "SPOT":
            source = "binance"
            values = {
                **common,
                "price": float(row[4]),
                "mid_price": float(row[4]),
                "trade_volume_base": volume,
                "best_bid": None,
                "best_ask": None,
                "spread": None,
                "bid_depth_notional": None,
                "ask_depth_notional": None,
            }
        else:
            source = "binance_futures"
            values = {
                **common,
                "perpetual_price": float(row[4]),
                "index_price": None,
                "basis_fraction": None,
                "funding_rate": funding_rate,
                "predicted_funding_rate": None,
                "open_interest_base": None,
                "open_interest_notional_usd": None,
                "long_liquidations_notional_usd": None,
                "short_liquidations_notional_usd": None,
            }
        return Observation(
            source=source,
            data_family=data_family,
            asset=asset,
            instrument=f"{asset}USDT",
            quote_currency="USDT",
            event_time=close_time,
            exchange_time=close_time,
            received_time=received_time,
            available_time=available_time,
            ingestion_time=ingestion_time,
            information_age_seconds=max(0.0, (received_time - available_time).total_seconds()),
            values=values,
            transformation_version=TRANSFORMATION_VERSION,
            metadata={
                "historical": True,
                "backtest_eligible": True,
                "interval": "15m",
                "available_time_rule": "official kline close_time + 1 millisecond",
                "aggressor_convention": "taker buy base volume supplied by Binance; seller taker = total - taker buy",
                "limitations": "bar aggregates; historical depth, spread, liquidations and open interest are unavailable",
            },
        )

    def backfill(
        self,
        *,
        asset: str,
        data_family: str,
        start: datetime,
        end: datetime,
    ) -> BackfillReport:
        if asset not in {"BTC", "ETH"}:
            raise ValueError("historical V1 supports only BTC and ETH")
        if data_family not in {"SPOT", "PERPS"}:
            raise ValueError("historical backfill supports SPOT and PERPS")
        requested_start = ensure_utc(start)
        safe_end = min(ensure_utc(end), utc_now() - timedelta(minutes=1))
        if requested_start >= safe_end:
            raise ValueError("historical start must be before the last safely completed bar")

        source = "binance" if data_family == "SPOT" else "binance_futures"
        latest = self.normalized_store.latest_event_time(
            source=source,
            data_family=data_family,
            asset=asset,
            transformation_version=TRANSFORMATION_VERSION,
        )
        effective_start = requested_start
        if latest is not None:
            effective_start = max(effective_start, latest + timedelta(milliseconds=1))
        if effective_start >= safe_end:
            return BackfillReport(
                asset,
                data_family,
                requested_start.isoformat(),
                effective_start.isoformat(),
                safe_end.isoformat(),
                0,
                0,
                0,
                0,
                "ALREADY_CURRENT",
            )

        funding_start = max(requested_start, effective_start - timedelta(days=2))
        funding = self._funding_history(asset, funding_start, safe_end) if data_family == "PERPS" else []
        funding_times = [item[0] for item in funding]
        funding_values = [item[1] for item in funding]
        base_url = self.spot_base_url if data_family == "SPOT" else self.futures_base_url
        endpoint = "/api/v3/klines" if data_family == "SPOT" else "/fapi/v1/klines"
        raw_source = "binance_spot_historical" if data_family == "SPOT" else "binance_futures_historical"
        cursor = int(effective_start.timestamp() * 1000)
        end_ms = int(safe_end.timestamp() * 1000)
        pages = received_count = inserted_count = 0

        while cursor < end_ms:
            payload, received = self._get_json(
                base_url=base_url,
                endpoint=endpoint,
                params={"symbol": f"{asset}USDT", "interval": "15m", "startTime": cursor, "endTime": end_ms, "limit": 1000},
                raw_source=raw_source,
            )
            if not payload:
                break
            observations = []
            for row in payload:
                available_ms = int(row[6]) + 1
                if available_ms > end_ms:
                    continue
                funding_rate = (
                    self._latest_funding(funding_times, funding_values, available_ms)
                    if data_family == "PERPS"
                    else None
                )
                observations.append(
                    self._observation_from_kline(
                        row=row,
                        received_time=received,
                        asset=asset,
                        data_family=data_family,
                        funding_rate=funding_rate,
                    )
                )
            inserted_count += self.normalized_store.insert(observations)
            received_count += len(observations)
            pages += 1
            next_cursor = int(payload[-1][0]) + INTERVAL_MILLISECONDS
            if next_cursor <= cursor:
                raise RuntimeError("Binance kline pagination did not advance")
            cursor = next_cursor
            if pages % 25 == 0:
                print(
                    f"{asset} {data_family}: {received_count:,} barres reçues, {inserted_count:,} insérées",
                    flush=True,
                )
            if len(payload) < 1000:
                break

        return BackfillReport(
            asset=asset,
            data_family=data_family,
            requested_start=requested_start.isoformat(),
            effective_start=effective_start.isoformat(),
            end=safe_end.isoformat(),
            pages=pages,
            received=received_count,
            inserted=inserted_count,
            duplicates=received_count - inserted_count,
            status="SUCCESS",
        )

    def backfill_many(
        self,
        *,
        assets: Iterable[str],
        families: Iterable[str],
        start: datetime,
        end: datetime,
    ) -> list[BackfillReport]:
        reports = []
        for asset in assets:
            for family in families:
                report = self.backfill(asset=asset, data_family=family, start=start, end=end)
                reports.append(report)
                print(report.to_dict(), flush=True)
        return reports
