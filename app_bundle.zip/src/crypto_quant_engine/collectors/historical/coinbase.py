from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from ...schema import Observation
from ...storage.normalized import NormalizedStore
from ...time import ensure_utc, utc_now


INTERVAL = timedelta(minutes=15)
TRANSFORMATION_VERSION = "coinbase-hosted-gap-v1"


@dataclass(frozen=True)
class CoinbaseGapReport:
    asset: str
    requested_start: str
    end: str
    pages: int
    received: int
    inserted: int
    status: str


def _iso(value: datetime) -> str:
    return ensure_utc(value).isoformat().replace("+00:00", "Z")


def _floor_interval(value: datetime) -> datetime:
    timestamp = ensure_utc(value)
    seconds = int(timestamp.timestamp())
    return datetime.fromtimestamp(seconds - seconds % int(INTERVAL.total_seconds()), tz=timezone.utc)


def backfill_coinbase_spot_gap(
    get_json: Callable[[str, dict[str, Any]], tuple[Any, datetime]],
    normalized_store: NormalizedStore,
    *,
    asset: str,
    start: datetime,
    end: datetime,
) -> CoinbaseGapReport:
    """Append completed Coinbase candles missed while the hosted app slept.

    Coinbase documents a 300-candle response limit.  Pages are therefore
    requested in bounded 299-bar chunks and filtered explicitly.  Candles
    recover price/volume continuity only: taker side, depth and open interest
    remain null instead of being inferred from OHLC direction.
    """

    if asset not in {"BTC", "ETH"}:
        raise ValueError("Coinbase hosted gap recovery supports BTC and ETH")
    requested_start = ensure_utc(start)
    cursor = _floor_interval(requested_start)
    safe_end = _floor_interval(end)
    if cursor >= safe_end:
        return CoinbaseGapReport(asset, _iso(requested_start), _iso(safe_end), 0, 0, 0, "ALREADY_CURRENT")

    product = f"{asset}-USD"
    pages = received_count = inserted_count = 0
    while cursor < safe_end:
        page_end = min(cursor + 299 * INTERVAL, safe_end)
        payload, received_time = get_json(
            f"/products/{product}/candles",
            {
                "granularity": int(INTERVAL.total_seconds()),
                "start": _iso(cursor),
                "end": _iso(page_end),
            },
        )
        pages += 1
        if not isinstance(payload, list):
            raise ValueError("unexpected Coinbase candle response")
        observations: list[Observation] = []
        for row in payload:
            if not isinstance(row, list) or len(row) < 6:
                raise ValueError("Coinbase candle is missing OHLCV fields")
            bucket_start = datetime.fromtimestamp(float(row[0]), tz=timezone.utc)
            close_time = bucket_start + INTERVAL
            if bucket_start < cursor or close_time > page_end or close_time > safe_end:
                continue
            observations.append(
                Observation(
                    source="coinbase",
                    data_family="SPOT",
                    asset=asset,
                    instrument=product,
                    quote_currency="USD",
                    event_time=close_time,
                    exchange_time=close_time,
                    received_time=received_time,
                    available_time=close_time + timedelta(milliseconds=1),
                    ingestion_time=utc_now(),
                    information_age_seconds=max(0.0, (received_time - close_time).total_seconds()),
                    values={
                        "price": float(row[4]),
                        "open_price": float(row[3]),
                        "high_price": float(row[2]),
                        "low_price": float(row[1]),
                        "trade_volume_base": float(row[5]),
                        "aggressive_buy_volume_base": None,
                        "aggressive_sell_volume_base": None,
                        "trade_count": None,
                        "best_bid": None,
                        "best_ask": None,
                        "mid_price": float(row[4]),
                        "spread": None,
                        "bid_depth_notional": None,
                        "ask_depth_notional": None,
                    },
                    metadata={
                        "provider": "Coinbase Exchange",
                        "interval": "15m",
                        "hosted_gap_recovery": True,
                        "backtest_eligible": False,
                        "available_time_rule": "official candle close + 1 millisecond",
                        "limitations": "OHLCV only; taker side and order-book depth unavailable",
                    },
                    transformation_version=TRANSFORMATION_VERSION,
                )
            )
        received_count += len(observations)
        inserted_count += normalized_store.insert(observations)
        cursor = page_end

    return CoinbaseGapReport(
        asset=asset,
        requested_start=_iso(requested_start),
        end=_iso(safe_end),
        pages=pages,
        received=received_count,
        inserted=inserted_count,
        status="SUCCESS",
    )
