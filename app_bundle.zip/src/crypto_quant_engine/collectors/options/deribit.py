from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from ...constants import ASSETS
from ...schema import Observation
from ...time import utc_now
from ..base import BaseCollector, CollectionBatch


@dataclass(frozen=True)
class ParsedOption:
    asset: str
    expiration: datetime
    strike: float
    call_or_put: str


def parse_instrument(name: str) -> ParsedOption:
    asset, expiry, strike, option_type = name.split("-")
    expiration = datetime.strptime(expiry, "%d%b%y").replace(tzinfo=timezone.utc)
    return ParsedOption(asset, expiration, float(strike), "call" if option_type == "C" else "put")


class DeribitOptionsCollector(BaseCollector):
    source = "deribit"

    def collect(self) -> CollectionBatch:
        batch = CollectionBatch()
        for asset in ASSETS:
            try:
                payload, received = self.get_json(
                    "/api/v2/public/get_book_summary_by_currency",
                    {"currency": asset, "kind": "option"},
                )
                summaries = payload.get("result", [])
                for item in summaries:
                    parsed = parse_instrument(item["instrument_name"])
                    # Deribit exposes the summary creation time. It is the market-event
                    # timestamp; the observation only becomes usable at our later receipt.
                    creation_timestamp = item.get("creation_timestamp")
                    exchange_time = (
                        datetime.fromtimestamp(float(creation_timestamp) / 1000.0, tz=timezone.utc)
                        if creation_timestamp is not None
                        else received
                    )
                    if exchange_time > received:
                        exchange_time = received
                    underlying = item.get("underlying_price")
                    oi = item.get("open_interest")
                    # BTC/ETH inverse options have a 1 base-coin contract multiplier.
                    # Deribit's summary OI is already expressed in base-currency units.
                    contract_multiplier = 1.0
                    contract_notional = float(oi) * float(underlying) if oi is not None and underlying else None
                    batch.observations.append(
                        Observation(
                            source=self.source,
                            data_family="OPTIONS",
                            asset=asset,
                            instrument=item["instrument_name"],
                            quote_currency=asset,
                            event_time=exchange_time,
                            exchange_time=exchange_time,
                            received_time=received,
                            available_time=received,
                            ingestion_time=utc_now(),
                            values={
                                "call_or_put": parsed.call_or_put,
                                "strike": parsed.strike,
                                "expiration": parsed.expiration.isoformat(),
                                "underlying_price": underlying,
                                "mark_price": item.get("mark_price"),
                                "bid": item.get("bid_price"),
                                "ask": item.get("ask_price"),
                                "volume_contracts": item.get("volume"),
                                "open_interest_contracts": oi,
                                "open_interest_base_units": oi,
                                "contract_multiplier_base_units": contract_multiplier,
                                "open_interest_notional_usd_estimate": contract_notional,
                                "implied_volatility": item.get("mark_iv"),
                                "interest_rate": item.get("interest_rate"),
                                "delta": None,
                                "gamma": None,
                                "vega": None,
                                "theta": None,
                            },
                            metadata={
                                "timestamp_semantics": "event/exchange use Deribit summary creation_timestamp; available_time is local receipt",
                                "greeks": "not exposed by summary endpoint; intentionally null",
                                "open_interest_semantics": "Deribit options OI is in underlying base-currency units",
                                "contract_multiplier_source": "Deribit BTC/ETH inverse option specification: 1 base coin",
                            },
                        )
                    )
                batch.coverage[asset] = bool(summaries)
                if not summaries:
                    batch.errors.append(f"{asset}: empty options summary")
            except Exception as exc:
                batch.errors.append(f"{asset}: {exc}")
                batch.coverage[asset] = False
        return batch
