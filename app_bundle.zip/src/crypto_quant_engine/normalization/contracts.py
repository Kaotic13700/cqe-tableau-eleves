from __future__ import annotations


def normalize_open_interest_notional(
    open_interest: float,
    price: float,
    *,
    unit: str,
    contract_size: float = 1.0,
) -> float:
    """Convert explicitly declared contract units to USD notional."""
    if open_interest < 0 or price <= 0 or contract_size <= 0:
        raise ValueError("OI must be non-negative and price/contract_size positive")
    if unit == "base_asset":
        return open_interest * contract_size * price
    if unit == "usd_notional":
        return open_interest * contract_size
    if unit == "inverse_usd_contract":
        return open_interest * contract_size
    raise ValueError(f"unsupported or ambiguous contract unit: {unit}")

