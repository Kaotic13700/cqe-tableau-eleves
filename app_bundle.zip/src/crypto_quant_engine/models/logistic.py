from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


class LogisticProbabilityModel:
    def __init__(self, feature_columns: list[str], c: float = 0.5, max_iter: int = 2000) -> None:
        self.feature_columns = list(feature_columns)
        self.pipeline = Pipeline(
            [
                ("impute", SimpleImputer(strategy="median", add_indicator=True)),
                ("scale", StandardScaler()),
                ("model", LogisticRegression(C=c, l1_ratio=0, max_iter=max_iter, random_state=20260825)),
            ]
        )

    def fit(self, x: pd.DataFrame, y: pd.Series) -> "LogisticProbabilityModel":
        labels = pd.Series(y, index=x.index)
        valid = labels.notna()
        if labels[valid].nunique() < 2:
            raise ValueError("logistic regression requires both target classes")
        self.pipeline.fit(x.loc[valid, self.feature_columns], labels.loc[valid].astype(int))
        return self

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        return self.pipeline.predict_proba(x.loc[:, self.feature_columns])

    def contributions(self, x: pd.DataFrame) -> pd.DataFrame:
        transformed = self.pipeline[:-1].transform(x.loc[:, self.feature_columns])
        coefficients = self.pipeline.named_steps["model"].coef_[0]
        names = self.pipeline[:-1].get_feature_names_out(self.feature_columns)
        return pd.DataFrame(transformed * coefficients, index=x.index, columns=names)
