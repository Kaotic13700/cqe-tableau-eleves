from __future__ import annotations

import numpy as np
import pandas as pd


class ProbabilityEnsemble:
    def __init__(self, models: list[object], weights: list[float] | None = None) -> None:
        if not models:
            raise ValueError("at least one model is required")
        self.models = models
        raw_weights = np.asarray(weights if weights is not None else np.ones(len(models)), dtype=float)
        if len(raw_weights) != len(models) or np.any(raw_weights < 0) or raw_weights.sum() <= 0:
            raise ValueError("weights must be non-negative and match models")
        self.weights = raw_weights / raw_weights.sum()

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        probabilities = np.vstack([model.predict_proba(x)[:, 1] for model in self.models])
        positive = np.average(probabilities, axis=0, weights=self.weights)
        return np.column_stack([1 - positive, positive])

    def disagreement(self, x: pd.DataFrame) -> np.ndarray:
        probabilities = np.vstack([model.predict_proba(x)[:, 1] for model in self.models])
        return probabilities.std(axis=0)

