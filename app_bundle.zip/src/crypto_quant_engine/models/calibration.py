from __future__ import annotations

import numpy as np
from scipy.special import expit, logit
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression


class ProbabilityCalibrator:
    """Fit only on a temporally later calibration set, never the final test set."""

    def __init__(self, method: str = "sigmoid") -> None:
        if method not in {"sigmoid", "isotonic"}:
            raise ValueError("method must be sigmoid or isotonic")
        self.method = method
        self.model = LogisticRegression(C=1e6) if method == "sigmoid" else IsotonicRegression(out_of_bounds="clip")

    def fit(self, raw_probability: np.ndarray, y: np.ndarray) -> "ProbabilityCalibrator":
        probability = np.clip(np.asarray(raw_probability, dtype=float), 1e-6, 1 - 1e-6)
        target = np.asarray(y, dtype=int)
        if self.method == "sigmoid":
            self.model.fit(logit(probability).reshape(-1, 1), target)
        else:
            self.model.fit(probability, target)
        return self

    def transform(self, raw_probability: np.ndarray) -> np.ndarray:
        probability = np.clip(np.asarray(raw_probability, dtype=float), 1e-6, 1 - 1e-6)
        if self.method == "sigmoid":
            return self.model.predict_proba(logit(probability).reshape(-1, 1))[:, 1]
        return np.asarray(self.model.predict(probability), dtype=float)


def calibration_grade(brier_score: float, expected_calibration_error: float) -> str:
    if brier_score <= 0.18 and expected_calibration_error <= 0.03:
        return "A"
    if brier_score <= 0.21 and expected_calibration_error <= 0.05:
        return "B"
    if brier_score <= 0.24 and expected_calibration_error <= 0.08:
        return "C"
    return "D"

