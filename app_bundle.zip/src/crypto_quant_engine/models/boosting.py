from __future__ import annotations

import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline


class BoostingCandidate:
    """Candidate only; it cannot replace baselines without OOS acceptance evidence."""

    def __init__(self, feature_columns: list[str]) -> None:
        self.feature_columns = list(feature_columns)
        self.pipeline = Pipeline(
            [
                ("impute", SimpleImputer(strategy="median")),
                (
                    "model",
                    HistGradientBoostingClassifier(
                        learning_rate=0.04,
                        max_depth=3,
                        max_iter=200,
                        l2_regularization=1.0,
                        random_state=20260825,
                    ),
                ),
            ]
        )

    def fit(self, x: pd.DataFrame, y: pd.Series) -> "BoostingCandidate":
        valid = y.notna()
        self.pipeline.fit(x.loc[valid, self.feature_columns], y.loc[valid].astype(int))
        return self

    def predict_proba(self, x: pd.DataFrame):
        return self.pipeline.predict_proba(x.loc[:, self.feature_columns])

