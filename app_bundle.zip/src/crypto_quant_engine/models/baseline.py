from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class UnconditionalBaseline:
    probability_: float | None = None
    sample_count_: int = 0

    def fit(self, _x: pd.DataFrame, y: pd.Series) -> "UnconditionalBaseline":
        valid = pd.Series(y).dropna().astype(float)
        if valid.empty:
            raise ValueError("cannot fit an unconditional baseline without labels")
        self.sample_count_ = len(valid)
        self.probability_ = float(valid.mean())
        return self

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        if self.probability_ is None:
            raise RuntimeError("model is not fitted")
        positive = np.full(len(x), self.probability_)
        return np.column_stack([1 - positive, positive])


@dataclass
class RegimeConditionalBaseline:
    regime_columns: tuple[str, ...]
    minimum_samples: int = 50
    global_probability_: float | None = None
    probabilities_: dict[tuple[object, ...], float] = field(default_factory=dict)
    counts_: dict[tuple[object, ...], int] = field(default_factory=dict)

    def fit(self, x: pd.DataFrame, y: pd.Series) -> "RegimeConditionalBaseline":
        frame = x.loc[:, self.regime_columns].copy()
        frame["target"] = pd.Series(y, index=x.index)
        frame = frame.dropna(subset=["target"])
        if frame.empty:
            raise ValueError("cannot fit regime baseline without labels")
        self.global_probability_ = float(frame["target"].mean())
        for key, group in frame.groupby(list(self.regime_columns), dropna=False):
            normalized_key = key if isinstance(key, tuple) else (key,)
            self.counts_[normalized_key] = len(group)
            if len(group) >= self.minimum_samples:
                self.probabilities_[normalized_key] = float(group["target"].mean())
        return self

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        if self.global_probability_ is None:
            raise RuntimeError("model is not fitted")
        positive = []
        for key in x.loc[:, self.regime_columns].itertuples(index=False, name=None):
            positive.append(self.probabilities_.get(tuple(key), self.global_probability_))
        values = np.asarray(positive)
        return np.column_stack([1 - values, values])

