from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd

from ..collectors.historical.binance import TRANSFORMATION_VERSION
from ..journal.predictions import PredictionJournal
from ..storage.normalized import NormalizedStore
from .dataset import MODEL_FEATURES, build_historical_research_dataset


def _json_value(value: Any) -> Any:
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if pd.isna(value):
        return None
    return value


def _already_recorded(journal: PredictionJournal, prediction_id: str) -> bool:
    with journal.connect() as connection:
        return connection.execute(
            "SELECT 1 FROM predictions WHERE prediction_id = ?", (prediction_id,)
        ).fetchone() is not None


def record_forward_predictions(
    *,
    normalized_store: NormalizedStore,
    journal: PredictionJournal,
    research_latest_path: str | Path,
    lookback_days: int = 45,
    minimum_effective_samples: int = 500,
) -> list[dict[str, Any]]:
    pointer = json.loads(Path(research_latest_path).read_text(encoding="utf-8"))
    pointer_path = Path(research_latest_path)
    summary_path = Path(pointer["summary_path"])
    if not summary_path.exists():
        summary_path = pointer_path.parent / pointer["research_version"] / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    observations = normalized_store.query(
        transformation_version=TRANSFORMATION_VERSION,
        available_after=datetime.now(timezone.utc) - timedelta(days=lookback_days),
    )
    frame = build_historical_research_dataset(observations)
    if frame.empty:
        raise RuntimeError("no historical bars available for forward prediction")
    model_directory = Path(pointer["model_directory"])
    if not model_directory.exists():
        model_directory = pointer_path.parents[2] / "models" / pointer["research_version"]
    reports = []
    for evaluation in summary["evaluations"]:
        asset = evaluation["asset"]
        target = evaluation["target"]
        artifact = joblib.load(model_directory / f"{asset}_{target}.joblib")
        latest = frame[frame["asset"] == asset].sort_values("prediction_time").iloc[-1]
        sample = latest.to_frame().T
        raw = float(artifact["model"].predict_proba(sample)[:, 1][0])
        calibrated = (
            float(artifact["calibrator"].transform(np.asarray([raw]))[0])
            if artifact["calibrator"] is not None
            else raw
        )
        effective = float(evaluation["holdout"]["effective_sample_count"])
        status = evaluation["status"]
        statistically_publishable = (
            status == "BACKTEST_VALIDATED_FORWARD_PENDING"
            or (status == "VALIDATED_BASE_RATE_ONLY" and effective >= minimum_effective_samples)
        )
        if status == "VALIDATED_BASE_RATE_ONLY":
            status = "VALIDATED_BASE_RATE_ONLY" if effective >= minimum_effective_samples else "INSUFFICIENT_EFFECTIVE_SAMPLE_FOR_PRECISE_RATE"
        available_time = pd.Timestamp(latest["feature_available_time"])
        age_seconds = max(0.0, (pd.Timestamp.now(tz="UTC") - available_time).total_seconds())
        completeness = float(sample[MODEL_FEATURES].notna().mean(axis=1).iloc[0])
        quality_score = 100 * (0.65 * completeness + 0.35 * max(0.0, 1 - age_seconds / 86_400))
        model_version = f"{pointer['research_version']}:{target}"
        prediction_timestamp = pd.Timestamp(latest["prediction_time"]).isoformat()
        identity = json.dumps(
            {"prediction_timestamp": prediction_timestamp, "asset": asset, "model_version": model_version},
            sort_keys=True,
        )
        import hashlib

        prediction_id = hashlib.sha256(identity.encode()).hexdigest()
        payload = {
            "prediction_timestamp": prediction_timestamp,
            "available_data_timestamp": available_time.isoformat(),
            "asset": asset,
            "price": float(latest["spot_price"]),
            "raw_features": {key: _json_value(latest.get(key)) for key in MODEL_FEATURES},
            "normalized_features": {
                key: _json_value(latest.get(key)) for key in MODEL_FEATURES if key.endswith("_z")
            },
            "macro_regime": "UNAVAILABLE_IN_HISTORICAL_CORE",
            "market_regime": {
                key: _json_value(latest.get(key, "UNCERTAIN"))
                for key in ("trend_regime", "volatility_regime", "driver_regime", "positioning_regime")
            },
            "model_version": model_version,
            "training_window": summary["dataset_version"],
            "raw_probability": raw if statistically_publishable else None,
            "calibrated_probability": calibrated if statistically_publishable else None,
            "confidence": {
                "status": status,
                "effective_sample_count": effective,
                "conditional_edge_validated": status == "BACKTEST_VALIDATED_FORWARD_PENDING",
                "reasons": (
                    []
                    if statistically_publishable
                    else ["NO_ROBUST_CONDITIONAL_EDGE_OR_EFFECTIVE_SAMPLE_TOO_SMALL"]
                ),
            },
            "data_quality": {
                "score": round(quality_score, 2),
                "feature_completeness": completeness,
                "data_age_seconds": age_seconds,
                "families": ["SPOT", "PERPS"],
                "excluded_families": ["OPTIONS_HISTORY", "ETF", "CME", "MACRO_VINTAGES"],
            },
            "expected_mae": None,
            "expected_mfe": None,
            "status": status,
        }
        if not _already_recorded(journal, prediction_id):
            journal.record(payload)
            action = "RECORDED"
        else:
            action = "ALREADY_RECORDED"
        reports.append(
            {
                "asset": asset,
                "target": target,
                "prediction_time": prediction_timestamp,
                "status": status,
                "action": action,
                "probability_published": statistically_publishable,
            }
        )
    return reports
