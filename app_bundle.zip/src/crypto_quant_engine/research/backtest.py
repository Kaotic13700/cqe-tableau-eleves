from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

import joblib
import numpy as np
import pandas as pd
from scipy.stats import norm, ttest_1samp
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

from ..journal.experiments import ExperimentRegistry
from ..models.baseline import RegimeConditionalBaseline, UnconditionalBaseline
from ..models.calibration import ProbabilityCalibrator, calibration_grade
from ..models.logistic import LogisticProbabilityModel
from ..scoring.effective_sample import effective_sample_size
from ..validation.calibration import calibration_metrics, calibration_table
from ..validation.purged_cv import PurgedWalkForwardSplit
from ..validation.walk_forward import walk_forward_evaluate
from .dataset import FEATURE_FAMILIES, MODEL_FEATURES, TARGETS


@dataclass(frozen=True)
class ResearchSettings:
    minimum_train_observations: int = 17_520
    fold_observations: int = 2_880
    embargo_observations: int = 672
    calibration_observations: int = 8_640
    final_holdout_fraction: float = 0.20
    minimum_oos_folds: int = 6
    minimum_effective_samples: int = 500
    minimum_simple_brier_improvement: float = 0.001
    maximum_ece: float = 0.08
    alpha: float = 0.05
    random_seed: int = 20260825


def benjamini_hochberg(p_values: list[float]) -> list[float]:
    if not p_values:
        return []
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    ranked = values[order]
    adjusted = np.empty(len(values), dtype=float)
    running = 1.0
    for reverse_index in range(len(values) - 1, -1, -1):
        rank = reverse_index + 1
        running = min(running, ranked[reverse_index] * len(values) / rank)
        adjusted[order[reverse_index]] = running
    return np.clip(adjusted, 0, 1).tolist()


def paired_block_power(
    actual: np.ndarray,
    baseline_probability: np.ndarray,
    candidate_probability: np.ndarray,
    *,
    block_size: int,
    required_improvement: float,
    alpha: float = 0.05,
    target_power: float = 0.80,
) -> dict[str, Any]:
    """Report paired-block evidence and the detectable Brier improvement.

    Overlapping prediction origins are collapsed into horizon-sized blocks.
    The minimum detectable effect uses a one-sided normal approximation on the
    independent block means. It is diagnostic only: model selection still uses
    the predeclared walk-forward, embargo, BH, stability, and holdout gates.
    """

    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one")
    if not 0 < target_power < 1:
        raise ValueError("target_power must be between zero and one")
    if required_improvement < 0:
        raise ValueError("required_improvement cannot be negative")
    loss_difference = (actual - baseline_probability) ** 2 - (actual - candidate_probability) ** 2
    block = np.arange(len(loss_difference)) // max(1, block_size)
    block_means = pd.Series(loss_difference).groupby(block).mean().dropna().to_numpy()
    improvement = float(np.mean(loss_difference)) if len(loss_difference) else float("nan")
    if len(block_means) < 3 or np.allclose(block_means, block_means[0]):
        p_value = 1.0 if not np.isfinite(improvement) or improvement <= 0 else 0.5
        minimum_detectable = float("nan")
        adequately_powered = False
        conclusion = "INCONCLUSIVE_DEGENERATE_OR_TOO_FEW_BLOCKS"
    else:
        statistic = ttest_1samp(block_means, popmean=0.0, alternative="greater")
        p_value = float(statistic.pvalue)
        standard_error = float(np.std(block_means, ddof=1) / np.sqrt(len(block_means)))
        minimum_detectable = float(
            (norm.ppf(1 - alpha) + norm.ppf(target_power)) * standard_error
        )
        adequately_powered = bool(minimum_detectable <= required_improvement)
        if p_value <= alpha and improvement > 0:
            conclusion = "RAW_EDGE_DETECTED_BH_PENDING"
        elif adequately_powered:
            conclusion = "NO_EDGE_AT_OR_ABOVE_PREDECLARED_THRESHOLD"
        else:
            conclusion = "INCONCLUSIVE_UNDERPOWERED"
    return {
        "brier_improvement": improvement,
        "p_value": p_value,
        "independent_block_count": len(block_means),
        "minimum_detectable_brier_improvement": minimum_detectable,
        "required_brier_improvement": required_improvement,
        "target_power": target_power,
        "alpha": alpha,
        "adequately_powered_for_required_improvement": adequately_powered,
        "power_conclusion": conclusion,
    }


def paired_block_p_value(
    actual: np.ndarray,
    baseline_probability: np.ndarray,
    candidate_probability: np.ndarray,
    *,
    block_size: int,
) -> tuple[float, float, int]:
    """Compatibility wrapper for callers that only need the paired test."""

    report = paired_block_power(
        actual,
        baseline_probability,
        candidate_probability,
        block_size=block_size,
        required_improvement=0.0,
    )
    return (
        report["brier_improvement"],
        report["p_value"],
        report["independent_block_count"],
    )


def _probability_metrics(actual: np.ndarray, probability: np.ndarray) -> dict[str, float]:
    return {
        "brier": float(brier_score_loss(actual, probability)),
        "log_loss": float(log_loss(actual, probability, labels=[0, 1])),
        "roc_auc": float(roc_auc_score(actual, probability)) if len(np.unique(actual)) == 2 else float("nan"),
    }


def _model_factory(name: str) -> Callable[[], object]:
    if name == "M0_UNCONDITIONAL":
        return UnconditionalBaseline
    if name == "M1_REGIME":
        return lambda: RegimeConditionalBaseline(
            ("trend_regime", "volatility_regime", "driver_regime"), minimum_samples=200
        )
    if name == "M2_LOGISTIC":
        return lambda: LogisticProbabilityModel(MODEL_FEATURES, c=0.5, max_iter=2000)
    raise ValueError(f"unknown research model: {name}")


def _overall_oos(
    frame: pd.DataFrame,
    target: str,
    label_end: str,
    model_name: str,
    settings: ResearchSettings,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    splitter = PurgedWalkForwardSplit(
        minimum_train_size=settings.minimum_train_observations,
        test_size=settings.fold_observations,
        step_size=settings.fold_observations,
        embargo_size=settings.embargo_observations,
    )
    predictions, folds = walk_forward_evaluate(
        frame,
        _model_factory(model_name),
        target,
        splitter,
        label_end_column=label_end,
    )
    if predictions.empty:
        return predictions, {"fold_count": 0}
    actual = predictions[target].astype(int).to_numpy()
    probability = predictions["probability"].to_numpy(dtype=float)
    summary = {
        **_probability_metrics(actual, probability),
        "fold_count": int(predictions["fold"].nunique()),
        "sample_count": len(predictions),
        "mean_train_count": float(folds["train_count"].mean()),
        "mean_test_count": float(folds["test_count"].mean()),
    }
    return predictions, summary


def _regime_stability(frame: pd.DataFrame, merged_predictions: pd.DataFrame) -> dict[str, Any]:
    context = frame[["prediction_time", "trend_regime", "volatility_regime"]].drop_duplicates("prediction_time")
    sample = merged_predictions.merge(context, on="prediction_time", how="left")
    sample["improvement"] = (sample["actual"] - sample["baseline_probability"]) ** 2 - (
        sample["actual"] - sample["candidate_probability"]
    ) ** 2
    groups = (
        sample.groupby(["trend_regime", "volatility_regime"], dropna=False)["improvement"]
        .agg(["size", "mean"])
        .reset_index()
    )
    eligible = groups[groups["size"] >= 200]
    positive_fraction = float((eligible["mean"] > 0).mean()) if len(eligible) else 0.0
    worst = float(eligible["mean"].min()) if len(eligible) else float("nan")
    stable = len(eligible) >= 3 and positive_fraction >= 0.6 and (not np.isfinite(worst) or worst > -0.01)
    return {
        "stable": bool(stable),
        "eligible_regime_cells": int(len(eligible)),
        "positive_cell_fraction": positive_fraction,
        "worst_cell_brier_improvement": worst,
    }


def _freeze_manifest(
    *,
    dataset_path: Path,
    dataset_version: str,
    frame: pd.DataFrame,
    output_directory: Path,
    settings: ResearchSettings,
) -> dict[str, Any]:
    dataset_hash = hashlib.sha256(dataset_path.read_bytes()).hexdigest()
    boundaries = {}
    for asset in ("BTC", "ETH"):
        sample = frame[frame["asset"] == asset].sort_values("prediction_time")
        holdout_index = int(np.floor(len(sample) * (1 - settings.final_holdout_fraction)))
        boundaries[asset] = {
            "row_count": len(sample),
            "history_start": str(sample["prediction_time"].min()),
            "holdout_start": str(sample.iloc[holdout_index]["prediction_time"]),
            "history_end": str(sample["prediction_time"].max()),
        }
    manifest = {
        "dataset_version": dataset_version,
        "dataset_sha256": dataset_hash,
        "frozen_before_model_selection": True,
        "feature_columns": MODEL_FEATURES,
        "feature_families": FEATURE_FAMILIES,
        "targets": list(TARGETS),
        "settings": asdict(settings),
        "boundaries": boundaries,
    }
    path = output_directory / "freeze_manifest.json"
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest


def _split_target_frame(
    frame: pd.DataFrame,
    target: str,
    settings: ResearchSettings,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sample = frame[frame[target].notna()].sort_values("prediction_time").reset_index(drop=True)
    holdout_start = int(np.floor(len(sample) * (1 - settings.final_holdout_fraction)))
    calibration_start = holdout_start - settings.calibration_observations
    if calibration_start <= settings.minimum_train_observations + settings.embargo_observations:
        raise ValueError(f"insufficient history for frozen calibration and holdout: {target}")
    development = sample.iloc[:calibration_start].copy()
    calibration = sample.iloc[calibration_start:holdout_start].copy()
    holdout = sample.iloc[holdout_start:].copy()
    # Le calibrateur apprend aussi sur des résultats : purger sa frontière avec
    # le holdout, comme celle de l'entraînement avec la calibration.
    cutoff = pd.to_datetime(holdout["prediction_time"], utc=True).min()
    calibration = calibration.iloc[:max(0, len(calibration) - settings.embargo_observations)]
    label_end_column = f"label_end_time_{target}"
    ends = pd.to_datetime(calibration[label_end_column], utc=True, errors="coerce")
    calibration = calibration[ends.notna() & (ends < cutoff)].copy()
    if calibration.empty:
        raise ValueError(f"insufficient purged calibration history: {target}")
    return development, calibration, holdout


def _fit_before_calibration(
    full_development: pd.DataFrame,
    calibration: pd.DataFrame,
    target: str,
    label_end: str,
    model_name: str,
    settings: ResearchSettings,
) -> tuple[object, ProbabilityCalibrator | None, dict[str, Any]]:
    cutoff = calibration["prediction_time"].min()
    embargoed = full_development.iloc[: max(0, len(full_development) - settings.embargo_observations)]
    train = embargoed[pd.to_datetime(embargoed[label_end], utc=True).lt(cutoff)]
    model = _model_factory(model_name)()
    model.fit(train, train[target])
    raw_probability = model.predict_proba(calibration)[:, 1]
    calibrator: ProbabilityCalibrator | None = None
    calibrated = raw_probability
    if model_name != "M0_UNCONDITIONAL":
        calibrator = ProbabilityCalibrator("sigmoid").fit(raw_probability, calibration[target].astype(int).to_numpy())
        calibrated = calibrator.transform(raw_probability)
    metrics = calibration_metrics(calibration[target].astype(int).to_numpy(), calibrated)
    return model, calibrator, {
        "train_count": len(train),
        "training_base_rate": float(train[target].mean()),
        "calibration_count": len(calibration),
        **metrics,
        "grade": calibration_grade(metrics["brier"], metrics["expected_calibration_error"]),
    }


def run_research_backtest(
    *,
    frame: pd.DataFrame,
    dataset_path: str | Path,
    dataset_version: str,
    research_version: str,
    output_root: str | Path,
    model_root: str | Path,
    experiment_registry: ExperimentRegistry,
    settings: ResearchSettings | None = None,
) -> dict[str, Any]:
    settings = settings or ResearchSettings()
    output_directory = Path(output_root) / research_version
    model_directory = Path(model_root) / research_version
    if output_directory.exists() or model_directory.exists():
        raise FileExistsError(f"research version already exists: {research_version}")
    output_directory.mkdir(parents=True)
    model_directory.mkdir(parents=True)
    dataset_path = Path(dataset_path)
    manifest = _freeze_manifest(
        dataset_path=dataset_path,
        dataset_version=dataset_version,
        frame=frame,
        output_directory=output_directory,
        settings=settings,
    )

    development_runs: list[dict[str, Any]] = []
    prediction_cache: dict[tuple[str, str, str], pd.DataFrame] = {}
    for asset in ("BTC", "ETH"):
        asset_frame = frame[frame["asset"] == asset].sort_values("prediction_time")
        for target, (horizon_steps, _) in TARGETS.items():
            label_end = f"label_end_time_{target}"
            development, _, _ = _split_target_frame(asset_frame, target, settings)
            for model_name in ("M0_UNCONDITIONAL", "M1_REGIME", "M2_LOGISTIC"):
                predictions, metrics = _overall_oos(
                    development, target, label_end, model_name, settings
                )
                prediction_cache[(asset, target, model_name)] = predictions
                development_runs.append(
                    {
                        "asset": asset,
                        "target": target,
                        "horizon_steps": horizon_steps,
                        "model": model_name,
                        "metrics": metrics,
                    }
                )
                print(
                    f"{asset} {target} {model_name}: {metrics.get('fold_count', 0)} plis, "
                    f"Brier={metrics.get('brier', float('nan')):.6f}",
                    flush=True,
                )

    tests: list[dict[str, Any]] = []
    for asset in ("BTC", "ETH"):
        for target, (horizon_steps, _) in TARGETS.items():
            baseline = prediction_cache[(asset, target, "M0_UNCONDITIONAL")].rename(
                columns={"probability": "baseline_probability", target: "actual"}
            )
            for model_name in ("M1_REGIME", "M2_LOGISTIC"):
                candidate = prediction_cache[(asset, target, model_name)].rename(
                    columns={"probability": "candidate_probability"}
                )
                merged = baseline[["prediction_time", "actual", "baseline_probability"]].merge(
                    candidate[["prediction_time", "candidate_probability"]], on="prediction_time", how="inner"
                )
                power = paired_block_power(
                    merged["actual"].to_numpy(dtype=float),
                    merged["baseline_probability"].to_numpy(dtype=float),
                    merged["candidate_probability"].to_numpy(dtype=float),
                    block_size=horizon_steps,
                    required_improvement=settings.minimum_simple_brier_improvement,
                    alpha=settings.alpha,
                )
                stability = _regime_stability(
                    frame[frame["asset"] == asset], merged
                )
                tests.append(
                    {
                        "asset": asset,
                        "target": target,
                        "model": model_name,
                        **power,
                        "regime_stability": stability,
                    }
                )
    adjusted = benjamini_hochberg([item["p_value"] for item in tests])
    for item, q_value in zip(tests, adjusted):
        item["q_value_bh"] = q_value
        if q_value <= settings.alpha and item["brier_improvement"] > 0:
            item["multiple_testing_power_conclusion"] = "EDGE_DETECTED_AFTER_BH"
        elif item["adequately_powered_for_required_improvement"]:
            item["multiple_testing_power_conclusion"] = (
                "NO_EDGE_AT_OR_ABOVE_PREDECLARED_THRESHOLD"
            )
        else:
            item["multiple_testing_power_conclusion"] = "INCONCLUSIVE_UNDERPOWERED"

    development_lookup = {
        (item["asset"], item["target"], item["model"]): item for item in development_runs
    }
    test_lookup = {(item["asset"], item["target"], item["model"]): item for item in tests}
    selected: dict[tuple[str, str], str] = {}
    for asset in ("BTC", "ETH"):
        for target in TARGETS:
            eligible = []
            for model_name in ("M1_REGIME", "M2_LOGISTIC"):
                evidence = test_lookup[(asset, target, model_name)]
                metrics = development_lookup[(asset, target, model_name)]["metrics"]
                if (
                    metrics.get("fold_count", 0) >= settings.minimum_oos_folds
                    and evidence["q_value_bh"] <= settings.alpha
                    and evidence["brier_improvement"] >= settings.minimum_simple_brier_improvement
                    and evidence["regime_stability"]["stable"]
                ):
                    eligible.append((metrics["brier"], model_name))
            selected[(asset, target)] = min(eligible)[1] if eligible else "M0_UNCONDITIONAL"

    evaluations: list[dict[str, Any]] = []
    artifacts: dict[tuple[str, str], tuple[object, ProbabilityCalibrator | None, pd.DataFrame]] = {}
    for asset in ("BTC", "ETH"):
        asset_frame = frame[frame["asset"] == asset].sort_values("prediction_time")
        for target, (horizon_steps, _) in TARGETS.items():
            label_end = f"label_end_time_{target}"
            development, calibration, holdout = _split_target_frame(asset_frame, target, settings)
            model_name = selected[(asset, target)]
            model, calibrator, calibration_summary = _fit_before_calibration(
                development, calibration, target, label_end, model_name, settings
            )
            raw = model.predict_proba(holdout)[:, 1]
            probability = calibrator.transform(raw) if calibrator else raw
            actual = holdout[target].astype(int).to_numpy()
            holdout_metrics = {**_probability_metrics(actual, probability), **calibration_metrics(actual, probability)}
            baseline_probability = np.full(len(holdout), calibration_summary["training_base_rate"])
            holdout_power = paired_block_power(
                actual,
                baseline_probability,
                probability,
                block_size=horizon_steps,
                required_improvement=settings.minimum_simple_brier_improvement,
                alpha=settings.alpha,
            )
            effective = effective_sample_size(pd.Series(actual), max_lag=horizon_steps)
            latest = asset_frame.sort_values("prediction_time").iloc[[-1]]
            live_raw = model.predict_proba(latest)[:, 1]
            live_probability = float((calibrator.transform(live_raw) if calibrator else live_raw)[0])
            evaluations.append(
                {
                    "asset": asset,
                    "target": target,
                    "selected_model": model_name,
                    "development": development_lookup[(asset, target, model_name)]["metrics"],
                    "selection_evidence": test_lookup.get((asset, target, model_name)),
                    "calibration": calibration_summary,
                    "holdout": {
                        **holdout_metrics,
                        "sample_count": len(holdout),
                        "effective_sample_count": effective,
                        "base_rate": float(actual.mean()),
                        "baseline_brier": float(brier_score_loss(actual, baseline_probability)),
                        **holdout_power,
                        "start": str(holdout["prediction_time"].min()),
                        "end": str(holdout["prediction_time"].max()),
                    },
                    "latest_prediction_time": str(latest.iloc[0]["prediction_time"]),
                    "latest_research_probability": live_probability,
                    "probability_kind": (
                        "UNCONDITIONAL_BASE_RATE" if model_name == "M0_UNCONDITIONAL" else "CONDITIONAL_RESEARCH"
                    ),
                }
            )
            calibration_table(actual, probability).to_csv(
                output_directory / f"reliability_{asset}_{target}.csv", index=False
            )
            artifacts[(asset, target)] = (model, calibrator, latest)

    conditional_evaluations = [item for item in evaluations if item["selected_model"] != "M0_UNCONDITIONAL"]
    final_adjusted = benjamini_hochberg([item["holdout"]["p_value"] for item in conditional_evaluations])
    for item, q_value in zip(conditional_evaluations, final_adjusted):
        item["holdout"]["q_value_bh"] = q_value
        holdout = item["holdout"]
        if q_value <= settings.alpha and holdout["brier_improvement"] > 0:
            holdout["multiple_testing_power_conclusion"] = "EDGE_DETECTED_AFTER_BH"
        elif holdout["adequately_powered_for_required_improvement"]:
            holdout["multiple_testing_power_conclusion"] = (
                "NO_EDGE_AT_OR_ABOVE_PREDECLARED_THRESHOLD"
            )
        else:
            holdout["multiple_testing_power_conclusion"] = "INCONCLUSIVE_UNDERPOWERED"
    for item in evaluations:
        if item["selected_model"] == "M0_UNCONDITIONAL":
            item["status"] = (
                "VALIDATED_BASE_RATE_ONLY"
                if item["holdout"]["effective_sample_count"] >= settings.minimum_effective_samples
                else "INSUFFICIENT_EFFECTIVE_SAMPLE_FOR_PRECISE_RATE"
            )
            item["precise_conditional_probability_allowed"] = False
        else:
            holdout = item["holdout"]
            accepted = (
                holdout.get("q_value_bh", 1.0) <= settings.alpha
                and holdout["brier_improvement"] > 0
                and holdout["effective_sample_count"] >= settings.minimum_effective_samples
                and holdout["expected_calibration_error"] <= settings.maximum_ece
            )
            item["status"] = "BACKTEST_VALIDATED_FORWARD_PENDING" if accepted else "NO_ROBUST_CONDITIONAL_EDGE"
            item["precise_conditional_probability_allowed"] = bool(accepted)

    for item in evaluations:
        asset, target = item["asset"], item["target"]
        model, calibrator, _ = artifacts[(asset, target)]
        artifact_path = model_directory / f"{asset}_{target}.joblib"
        joblib.dump(
            {
                "model": model,
                "calibrator": calibrator,
                "asset": asset,
                "target": target,
                "feature_columns": MODEL_FEATURES,
                "research_version": research_version,
                "status": item["status"],
            },
            artifact_path,
        )
        experiment_id = experiment_registry.record(
            {
                "code_version": "v1-historical-research",
                "dataset_version": dataset_version,
                "feature_version": "historical-core-v1",
                "model_config": {
                    "selected_model": item["selected_model"],
                    "features": MODEL_FEATURES,
                    "target": target,
                    "anti_overfit": asdict(settings),
                },
                "train_dates": manifest["boundaries"][asset]["history_start"] + " to calibration",
                "validation_dates": str(item["calibration"]),
                "test_dates": item["holdout"]["start"] + " to " + item["holdout"]["end"],
                "random_seed": settings.random_seed,
                "metrics": item,
                "status": item["status"],
            }
        )
        item["experiment_id"] = experiment_id

    result = {
        "research_version": research_version,
        "dataset_version": dataset_version,
        "anti_overfit_protocol": {
            "final_holdout_frozen_before_selection": True,
            "walk_forward_with_purge_and_embargo": True,
            "benjamini_hochberg": True,
            "complex_model": "REJECTED_FROM_PRODUCTION_WITHOUT_FORWARD_EVIDENCE",
        },
        "evaluations": evaluations,
        "development_multiple_tests": tests,
    }
    (output_directory / "summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, default=str), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "asset": item["asset"],
                "target": item["target"],
                "selected_model": item["selected_model"],
                "status": item["status"],
                "holdout_brier": item["holdout"]["brier"],
                "holdout_log_loss": item["holdout"]["log_loss"],
                "holdout_ece": item["holdout"]["expected_calibration_error"],
                "holdout_base_rate": item["holdout"]["base_rate"],
                "holdout_effective_samples": item["holdout"]["effective_sample_count"],
                "latest_research_probability": item["latest_research_probability"],
                "probability_kind": item["probability_kind"],
            }
            for item in evaluations
        ]
    ).to_csv(output_directory / "summary.csv", index=False)
    latest_pointer = {
        "research_version": research_version,
        "summary_path": str((output_directory / "summary.json").resolve()),
        "model_directory": str(model_directory.resolve()),
    }
    Path(output_root).mkdir(parents=True, exist_ok=True)
    (Path(output_root) / "latest.json").write_text(
        json.dumps(latest_pointer, indent=2, sort_keys=True), encoding="utf-8"
    )
    return result
