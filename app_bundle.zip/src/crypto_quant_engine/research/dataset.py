from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..features.common import causal_zscore
from ..features.volatility import add_realized_volatility
from ..regimes.engine import classify_regimes


TARGETS = {
    "up_4h": (16, "forward_return_4h"),
    "up_24h": (96, "forward_return_24h"),
    "up_72h": (288, "forward_return_72h"),
    "up_7d": (672, "forward_return_7d"),
    "first_touch_plus_3_before_minus_3_72h": (288, "first_touch_return_3_72h"),
}

FEATURE_FAMILIES = {
    "PRICE_TREND": ["return_1h", "return_4h", "return_24h"],
    "SPOT": ["spot_flow_z", "spot_volume_z", "spot_buy_sell_imbalance"],
    "PERPS": ["perp_flow_z", "funding_z", "basis_z", "absorption_score"],
    "VOLATILITY": ["realized_volatility_96_z", "realized_volatility_672_z"],
    "RELATIVE": ["eth_btc_return_24h"],
}
MODEL_FEATURES = [feature for family in FEATURE_FAMILIES.values() for feature in family]


def _value(frame: pd.DataFrame, name: str) -> pd.Series:
    column = f"value.{name}"
    if column in frame:
        return pd.to_numeric(frame[column], errors="coerce")
    return pd.Series(np.nan, index=frame.index, dtype=float)


def _last_historical_bar(observations: pd.DataFrame, family: str) -> pd.DataFrame:
    frame = observations[observations["data_family"] == family].copy()
    if frame.empty:
        return frame
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    # Normal completed bars become available exactly on the next 15-minute
    # boundary. Rare exchange-maintenance candles can close early; conservatively
    # defer those bars to the following boundary instead of leaking them into the
    # bucket that began before their actual availability.
    frame["prediction_time"] = frame["available_time"].dt.ceil("15min")
    return frame.sort_values("available_time").drop_duplicates(
        ["asset", "prediction_time", "source", "instrument"], keep="last"
    )


def _causal_group_z(frame: pd.DataFrame, column: str, window: int = 96, min_periods: int = 32) -> pd.Series:
    return frame.groupby("asset", group_keys=False)[column].transform(
        lambda series: causal_zscore(series, window=window, min_periods=min_periods)
    )


def _add_fixed_horizon_labels(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.sort_values(["asset", "prediction_time"]).copy()
    grouped_price = result.groupby("asset")["spot_price"]
    grouped_time = result.groupby("asset")["prediction_time"]
    for target_name, (steps, return_column) in TARGETS.items():
        if target_name.startswith("first_touch"):
            continue
        future_price = grouped_price.shift(-steps)
        future_time = grouped_time.shift(-steps)
        expected = pd.to_timedelta(steps * 15, unit="min")
        exact = future_time - result["prediction_time"] == expected
        result[return_column] = (future_price / result["spot_price"] - 1).where(exact)
        result[target_name] = result[return_column].gt(0).astype(float).where(result[return_column].notna())
        result[f"label_end_time_{target_name}"] = future_time.where(exact)
    return result


def _add_path_labels(frame: pd.DataFrame, steps: int = 288, threshold: float = 0.03) -> pd.DataFrame:
    result = frame.copy()
    target_column = "first_touch_plus_3_before_minus_3_72h"
    result[target_column] = np.nan
    result["first_touch_return_3_72h"] = np.nan
    result[f"label_end_time_{target_column}"] = pd.Series(pd.NaT, index=result.index, dtype="datetime64[ns, UTC]")
    result["mae_72h"] = np.nan
    result["mfe_72h"] = np.nan

    for _, group in result.groupby("asset", sort=False):
        indices = group.index.to_numpy()
        prices = group["spot_price"].to_numpy(dtype=float)
        times = pd.to_datetime(group["prediction_time"], utc=True).to_numpy(dtype="datetime64[ns]")
        valid_count = max(0, len(group) - steps)
        if valid_count == 0:
            continue
        windows = np.lib.stride_tricks.sliding_window_view(prices[1:], steps)
        end_times = times[steps:]
        exact = end_times - times[:valid_count] == np.timedelta64(steps * 15, "m")
        labels = np.full(valid_count, np.nan)
        mae = np.full(valid_count, np.nan)
        mfe = np.full(valid_count, np.nan)
        chunk_size = 4_000
        for start in range(0, valid_count, chunk_size):
            stop = min(valid_count, start + chunk_size)
            paths = windows[start:stop] / prices[start:stop, None] - 1
            mae[start:stop] = np.minimum(0.0, np.nanmin(paths, axis=1))
            mfe[start:stop] = np.maximum(0.0, np.nanmax(paths, axis=1))
            up = paths >= threshold
            down = paths <= -threshold
            has_up = up.any(axis=1)
            has_down = down.any(axis=1)
            first_up = np.where(has_up, up.argmax(axis=1), steps + 1)
            first_down = np.where(has_down, down.argmax(axis=1), steps + 1)
            resolved = has_up | has_down
            labels[start:stop] = np.where(resolved, (first_up < first_down).astype(float), np.nan)
        labels[~exact] = np.nan
        mae[~exact] = np.nan
        mfe[~exact] = np.nan
        valid_indices = indices[:valid_count]
        result.loc[valid_indices, target_column] = labels
        result.loc[valid_indices, "first_touch_return_3_72h"] = labels
        result.loc[valid_indices, "mae_72h"] = mae
        result.loc[valid_indices, "mfe_72h"] = mfe
        exact_indices = valid_indices[exact]
        result.loc[exact_indices, f"label_end_time_{target_column}"] = pd.to_datetime(end_times[exact], utc=True)
    return result


def build_historical_research_dataset(observations: pd.DataFrame) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    if "meta.backtest_eligible" in observations:
        eligible = observations["meta.backtest_eligible"].fillna(False).astype(bool)
        observations = observations[eligible].copy()
    spot = _last_historical_bar(observations, "SPOT")
    perps = _last_historical_bar(observations, "PERPS")
    if spot.empty or perps.empty:
        raise ValueError("historical research requires aligned SPOT and PERPS bars")

    spot_block = spot[["asset", "prediction_time", "available_time"]].rename(
        columns={"available_time": "spot_available_time"}
    )
    spot_block["spot_price"] = _value(spot, "mid_price").fillna(_value(spot, "close")).to_numpy()
    spot_block["spot_volume"] = _value(spot, "trade_volume_base").fillna(_value(spot, "volume_base")).to_numpy()
    spot_block["spot_flow_delta"] = (
        _value(spot, "aggressive_buy_volume_base") - _value(spot, "aggressive_sell_volume_base")
    ).to_numpy()
    spot_block["spot_buy_sell_imbalance"] = spot_block["spot_flow_delta"] / spot_block["spot_volume"].replace(0, np.nan)

    perp_block = perps[["asset", "prediction_time", "available_time"]].rename(
        columns={"available_time": "perp_available_time"}
    )
    perp_block["perp_price"] = _value(perps, "perpetual_price").fillna(_value(perps, "close")).to_numpy()
    perp_block["perp_volume"] = _value(perps, "volume_base").to_numpy()
    perp_block["perp_flow_delta"] = (
        _value(perps, "aggressive_buy_volume_base") - _value(perps, "aggressive_sell_volume_base")
    ).to_numpy()
    perp_block["oi_weighted_funding"] = _value(perps, "funding_rate").to_numpy()

    result = spot_block.merge(perp_block, on=["asset", "prediction_time"], how="inner", validate="one_to_one")
    result["feature_available_time"] = result[["spot_available_time", "perp_available_time"]].max(axis=1)
    if (pd.to_datetime(result["feature_available_time"], utc=True) > result["prediction_time"]).any():
        raise ValueError("historical feature availability exceeds prediction time")
    result = result.sort_values(["asset", "prediction_time"]).reset_index(drop=True)
    result["oi_weighted_basis"] = result["perp_price"] / result["spot_price"] - 1
    result["spot_cvd_aggregate"] = result.groupby("asset")["spot_flow_delta"].cumsum()
    result["perp_cvd_aggregate"] = result.groupby("asset")["perp_flow_delta"].cumsum()
    result["spot_flow_z"] = _causal_group_z(result, "spot_flow_delta")
    result["spot_volume_z"] = _causal_group_z(result, "spot_volume")
    result["perp_flow_z"] = _causal_group_z(result, "perp_flow_delta")
    result["funding_z"] = _causal_group_z(result, "oi_weighted_funding", window=672, min_periods=96)
    result["basis_z"] = _causal_group_z(result, "oi_weighted_basis")
    result["absorption_score"] = result["spot_flow_z"] - result["perp_flow_z"]
    result["delta_open_interest_notional_usd"] = np.nan
    result["oi_change_z"] = np.nan
    result["skew_30d"] = np.nan

    grouped_price = result.groupby("asset")["spot_price"]
    for name, periods in (("1h", 4), ("4h", 16), ("24h", 96)):
        result[f"return_{name}"] = grouped_price.pct_change(periods, fill_method=None)

    ratios = result.pivot(index="prediction_time", columns="asset", values="spot_price")
    if {"BTC", "ETH"}.issubset(ratios.columns):
        relative = (ratios["ETH"] / ratios["BTC"]).rename("eth_btc")
        result = result.merge(relative, left_on="prediction_time", right_index=True, how="left")
        result["eth_btc_return_24h"] = result.groupby("asset")["eth_btc"].pct_change(96, fill_method=None)
    else:
        result["eth_btc"] = np.nan
        result["eth_btc_return_24h"] = np.nan

    result = add_realized_volatility(result)
    result = classify_regimes(result)
    result = _add_fixed_horizon_labels(result)
    result = _add_path_labels(result)
    result["historical_gap_minutes"] = result.groupby("asset")["prediction_time"].diff().dt.total_seconds() / 60
    return result.sort_values(["asset", "prediction_time"]).reset_index(drop=True)


def write_research_dataset(
    frame: pd.DataFrame,
    root: str | Path,
    version: str,
    metadata: dict[str, object] | None = None,
) -> tuple[Path, str]:
    directory = Path(root) / version
    directory.mkdir(parents=True, exist_ok=True)
    data_path = directory / "dataset.csv.gz"
    metadata_path = directory / "metadata.json"
    if data_path.exists() or metadata_path.exists():
        raise FileExistsError(f"research dataset version already exists: {version}")
    frame.to_csv(data_path, index=False, compression="gzip")
    digest = hashlib.sha256(data_path.read_bytes()).hexdigest()
    gaps = frame.loc[frame["historical_gap_minutes"].gt(15.0), "historical_gap_minutes"]
    document = {
        "dataset_version": version,
        "sha256": digest,
        "row_count": len(frame),
        "assets": sorted(frame["asset"].dropna().unique().tolist()),
        "start": str(frame["prediction_time"].min()),
        "end": str(frame["prediction_time"].max()),
        "maximum_gap_minutes": float(gaps.max()) if not gaps.empty else 15.0,
        "gap_count_over_15_minutes": int(len(gaps)),
        "point_in_time": True,
        "historical_families": ["SPOT", "PERPS"],
        "excluded_unavailable_families": ["OPTIONS", "ETF", "CME", "MACRO_VINTAGES"],
        **(metadata or {}),
    }
    metadata_path.write_text(json.dumps(document, indent=2, sort_keys=True), encoding="utf-8")
    return data_path, digest
