from __future__ import annotations

from dataclasses import asdict, dataclass

import pandas as pd


@dataclass(frozen=True)
class AssetReadiness:
    asset: str
    history_days: float
    canonical_buckets: int
    family_buckets: dict[str, int]
    source_count: int
    ready_for_model_research: bool
    blockers: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def assess_backtest_readiness(
    observations: pd.DataFrame,
    *,
    minimum_history_days: int = 180,
    minimum_canonical_buckets: int = 17_520,
    required_families: tuple[str, ...] = ("SPOT", "PERPS", "OPTIONS"),
) -> list[AssetReadiness]:
    if observations.empty:
        return [
            AssetReadiness(
                asset=asset,
                history_days=0.0,
                canonical_buckets=0,
                family_buckets={family: 0 for family in required_families},
                source_count=0,
                ready_for_model_research=False,
                blockers=("NO_POINT_IN_TIME_HISTORY",),
            )
            for asset in ("BTC", "ETH")
        ]
    frame = observations[observations["asset"].isin(("BTC", "ETH"))].copy()
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame["bucket"] = frame["available_time"].dt.floor("15min")
    reports: list[AssetReadiness] = []
    for asset in ("BTC", "ETH"):
        sample = frame[frame["asset"] == asset]
        if sample.empty:
            reports.append(
                AssetReadiness(
                    asset,
                    0.0,
                    0,
                    {family: 0 for family in required_families},
                    0,
                    False,
                    ("NO_POINT_IN_TIME_HISTORY",),
                )
            )
            continue
        history_days = (sample["available_time"].max() - sample["available_time"].min()).total_seconds() / 86400
        family_buckets = {
            family: int(sample.loc[sample["data_family"] == family, "bucket"].nunique())
            for family in required_families
        }
        canonical_buckets = min(family_buckets.values()) if family_buckets else 0
        blockers: list[str] = []
        if history_days < minimum_history_days:
            blockers.append("HISTORY_SHORTER_THAN_MINIMUM")
        if canonical_buckets < minimum_canonical_buckets:
            blockers.append("INSUFFICIENT_CANONICAL_BUCKETS")
        missing = [family for family, count in family_buckets.items() if count == 0]
        if missing:
            blockers.append("MISSING_FAMILIES:" + ",".join(missing))
        reports.append(
            AssetReadiness(
                asset=asset,
                history_days=round(history_days, 3),
                canonical_buckets=canonical_buckets,
                family_buckets=family_buckets,
                source_count=int(sample["source"].nunique()),
                ready_for_model_research=not blockers,
                blockers=tuple(blockers),
            )
        )
    return reports


def assess_backtest_readiness_statistics(
    statistics: dict[str, dict[str, object]],
    *,
    minimum_history_days: int = 180,
    minimum_canonical_buckets: int = 17_520,
    required_families: tuple[str, ...] = ("SPOT", "PERPS", "OPTIONS"),
) -> list[AssetReadiness]:
    """Build readiness reports from bounded-memory storage aggregates."""

    reports: list[AssetReadiness] = []
    for asset in ("BTC", "ETH"):
        sample = statistics.get(asset, {})
        history_start = sample.get("history_start")
        history_end = sample.get("history_end")
        source_count = int(sample.get("source_count", 0))
        raw_family_buckets = sample.get("family_buckets", {})
        if not isinstance(raw_family_buckets, dict):
            raw_family_buckets = {}
        family_buckets = {
            family: int(raw_family_buckets.get(family, 0))
            for family in required_families
        }
        if history_start is None or history_end is None:
            reports.append(
                AssetReadiness(
                    asset=asset,
                    history_days=0.0,
                    canonical_buckets=0,
                    family_buckets=family_buckets,
                    source_count=0,
                    ready_for_model_research=False,
                    blockers=("NO_POINT_IN_TIME_HISTORY",),
                )
            )
            continue

        start = pd.Timestamp(history_start)
        end = pd.Timestamp(history_end)
        history_days = (end - start).total_seconds() / 86400
        canonical_buckets = min(family_buckets.values()) if family_buckets else 0
        blockers: list[str] = []
        if history_days < minimum_history_days:
            blockers.append("HISTORY_SHORTER_THAN_MINIMUM")
        if canonical_buckets < minimum_canonical_buckets:
            blockers.append("INSUFFICIENT_CANONICAL_BUCKETS")
        missing = [family for family, count in family_buckets.items() if count == 0]
        if missing:
            blockers.append("MISSING_FAMILIES:" + ",".join(missing))
        reports.append(
            AssetReadiness(
                asset=asset,
                history_days=round(history_days, 3),
                canonical_buckets=canonical_buckets,
                family_buckets=family_buckets,
                source_count=source_count,
                ready_for_model_research=not blockers,
                blockers=tuple(blockers),
            )
        )
    return reports
