from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class SimulationSummary:
    terminal_quantiles: dict[str, float]
    drawdown_quantiles: dict[str, float]
    expected_mae: float
    expected_mfe: float
    probability_up_before_down: float
    path_count: int
    regime_sample_count: int


class ConditionalBlockBootstrap:
    """Empirical, regime-conditioned bootstrap preserving local serial dependence."""

    def __init__(self, block_size: int = 8, random_seed: int = 20260825) -> None:
        if block_size <= 0:
            raise ValueError("block_size must be positive")
        self.block_size = block_size
        self.rng = np.random.default_rng(random_seed)

    def simulate(
        self,
        returns: pd.Series,
        steps: int,
        path_count: int = 10_000,
        upside: float = 0.03,
        downside: float = 0.03,
        minimum_samples: int = 200,
    ) -> tuple[np.ndarray, SimulationSummary]:
        sample = returns.dropna().to_numpy(dtype=float)
        if len(sample) < minimum_samples:
            raise ValueError(f"insufficient regime-conditioned returns: {len(sample)} < {minimum_samples}")
        if steps <= 0 or path_count <= 0:
            raise ValueError("steps and path_count must be positive")
        blocks_needed = int(np.ceil(steps / self.block_size))
        max_start = len(sample) - self.block_size
        if max_start < 0:
            raise ValueError("sample is shorter than block size")
        starts = self.rng.integers(0, max_start + 1, size=(path_count, blocks_needed))
        simulated_returns = np.empty((path_count, blocks_needed * self.block_size))
        offsets = np.arange(self.block_size)
        for block in range(blocks_needed):
            simulated_returns[:, block * self.block_size : (block + 1) * self.block_size] = sample[
                starts[:, block, None] + offsets
            ]
        simulated_returns = simulated_returns[:, :steps]
        paths = np.cumprod(1 + simulated_returns, axis=1) - 1
        running_peak = np.maximum.accumulate(1 + paths, axis=1)
        drawdowns = (1 + paths) / running_peak - 1
        up_hit = paths >= upside
        down_hit = paths <= -downside
        up_first = np.where(up_hit.any(axis=1), up_hit.argmax(axis=1), steps + 1)
        down_first = np.where(down_hit.any(axis=1), down_hit.argmax(axis=1), steps + 1)
        summary = SimulationSummary(
            terminal_quantiles={str(q): float(np.quantile(paths[:, -1], q)) for q in (0.05, 0.25, 0.5, 0.75, 0.95)},
            drawdown_quantiles={str(q): float(np.quantile(drawdowns.min(axis=1), q)) for q in (0.05, 0.5, 0.95)},
            expected_mae=float(paths.min(axis=1).mean()),
            expected_mfe=float(paths.max(axis=1).mean()),
            probability_up_before_down=float(np.mean(up_first < down_first)),
            path_count=path_count,
            regime_sample_count=len(sample),
        )
        return paths, summary

