from __future__ import annotations

import numpy as np
import pandas as pd


def column(frame: pd.DataFrame, name: str) -> pd.Series:
    for candidate in (name, f"value.{name}"):
        if candidate in frame:
            return frame[candidate]
    return pd.Series(np.nan, index=frame.index, dtype=float)


def causal_zscore(series: pd.Series, window: int = 96, min_periods: int = 32) -> pd.Series:
    """Standardize against strictly prior observations, never future or current rows."""
    history = series.shift(1)
    mean = history.rolling(window, min_periods=min_periods).mean()
    standard_deviation = history.rolling(window, min_periods=min_periods).std(ddof=1)
    return (series - mean) / standard_deviation.replace(0, np.nan)


def safe_ratio(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    return numerator / denominator.replace(0, np.nan)


def weighted_average(values: pd.Series, weights: pd.Series) -> float:
    mask = values.notna() & weights.notna() & (weights > 0)
    if not mask.any():
        return float("nan")
    return float(np.average(values[mask], weights=weights[mask]))


def canonical_bucket(frame: pd.DataFrame, frequency: str = "15min") -> pd.Series:
    return pd.to_datetime(frame["available_time"], utc=True).dt.floor(frequency)


def assert_point_in_time(frame: pd.DataFrame) -> None:
    if {"feature_available_time", "prediction_time"}.issubset(frame.columns):
        unavailable = pd.to_datetime(frame["feature_available_time"], utc=True) > pd.to_datetime(
            frame["prediction_time"], utc=True
        )
        if unavailable.any():
            raise ValueError(f"point-in-time violation in {int(unavailable.sum())} feature rows")

