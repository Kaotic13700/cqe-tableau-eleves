from __future__ import annotations

import numpy as np
import pandas as pd

from .common import canonical_bucket, causal_zscore, column, safe_ratio, weighted_average


def build_spot_features(
    observations: pd.DataFrame,
    exchange_weights: dict[str, float] | None = None,
    frequency: str = "15min",
    z_window: int = 96,
    min_periods: int = 32,
) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    frame = frame.sort_values("available_time").drop_duplicates(
        ["asset", "bucket", "source", "instrument"], keep="last"
    )
    weights = exchange_weights or {}
    frame["quality_weight"] = frame["source"].map(weights).fillna(0.5)
    flow_declared_safe = column(frame, "trade_flow_deduplicated").eq(True)
    flow_interval_eligible = column(frame, "trade_flow_interval_eligible").eq(True)
    flow_gap = column(frame, "trade_gap_detected").eq(True)
    frame["flow_safe"] = flow_declared_safe & flow_interval_eligible & ~flow_gap
    frame["flow_delta"] = column(frame, "aggressive_buy_volume_base").astype(float) - column(
        frame, "aggressive_sell_volume_base"
    ).astype(float)
    frame["flow_delta"] = frame["flow_delta"].where(frame["flow_safe"])
    frame["volume"] = column(frame, "trade_volume_base").astype(float)
    frame["flow_volume"] = frame["volume"].where(frame["flow_safe"])
    frame["mid"] = column(frame, "mid_price").astype(float)
    frame["spread"] = column(frame, "spread").astype(float)
    frame["bid_depth"] = column(frame, "bid_depth_notional").astype(float)
    frame["ask_depth"] = column(frame, "ask_depth_notional").astype(float)

    rows: list[dict[str, object]] = []
    for (asset, bucket), group in frame.groupby(["asset", "bucket"], sort=True):
        relevance = group["quality_weight"] * group["volume"].clip(lower=0).fillna(0)
        if relevance.sum() <= 0:
            relevance = group["quality_weight"]
        bid_depth = group["bid_depth"].sum(min_count=1)
        ask_depth = group["ask_depth"].sum(min_count=1)
        rows.append(
            {
                "asset": asset,
                "prediction_time": bucket,
                "feature_available_time": group["available_time"].max(),
                "spot_price": weighted_average(group["mid"], relevance),
                "spot_flow_delta": weighted_average(group["flow_delta"], relevance),
                "spot_volume": group["volume"].sum(min_count=1),
                "spot_spread": weighted_average(group["spread"], relevance),
                "spot_order_book_imbalance": (bid_depth - ask_depth) / (bid_depth + ask_depth)
                if pd.notna(bid_depth) and pd.notna(ask_depth) and bid_depth + ask_depth
                else np.nan,
                "spot_buy_sell_imbalance": safe_ratio(
                    pd.Series([group["flow_delta"].sum(min_count=1)]),
                    pd.Series([group["flow_volume"].sum(min_count=1)]),
                ).iloc[0],
                "spot_exchange_coverage": int(group["source"].nunique()),
                "spot_flow_exchange_coverage": int(group.loc[group["flow_safe"], "source"].nunique()),
                "spot_flow_cursor_safe": bool(group["flow_safe"].any()),
                "spot_information_age_seconds": group["information_age_seconds"].max(),
            }
        )
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    grouped = result.groupby("asset", group_keys=False)
    result["spot_cvd_aggregate"] = grouped["spot_flow_delta"].cumsum()
    result["spot_flow_z"] = grouped["spot_flow_delta"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["spot_volume_z"] = grouped["spot_volume"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["spot_spread_z"] = grouped["spot_spread"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    return result.reset_index(drop=True)
