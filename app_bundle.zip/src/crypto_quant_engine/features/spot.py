from __future__ import annotations

import numpy as np
import pandas as pd

from .common import canonical_bucket, causal_zscore, column, safe_ratio, weighted_average


def build_spot_features(
    observations: pd.DataFrame,
    exchange_weights: dict[str, float] | None = None,
    frequency: str = "15min",
    z_window: int = 96,
    min_periods: int = 32,
) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    weights = exchange_weights or {}
    frame["quality_weight"] = frame["source"].map(weights).fillna(0.5)
    flow_declared_safe = column(frame, "trade_flow_deduplicated").eq(True)
    flow_interval_eligible = column(frame, "trade_flow_interval_eligible").eq(True)
    flow_gap = column(frame, "trade_gap_detected").eq(True)
    historical_eligible = (
        frame["meta.backtest_eligible"].eq(True)
        if "meta.backtest_eligible" in frame
        else pd.Series(False, index=frame.index)
    )
    historical_interval = (
        frame["meta.interval"].fillna("").astype(str).str.lower().eq("15m")
        if "meta.interval" in frame
        else pd.Series(False, index=frame.index)
    )
    historical_flow_complete = (
        column(frame, "aggressive_buy_volume_base").notna()
        & column(frame, "aggressive_sell_volume_base").notna()
        & column(frame, "trade_volume_base").notna()
    )
    frame["flow_safe"] = (
        (flow_declared_safe & flow_interval_eligible & ~flow_gap)
        | (historical_eligible & historical_interval & historical_flow_complete)
    )
    frame["flow_delta"] = column(frame, "aggressive_buy_volume_base").astype(float) - column(
        frame, "aggressive_sell_volume_base"
    ).astype(float)
    frame["flow_delta"] = frame["flow_delta"].where(frame["flow_safe"])
    frame["volume"] = column(frame, "trade_volume_base").astype(float)
    frame["flow_volume"] = frame["volume"].where(frame["flow_safe"])
    frame["mid"] = column(frame, "mid_price").astype(float)
    frame["spread"] = column(frame, "spread").astype(float)
    frame["bid_depth"] = column(frame, "bid_depth_notional").astype(float)
    frame["ask_depth"] = column(frame, "ask_depth_notional").astype(float)

    # A completed historical 15-minute bar can safely restore aggressor flow
    # after a hosted sleep, while a newer observation carries the current order
    # book. The most recent completed bar may belong to the immediately preceding
    # bucket; accept it for at most 20 minutes and expose its actual availability.
    # This is a causal lagged feature, never a fabricated current trade stream.
    keys = ["asset", "bucket", "source", "instrument"]
    latest = frame.sort_values("available_time").drop_duplicates(keys, keep="last")
    identity = ["asset", "source", "instrument"]
    safe_flow = (
        frame[frame["flow_safe"]]
        .sort_values("available_time")
        .drop_duplicates(identity + ["available_time"], keep="last")
        [identity + ["bucket", "flow_delta", "flow_volume", "available_time"]]
        .rename(
            columns={
                "bucket": "recovered_flow_bucket",
                "flow_delta": "recovered_flow_delta",
                "flow_volume": "recovered_flow_volume",
                "available_time": "recovered_flow_available_time",
            }
        )
    )
    latest["_recovery_available_time"] = pd.to_datetime(latest["available_time"], utc=True)
    safe_flow["recovered_flow_available_time"] = pd.to_datetime(
        safe_flow["recovered_flow_available_time"], utc=True
    )
    frame = pd.merge_asof(
        latest.sort_values("_recovery_available_time"),
        safe_flow.sort_values("recovered_flow_available_time"),
        left_on="_recovery_available_time",
        right_on="recovered_flow_available_time",
        by=identity,
        direction="backward",
        tolerance=pd.Timedelta(20, unit="min"),
    )
    causal_recovery = (
        ~frame["flow_safe"]
        & frame["recovered_flow_delta"].notna()
        & (frame["recovered_flow_available_time"] <= frame["_recovery_available_time"])
        & (frame["recovered_flow_bucket"] <= frame["bucket"])
        & (frame["recovered_flow_bucket"] >= frame["bucket"] - pd.Timedelta(15, unit="min"))
    )
    frame.loc[causal_recovery, "flow_delta"] = frame.loc[
        causal_recovery, "recovered_flow_delta"
    ]
    frame.loc[causal_recovery, "flow_volume"] = frame.loc[
        causal_recovery, "recovered_flow_volume"
    ]
    frame.loc[causal_recovery, "flow_safe"] = True
    frame = frame.drop(
        columns=[
            "recovered_flow_delta",
            "recovered_flow_volume",
            "recovered_flow_available_time",
            "recovered_flow_bucket",
            "_recovery_available_time",
        ]
    )

    rows: list[dict[str, object]] = []
    for (asset, bucket), group in frame.groupby(["asset", "bucket"], sort=True):
        relevance = group["quality_weight"] * group["volume"].clip(lower=0).fillna(0)
        if relevance.sum() <= 0:
            relevance = group["quality_weight"]
        bid_depth = group["bid_depth"].sum(min_count=1)
        ask_depth = group["ask_depth"].sum(min_count=1)
        rows.append(
            {
                "asset": asset,
                "prediction_time": bucket,
                "feature_available_time": group["available_time"].max(),
                "spot_price": weighted_average(group["mid"], relevance),
                "spot_flow_delta": weighted_average(group["flow_delta"], relevance),
                "spot_volume": group["volume"].sum(min_count=1),
                "spot_spread": weighted_average(group["spread"], relevance),
                "spot_order_book_imbalance": (bid_depth - ask_depth) / (bid_depth + ask_depth)
                if pd.notna(bid_depth) and pd.notna(ask_depth) and bid_depth + ask_depth
                else np.nan,
                "spot_buy_sell_imbalance": safe_ratio(
                    pd.Series([group["flow_delta"].sum(min_count=1)]),
                    pd.Series([group["flow_volume"].sum(min_count=1)]),
                ).iloc[0],
                "spot_exchange_coverage": int(group["source"].nunique()),
                "spot_flow_exchange_coverage": int(group.loc[group["flow_safe"], "source"].nunique()),
                "spot_flow_cursor_safe": bool(group["flow_safe"].any()),
                "spot_information_age_seconds": group["information_age_seconds"].max(),
            }
        )
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    grouped = result.groupby("asset", group_keys=False)
    result["spot_cvd_aggregate"] = grouped["spot_flow_delta"].cumsum()
    result["spot_flow_z"] = grouped["spot_flow_delta"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["spot_volume_z"] = grouped["spot_volume"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["spot_spread_z"] = grouped["spot_spread"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    return result.reset_index(drop=True)
