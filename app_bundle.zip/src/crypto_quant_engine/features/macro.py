from __future__ import annotations

import numpy as np
import pandas as pd

from .common import causal_zscore, column


def build_macro_features(observations: pd.DataFrame) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy().sort_values(["instrument", "available_time"])
    frame["macro_value"] = pd.to_numeric(column(frame, "value"), errors="coerce")
    frame["vintage_safe"] = frame.get("meta.vintage_safe", False)
    frame["macro_change"] = frame.groupby("instrument")["macro_value"].diff()
    frame["macro_change_z"] = frame.groupby("instrument")["macro_change"].transform(
        lambda values: causal_zscore(values, window=36, min_periods=12)
    )
    return frame[
        [
            "instrument",
            "event_time",
            "available_time",
            "macro_value",
            "macro_change",
            "macro_change_z",
            "vintage_safe",
        ]
    ].reset_index(drop=True)


def macro_surprise(actual: pd.Series, consensus: pd.Series, historical_std: pd.Series) -> pd.Series:
    return (actual - consensus) / historical_std.replace(0, np.nan)

