from __future__ import annotations

import numpy as np
import pandas as pd

from .common import column


def build_cme_basis_features(observations: pd.DataFrame) -> pd.DataFrame:
    """Provider-neutral licensed-feed path; no website scraping is performed."""
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy().sort_values(["asset", "available_time"])
    futures_price = pd.to_numeric(column(frame, "futures_price"), errors="coerce")
    reference_price = pd.to_numeric(column(frame, "reference_spot_price"), errors="coerce")
    basis = pd.to_numeric(column(frame, "basis_fraction"), errors="coerce")
    basis = basis.fillna(futures_price / reference_price.replace(0, np.nan) - 1)
    days = pd.to_numeric(column(frame, "days_to_expiry"), errors="coerce")
    frame["cme_futures_price"] = futures_price
    frame["cme_reference_spot_price"] = reference_price
    frame["cme_basis_fraction"] = basis
    frame["cme_basis_annualized"] = basis * 365.25 / days.replace(0, np.nan)
    frame["cme_days_to_expiry"] = days
    frame["cme_information_age_seconds"] = pd.to_numeric(
        frame.get("information_age_seconds", pd.Series(np.nan, index=frame.index)), errors="coerce"
    )
    frame["cme_backtest_eligible"] = frame.get("meta.backtest_eligible", False)
    frame["prediction_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame["feature_available_time"] = frame["prediction_time"]
    return frame[
        [
            "asset",
            "prediction_time",
            "feature_available_time",
            "cme_futures_price",
            "cme_reference_spot_price",
            "cme_basis_fraction",
            "cme_basis_annualized",
            "cme_days_to_expiry",
            "cme_information_age_seconds",
            "cme_backtest_eligible",
        ]
    ].reset_index(drop=True)
