from __future__ import annotations

import numpy as np
import pandas as pd

from .common import canonical_bucket, causal_zscore, column, weighted_average


def build_perp_features(
    observations: pd.DataFrame,
    exchange_weights: dict[str, float] | None = None,
    frequency: str = "15min",
    z_window: int = 96,
    min_periods: int = 32,
) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    frame = frame.sort_values("available_time").drop_duplicates(
        ["asset", "bucket", "source", "instrument"], keep="last"
    )
    weights = exchange_weights or {}
    source_aliases = {
        "binance_futures": "binance",
        "okx_perps": "okx",
        "hyperliquid_perps": "hyperliquid",
    }
    frame["quality_weight"] = frame["source"].map(
        lambda source: weights.get(source, weights.get(source_aliases.get(str(source), ""), 0.5))
    )
    venue_fallback = frame["source"].map(lambda source: "DEX" if source == "hyperliquid_perps" else "CEX")
    frame["venue_type"] = (
        frame["meta.venue_type"].fillna(venue_fallback).astype("string")
        if "meta.venue_type" in frame
        else venue_fallback.astype("string")
    )
    frame["oi_notional"] = column(frame, "open_interest_notional_usd").astype(float)
    frame["funding"] = column(frame, "funding_rate").astype(float)
    frame["basis"] = column(frame, "basis_fraction").astype(float)
    frame["perp_price"] = column(frame, "perpetual_price").astype(float)
    frame["volume"] = column(frame, "volume_base").astype(float)
    frame["volume_24h_usd"] = column(frame, "volume_24h_usd").astype(float)
    flow_declared_safe = column(frame, "trade_flow_deduplicated").eq(True)
    flow_interval_eligible = column(frame, "trade_flow_interval_eligible").eq(True)
    flow_gap = column(frame, "trade_gap_detected").eq(True)
    frame["flow_safe"] = flow_declared_safe & flow_interval_eligible & ~flow_gap
    frame["flow_delta"] = column(frame, "aggressive_buy_volume_base").astype(float) - column(
        frame, "aggressive_sell_volume_base"
    ).astype(float)
    frame["flow_delta"] = frame["flow_delta"].where(frame["flow_safe"])

    rows: list[dict[str, object]] = []
    for (asset, bucket), group in frame.groupby(["asset", "bucket"], sort=True):
        oi_weights = group["oi_notional"].clip(lower=0) * group["quality_weight"]
        relevance = oi_weights
        if relevance.fillna(0).sum() <= 0:
            relevance = group["volume"].clip(lower=0) * group["quality_weight"]
        if relevance.fillna(0).sum() <= 0:
            relevance = group["quality_weight"]
        cex = group[group["venue_type"].str.upper() == "CEX"]
        cex_relevance = cex["oi_notional"].clip(lower=0) * cex["quality_weight"]
        if cex_relevance.fillna(0).sum() <= 0:
            cex_relevance = cex["volume"].clip(lower=0) * cex["quality_weight"]
        if cex_relevance.fillna(0).sum() <= 0:
            cex_relevance = cex["quality_weight"]
        dex = group[group["venue_type"].str.upper() == "DEX"]
        dex_relevance = dex["oi_notional"].clip(lower=0) * dex["quality_weight"]
        if dex_relevance.fillna(0).sum() <= 0:
            dex_relevance = dex["volume"].clip(lower=0) * dex["quality_weight"]
        if dex_relevance.fillna(0).sum() <= 0:
            dex_relevance = dex["quality_weight"]
        rows.append(
            {
                "asset": asset,
                "prediction_time": bucket,
                "feature_available_time": group["available_time"].max(),
                "perp_price": weighted_average(group["perp_price"], relevance),
                "open_interest_notional_usd": group["oi_notional"].sum(min_count=1),
                "oi_weighted_funding": weighted_average(group["funding"], relevance),
                "oi_weighted_basis": weighted_average(group["basis"], relevance),
                "perp_flow_delta": weighted_average(group["flow_delta"], relevance),
                "long_liquidations_notional_usd": column(group, "long_liquidations_notional_usd").sum(min_count=1),
                "short_liquidations_notional_usd": column(group, "short_liquidations_notional_usd").sum(min_count=1),
                "perp_exchange_coverage": int(group["source"].nunique()),
                "perp_flow_exchange_coverage": int(group.loc[group["flow_safe"], "source"].nunique()),
                "perp_flow_cursor_safe": bool(group["flow_safe"].any()),
                "perp_cex_exchange_coverage": int(group.loc[group["venue_type"].str.upper() == "CEX", "source"].nunique()),
                "perp_dex_exchange_coverage": int(dex["source"].nunique()),
                "perp_information_age_seconds": group["information_age_seconds"].max(),
                "cex_open_interest_notional_usd": cex["oi_notional"].sum(min_count=1),
                "cex_oi_weighted_funding": weighted_average(cex["funding"], cex_relevance),
                "cex_oi_weighted_basis": weighted_average(cex["basis"], cex_relevance),
                "dex_open_interest_notional_usd": dex["oi_notional"].sum(min_count=1),
                "dex_oi_weighted_funding": weighted_average(dex["funding"], dex_relevance),
                "dex_oi_weighted_basis": weighted_average(dex["basis"], dex_relevance),
                "dex_volume_24h_usd": dex["volume_24h_usd"].sum(min_count=1),
                "dex_perp_information_age_seconds": dex["information_age_seconds"].max() if not dex.empty else np.nan,
            }
        )
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    grouped = result.groupby("asset", group_keys=False)
    result["delta_open_interest_notional_usd"] = grouped["open_interest_notional_usd"].diff()
    result["perp_cvd_aggregate"] = grouped["perp_flow_delta"].cumsum()
    result["perp_flow_z"] = grouped["perp_flow_delta"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["funding_z"] = grouped["oi_weighted_funding"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["basis_z"] = grouped["oi_weighted_basis"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    result["oi_change_z"] = grouped["delta_open_interest_notional_usd"].transform(
        lambda series: causal_zscore(series, z_window, min_periods)
    )
    return result.reset_index(drop=True)


def add_spot_perp_divergence(features: pd.DataFrame) -> pd.DataFrame:
    result = features.copy()
    if {"spot_flow_z", "perp_flow_z"}.issubset(result.columns):
        result["absorption_score"] = result["spot_flow_z"] - result["perp_flow_z"]
        conditions = [
            (result["spot_flow_z"] > 0) & (result["perp_flow_z"] < 0),
            (result["spot_flow_z"] < 0) & (result["perp_flow_z"] > 0),
            np.sign(result["spot_flow_z"]) == np.sign(result["perp_flow_z"]),
        ]
        result["spot_perp_state"] = np.select(
            conditions,
            ["SPOT_BUY_PERP_SELL", "SPOT_SELL_PERP_BUY", "CONFIRMATION"],
            default="UNCERTAIN",
        )
    return result
