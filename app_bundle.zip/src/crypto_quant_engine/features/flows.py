from __future__ import annotations

import json
import numpy as np
import pandas as pd

from .common import canonical_bucket, causal_zscore, column

STABLECOIN_TRANSFORMATION_VERSION = "stablecoin-multisource-v3-dated-supply"


def build_etf_flow_features(observations: pd.DataFrame) -> pd.DataFrame:
    """Build only from publication-time-stamped flows; trading date is never the availability timestamp."""
    if observations.empty:
        return pd.DataFrame()
    required = {"asset", "available_time"}
    missing = required - set(observations.columns)
    if missing:
        raise ValueError(f"ETF rows missing: {sorted(missing)}")
    frame = observations.copy()
    frame["asset"] = frame["asset"].astype(str).str.upper()
    # ETF evidence is intentionally scoped to the two US spot-ETF aggregates.
    # A future unrelated ETF row must never leak into BTC or ETH cumulative flows.
    frame = frame[frame["asset"].isin({"BTC", "ETH"})].copy()
    if "instrument" in frame:
        expected = frame["asset"].map(lambda asset: f"US_SPOT_{asset}_ETF_AGGREGATE")
        frame = frame[frame["instrument"].astype(str).eq(expected)].copy()
    if frame.empty:
        return pd.DataFrame()
    frame = frame.sort_values(["asset", "available_time"])
    daily = column(frame, "daily_net_flow_usd")
    if daily.isna().all():
        daily = column(frame, "daily_net_flow")
    if daily.isna().all():
        raise ValueError("ETF rows missing: ['daily_net_flow_usd']")
    frame["etf_daily_net_flow_usd"] = pd.to_numeric(daily, errors="coerce")
    trading_date = column(frame, "trading_date")
    if trading_date.isna().all() and "event_time" in frame:
        trading_date = pd.to_datetime(frame["event_time"], utc=True).dt.date.astype(str)
    if trading_date.isna().all():
        # Compatibility with normalized legacy rows that only retained receipt time.
        trading_date = pd.to_datetime(frame["available_time"], utc=True).dt.date.astype(str)
    frame["etf_trading_date"] = trading_date.astype("string")
    fund_columns = [name for name in frame if name.startswith("value.fund_flows_usd_millions.")]
    if fund_columns:
        placeholder = frame[fund_columns].isna().all(axis=1) & frame["etf_daily_net_flow_usd"].eq(0)
        frame = frame.loc[~placeholder].copy()
    # Keep every publication vintage. A later revision must not erase the value
    # that was actually known at an earlier prediction time.
    snapshots = []
    for asset, receipts in frame.sort_values(["asset", "available_time", "etf_trading_date"]).groupby("asset"):
        known: dict[str, float] = {}
        for _, receipt in receipts.iterrows():
            known[str(receipt["etf_trading_date"])] = float(receipt["etf_daily_net_flow_usd"])
            ordered = pd.Series([known[day] for day in sorted(known)], dtype=float)
            snapshot = receipt.copy()
            snapshot["etf_trading_date"] = max(known)
            snapshot["etf_daily_net_flow_usd"] = ordered.iloc[-1]
            snapshot["etf_history_day_count"] = len(ordered)
            for window in (3, 5, 10):
                snapshot[f"etf_flow_{window}d_usd"] = float(ordered.iloc[-window:].sum()) if len(ordered) >= window else np.nan
            snapshot["etf_flow_acceleration_usd"] = (
                float(ordered.iloc[-1] - 2 * ordered.iloc[-2] + ordered.iloc[-3]) if len(ordered) >= 3 else np.nan
            )
            snapshot["etf_flow_z"] = float(causal_zscore(ordered, window=60, min_periods=20).iloc[-1])
            snapshot["etf_level_usd_per_session"] = float(ordered.iloc[-5:].mean()) if len(ordered) >= 5 else np.nan
            snapshot["etf_acceleration_usd_per_session"] = (
                float(ordered.iloc[-1] - ordered.iloc[-5:-1].mean()) if len(ordered) >= 5 else np.nan
            )
            snapshots.append(snapshot)
    frame = pd.DataFrame(snapshots)
    frame["prediction_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame["feature_available_time"] = frame["prediction_time"]
    if "information_age_seconds" in frame:
        frame["etf_information_age_seconds"] = pd.to_numeric(frame["information_age_seconds"], errors="coerce")
    else:
        frame["etf_information_age_seconds"] = np.nan
    frame["etf_backtest_eligible"] = False
    return frame[
        [
            "asset",
            "prediction_time",
            "available_time",
            "feature_available_time",
            "etf_trading_date",
            "etf_daily_net_flow_usd",
            "etf_flow_3d_usd",
            "etf_flow_5d_usd",
            "etf_flow_10d_usd",
            "etf_flow_acceleration_usd",
            "etf_level_usd_per_session",
            "etf_acceleration_usd_per_session",
            "etf_flow_z",
            "etf_information_age_seconds",
            "etf_history_day_count",
            "etf_backtest_eligible",
        ]
    ].reset_index(drop=True)


def build_stablecoin_flow_features(observations: pd.DataFrame) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame = frame.sort_values("available_time", kind="stable")
    measures = (
        "stablecoin_supply_usd",
        "stablecoin_supply_change_1d_usd",
        "stablecoin_supply_change_7d_usd",
        "stablecoin_supply_change_30d_usd",
        "stablecoin_market_cap_usd",
        "stablecoin_market_cap_change_1d_usd",
    )
    for name in measures:
        frame[name] = pd.to_numeric(column(frame, name), errors="coerce")

    # Build a causal union of the two independent measures. A CoinGecko market
    # cap never overwrites or masquerades as DefiLlama circulating supply.
    latest = {name: np.nan for name in measures}
    last_seen: dict[str, pd.Timestamp] = {}
    providers: dict[str, pd.Timestamp] = {}
    maximum_age = pd.Timedelta(days=2)
    snapshots: list[dict[str, object]] = []
    previous_supply = np.nan
    for _, receipt in frame.iterrows():
        received = receipt["available_time"]
        for name, timestamp in list(last_seen.items()):
            if received - timestamp > maximum_age:
                latest[name] = np.nan
                del last_seen[name]
        providers = {name: timestamp for name, timestamp in providers.items() if received - timestamp <= maximum_age}
        for name in measures:
            if pd.notna(receipt[name]) and np.isfinite(receipt[name]):
                latest[name] = float(receipt[name])
                age = receipt.get('information_age_seconds', 0)
                age = float(age) if pd.notna(age) and np.isfinite(float(age)) else 0.0
                last_seen[name] = received - pd.Timedelta(seconds=max(0.0, age))
        provider = str(receipt.get("source", "")).strip()
        if provider and any(pd.notna(receipt[name]) and np.isfinite(receipt[name]) for name in measures):
            providers[provider] = received
        supply = latest["stablecoin_supply_usd"]
        receipt_has_supply = pd.notna(receipt["stablecoin_supply_usd"])
        snapshots.append({
            "prediction_time": receipt["available_time"],
            "feature_available_time": receipt["available_time"],
            **latest,
            "stablecoin_supply_change_since_previous_snapshot_usd": (
                supply - previous_supply
                if receipt_has_supply and pd.notna(supply) and pd.notna(previous_supply)
                else np.nan
            ),
            "stablecoin_source_count": len(providers),
            "stablecoin_sources": ", ".join(sorted(providers)),
            "stablecoin_transformation_version": STABLECOIN_TRANSFORMATION_VERSION,
            "stablecoin_information_age_seconds": max(
                ((received - timestamp).total_seconds() for timestamp in last_seen.values()), default=np.nan
            ),
        })
        if receipt_has_supply and pd.notna(supply):
            previous_supply = supply
    result = pd.DataFrame(snapshots)
    result["stablecoin_liquidity_change_1d_usd"] = result["stablecoin_supply_change_1d_usd"].fillna(
        result["stablecoin_market_cap_change_1d_usd"]
    )
    result["stablecoin_supply_change_z"] = causal_zscore(
        result["stablecoin_supply_change_1d_usd"], window=60, min_periods=20
    )
    result["stablecoin_backtest_eligible"] = False
    return result[
        [
            "prediction_time",
            "feature_available_time",
            "stablecoin_supply_usd",
            "stablecoin_supply_change_1d_usd",
            "stablecoin_supply_change_7d_usd",
            "stablecoin_supply_change_30d_usd",
            "stablecoin_market_cap_usd",
            "stablecoin_market_cap_change_1d_usd",
            "stablecoin_liquidity_change_1d_usd",
            "stablecoin_supply_change_since_previous_snapshot_usd",
            "stablecoin_supply_change_z",
            "stablecoin_source_count",
            "stablecoin_sources",
            "stablecoin_transformation_version",
            "stablecoin_information_age_seconds",
            "stablecoin_backtest_eligible",
        ]
    ].reset_index(drop=True)


def build_liquidation_features(observations: pd.DataFrame, frequency: str = "15min") -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame = frame.sort_values("available_time")
    event_key = column(frame, "liquidation_event_key")
    if event_key.notna().any():
        frame = frame.loc[~(event_key.notna() & frame.assign(_event_key=event_key).duplicated(
            ["source", "_event_key"], keep="first"))].copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    frame["long_notional"] = pd.to_numeric(
        column(frame, "observed_long_liquidation_notional_usd"), errors="coerce"
    )
    frame["short_notional"] = pd.to_numeric(
        column(frame, "observed_short_liquidation_notional_usd"), errors="coerce"
    )
    frame["event_count"] = pd.to_numeric(column(frame, "liquidation_order_count"), errors="coerce")
    frame["heartbeat"] = column(frame, "listener_heartbeat").astype("boolean").fillna(False).astype(bool)
    rows: list[dict[str, object]] = []
    last_prices = {}
    for (asset, bucket), group in frame.groupby(["asset", "bucket"], sort=True):
        # Preserve each available prefix. A later heartbeat/event must not move
        # the entire bucket past an earlier market snapshot's causal cutoff.
        long_value = short_value = np.nan
        live = False
        event_count = 0
        sources = {}
        for available, updates in group.groupby("available_time", sort=True):
            for name in ("long_notional", "short_notional"):
                increment = updates[name].sum(min_count=1)
                if pd.notna(increment):
                    if name == "long_notional":
                        long_value = (0.0 if pd.isna(long_value) else long_value) + increment
                    else:
                        short_value = (0.0 if pd.isna(short_value) else short_value) + increment
            live = live or bool(updates["heartbeat"].any())
            event_count += int(updates["event_count"].fillna(0).sum())
            for _, update in updates.iterrows():
                source = str(update.get("source", "binance_liquidation_stream"))
                state = sources.setdefault(source, {"long": 0.0, "short": 0.0, "events": 0,
                                                    "connected": False, "observed": False,
                                                    **last_prices.get((asset, source), {})})
                for key, col in (("long", "long_notional"), ("short", "short_notional")):
                    if pd.notna(update[col]):
                        state[key] += float(update[col])
                        state["observed"] = True
                state["events"] += int(update["event_count"]) if pd.notna(update["event_count"]) else 0
                explicit = update.get("value.listener_connected", update.get("listener_connected"))
                if explicit is not None and pd.notna(explicit):
                    state["connected"] = bool(explicit)
                elif bool(update["heartbeat"]):
                    state["connected"] = True
                state["received_at"] = pd.Timestamp(available).isoformat()
                basis = update.get("meta.price_basis")
                if isinstance(basis, str): state["price_basis"] = basis
                error = update.get("meta.status_error")
                if isinstance(error, str): state["error"] = error
                price = update.get("value.liquidation_reference_price", update.get("liquidation_reference_price"))
                if price is None or pd.isna(price):
                    price = update.get("value.execution_price", update.get("execution_price"))
                event = pd.to_datetime(update.get("event_time"), utc=True, errors="coerce")
                previous = pd.to_datetime(state.get("last_event_time"), utc=True, errors="coerce")
                if price is not None and pd.notna(price) and np.isfinite(float(price)) and pd.notna(event) and (pd.isna(previous) or event >= previous):
                    last_prices[(asset,source)] = {"last_price":float(price), "last_event_time":event.isoformat()}
                    state.update(last_prices[(asset,source)])
            live = any(state["connected"] for state in sources.values())
            rows.append(
                {
                    "asset": asset,
                    "prediction_time": pd.to_datetime(available, utc=True),
                    "feature_available_time": pd.to_datetime(available, utc=True),
                    "observed_long_liquidation_notional_usd": 0.0 if live and pd.isna(long_value) else long_value,
                    "observed_short_liquidation_notional_usd": 0.0 if live and pd.isna(short_value) else short_value,
                    "observed_liquidation_order_count": event_count,
                    "liquidation_stream_live": live,
                    "liquidation_snapshot_is_lower_bound": all(s == "binance_liquidation_stream" for s in sources),
                    "liquidation_feature_transformation": "multivenue-available-prefix-v3",
                    "liquidation_sources_json": json.dumps(sources, sort_keys=True),
                    "liquidation_connected_source_count": sum(s["connected"] for s in sources.values()),
                }
            )
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    total = result["observed_long_liquidation_notional_usd"].fillna(0) + result[
        "observed_short_liquidation_notional_usd"
    ].fillna(0)
    result["observed_liquidation_imbalance"] = (
        result["observed_short_liquidation_notional_usd"].fillna(0)
        - result["observed_long_liquidation_notional_usd"].fillna(0)
    ) / total.replace(0, np.nan)
    # When the listener heartbeat proves the stream was connected but no forced
    # liquidation occurred, the defensible observation is a neutral imbalance of
    # zero.  Rows without a heartbeat remain NaN so a disconnected source can never
    # masquerade as a calm market.
    quiet_but_live = result["liquidation_stream_live"] & total.eq(0)
    result.loc[quiet_but_live, "observed_liquidation_imbalance"] = 0.0
    return result.reset_index(drop=True)
