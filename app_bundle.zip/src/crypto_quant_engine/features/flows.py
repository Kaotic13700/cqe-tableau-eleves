from __future__ import annotations

import numpy as np
import pandas as pd

from .common import canonical_bucket, causal_zscore, column


def build_etf_flow_features(observations: pd.DataFrame) -> pd.DataFrame:
    """Build only from publication-time-stamped flows; trading date is never the availability timestamp."""
    if observations.empty:
        return pd.DataFrame()
    required = {"asset", "available_time"}
    missing = required - set(observations.columns)
    if missing:
        raise ValueError(f"ETF rows missing: {sorted(missing)}")
    frame = observations.copy().sort_values(["asset", "available_time"])
    daily = column(frame, "daily_net_flow_usd")
    if daily.isna().all():
        daily = column(frame, "daily_net_flow")
    if daily.isna().all():
        raise ValueError("ETF rows missing: ['daily_net_flow_usd']")
    frame["etf_daily_net_flow_usd"] = pd.to_numeric(daily, errors="coerce")
    trading_date = column(frame, "trading_date")
    if trading_date.isna().all() and "event_time" in frame:
        trading_date = pd.to_datetime(frame["event_time"], utc=True).dt.date.astype(str)
    if trading_date.isna().all():
        # Compatibility with normalized legacy rows that only retained receipt time.
        trading_date = pd.to_datetime(frame["available_time"], utc=True).dt.date.astype(str)
    frame["etf_trading_date"] = trading_date.astype("string")
    fund_columns = [name for name in frame if name.startswith("value.fund_flows_usd_millions.")]
    if fund_columns:
        placeholder = frame[fund_columns].isna().all(axis=1) & frame["etf_daily_net_flow_usd"].eq(0)
        frame = frame.loc[~placeholder].copy()
    frame = frame.sort_values(["asset", "etf_trading_date", "available_time"])
    # Repeated receipts of the same published day are refreshes, not extra flow days.
    frame = frame.drop_duplicates(["asset", "etf_trading_date"], keep="last")
    grouped = frame.groupby("asset", group_keys=False)
    frame["etf_history_day_count"] = grouped.cumcount() + 1
    for window in (3, 5, 10):
        frame[f"etf_flow_{window}d_usd"] = grouped["etf_daily_net_flow_usd"].transform(
            lambda value: value.rolling(window, min_periods=window).sum()
        )
    first_difference = grouped["etf_daily_net_flow_usd"].diff()
    frame["etf_flow_acceleration_usd"] = first_difference.groupby(frame["asset"]).diff()
    frame["etf_flow_z"] = grouped["etf_daily_net_flow_usd"].transform(
        lambda value: causal_zscore(value, window=60, min_periods=20)
    )
    frame["prediction_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame["feature_available_time"] = frame["prediction_time"]
    if "information_age_seconds" in frame:
        frame["etf_information_age_seconds"] = pd.to_numeric(frame["information_age_seconds"], errors="coerce")
    else:
        frame["etf_information_age_seconds"] = np.nan
    frame["etf_backtest_eligible"] = False
    return frame[
        [
            "asset",
            "prediction_time",
            "available_time",
            "feature_available_time",
            "etf_trading_date",
            "etf_daily_net_flow_usd",
            "etf_flow_3d_usd",
            "etf_flow_5d_usd",
            "etf_flow_10d_usd",
            "etf_flow_acceleration_usd",
            "etf_flow_z",
            "etf_information_age_seconds",
            "etf_history_day_count",
            "etf_backtest_eligible",
        ]
    ].reset_index(drop=True)


def build_stablecoin_flow_features(observations: pd.DataFrame) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy().sort_values("available_time")
    frame["prediction_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame["feature_available_time"] = frame["prediction_time"]
    for name in (
        "stablecoin_supply_usd",
        "stablecoin_supply_change_1d_usd",
        "stablecoin_supply_change_7d_usd",
        "stablecoin_supply_change_30d_usd",
    ):
        frame[name] = pd.to_numeric(column(frame, name), errors="coerce")
    frame["stablecoin_supply_change_since_previous_snapshot_usd"] = frame["stablecoin_supply_usd"].diff()
    frame["stablecoin_supply_change_z"] = causal_zscore(
        frame["stablecoin_supply_change_1d_usd"], window=60, min_periods=20
    )
    frame["stablecoin_information_age_seconds"] = 0.0
    frame["stablecoin_backtest_eligible"] = False
    return frame[
        [
            "prediction_time",
            "feature_available_time",
            "stablecoin_supply_usd",
            "stablecoin_supply_change_1d_usd",
            "stablecoin_supply_change_7d_usd",
            "stablecoin_supply_change_30d_usd",
            "stablecoin_supply_change_since_previous_snapshot_usd",
            "stablecoin_supply_change_z",
            "stablecoin_information_age_seconds",
            "stablecoin_backtest_eligible",
        ]
    ].reset_index(drop=True)


def build_liquidation_features(observations: pd.DataFrame, frequency: str = "15min") -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    frame["long_notional"] = pd.to_numeric(
        column(frame, "observed_long_liquidation_notional_usd"), errors="coerce"
    )
    frame["short_notional"] = pd.to_numeric(
        column(frame, "observed_short_liquidation_notional_usd"), errors="coerce"
    )
    frame["event_count"] = pd.to_numeric(column(frame, "liquidation_order_count"), errors="coerce")
    frame["heartbeat"] = column(frame, "listener_heartbeat").astype("boolean").fillna(False).astype(bool)
    rows: list[dict[str, object]] = []
    for (asset, bucket), group in frame.groupby(["asset", "bucket"], sort=True):
        long_value = group["long_notional"].sum(min_count=1)
        short_value = group["short_notional"].sum(min_count=1)
        live = bool(group["heartbeat"].any())
        if live and pd.isna(long_value):
            long_value = 0.0
        if live and pd.isna(short_value):
            short_value = 0.0
        rows.append(
            {
                "asset": asset,
                "prediction_time": bucket,
                "feature_available_time": pd.to_datetime(group["available_time"], utc=True).max(),
                "observed_long_liquidation_notional_usd": long_value,
                "observed_short_liquidation_notional_usd": short_value,
                "observed_liquidation_order_count": int(group["event_count"].fillna(0).sum()),
                "liquidation_stream_live": live,
                "liquidation_snapshot_is_lower_bound": True,
            }
        )
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    total = result["observed_long_liquidation_notional_usd"].fillna(0) + result[
        "observed_short_liquidation_notional_usd"
    ].fillna(0)
    result["observed_liquidation_imbalance"] = (
        result["observed_short_liquidation_notional_usd"].fillna(0)
        - result["observed_long_liquidation_notional_usd"].fillna(0)
    ) / total.replace(0, np.nan)
    # When the listener heartbeat proves the stream was connected but no forced
    # liquidation occurred, the defensible observation is a neutral imbalance of
    # zero.  Rows without a heartbeat remain NaN so a disconnected source can never
    # masquerade as a calm market.
    quiet_but_live = result["liquidation_stream_live"] & total.eq(0)
    result.loc[quiet_but_live, "observed_liquidation_imbalance"] = 0.0
    return result.reset_index(drop=True)
