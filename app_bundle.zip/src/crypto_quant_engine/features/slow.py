from __future__ import annotations

import pandas as pd


def point_in_time_slow_features(
    prediction_times: pd.DataFrame,
    observations: pd.DataFrame,
    value_columns: list[str],
) -> pd.DataFrame:
    """Carry slow features forward by available_time, never by the period they describe."""
    left = prediction_times.sort_values("prediction_time").copy()
    right = observations.sort_values("available_time").copy()
    left["prediction_time"] = pd.to_datetime(left["prediction_time"], utc=True)
    right["available_time"] = pd.to_datetime(right["available_time"], utc=True)
    return pd.merge_asof(
        left,
        right[["available_time", *value_columns]],
        left_on="prediction_time",
        right_on="available_time",
        direction="backward",
    )

