from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


def reaction_to_release(
    releases: pd.DataFrame,
    markets: pd.DataFrame,
    instruments: list[str],
    window: timedelta = timedelta(hours=1),
) -> pd.DataFrame:
    """Compute post-release market returns using only observations after each release availability time."""
    required_release = {"release_id", "available_time"}
    required_market = {"instrument", "available_time", "price"}
    if not required_release.issubset(releases) or not required_market.issubset(markets):
        raise ValueError("release or market timestamp columns are missing")
    rows = []
    market = markets.copy()
    market["available_time"] = pd.to_datetime(market["available_time"], utc=True)
    for release in releases.itertuples(index=False):
        start = pd.Timestamp(getattr(release, "available_time"))
        end = start + window
        row = {"release_id": getattr(release, "release_id"), "release_time": start, "available_time": end}
        for instrument in instruments:
            sample = market[
                (market["instrument"] == instrument)
                & (market["available_time"] >= start)
                & (market["available_time"] <= end)
            ].sort_values("available_time")
            # A completed-window reaction cannot be published at release time.
            # Require an observation at the window end; otherwise stay missing.
            complete = len(sample) >= 2 and sample.iloc[-1]["available_time"] >= end
            row[f"reaction_{instrument}"] = (
                float(sample.iloc[-1]["price"] / sample.iloc[0]["price"] - 1) if complete else np.nan
            )
        rows.append(row)
    return pd.DataFrame(rows)
