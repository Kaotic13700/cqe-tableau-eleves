from __future__ import annotations

import pandas as pd

from .common import column


def build_market_breadth_features(observations: pd.DataFrame) -> pd.DataFrame:
    """Expose current global-market breadth strictly from its receipt time."""

    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    rows: list[dict[str, object]] = []
    value_columns = (
        "global_crypto_market_cap_usd",
        "btc_dominance",
        "eth_dominance",
        "total3_market_cap_usd",
        "total3_btc",
    )
    for _, item in frame.sort_values("available_time").iterrows():
        row: dict[str, object] = {
            "prediction_time": item["available_time"],
            "feature_available_time": item["available_time"],
            "market_breadth_information_age_seconds": item.get("information_age_seconds", 0.0),
            "market_breadth_backtest_eligible": bool((item.get("metadata") or {}).get("backtest_eligible", False))
            if isinstance(item.get("metadata"), dict)
            else False,
        }
        for name in value_columns:
            row[name] = column(frame.loc[[item.name]], name).iloc[0]
        rows.append(row)
    return pd.DataFrame(rows).sort_values("prediction_time").reset_index(drop=True)


def add_eth_btc(features: pd.DataFrame, tolerance_minutes: int = 30) -> pd.DataFrame:
    """Add a causal ETH/BTC ratio when asset snapshots are not exactly simultaneous.

    Live collectors finish BTC and ETH a few milliseconds apart, so an exact
    timestamp pivot drops the most recent ratio.  A backward as-of join uses
    only the last price that was already available at each prediction time.
    The tolerance prevents an old price from silently filling a collection gap.
    """
    required = {"prediction_time", "asset", "spot_price"}
    if features.empty or not required.issubset(features.columns):
        return features.copy()

    result = features.copy()
    result["prediction_time"] = pd.to_datetime(result["prediction_time"], utc=True)
    result["_relative_order"] = range(len(result))
    timeline = result[["prediction_time"]].drop_duplicates().sort_values("prediction_time")
    tolerance_delta = pd.to_timedelta(int(tolerance_minutes), unit="m")

    for asset, column in (("BTC", "_btc_price"), ("ETH", "_eth_price")):
        prices = (
            result.loc[result["asset"] == asset, ["prediction_time", "spot_price"]]
            .dropna(subset=["spot_price"])
            .drop_duplicates("prediction_time", keep="last")
            .sort_values("prediction_time")
            .rename(columns={"spot_price": column})
        )
        timeline = pd.merge_asof(
            timeline,
            prices,
            on="prediction_time",
            direction="backward",
            tolerance=tolerance_delta,
        )

    timeline["eth_btc"] = timeline["_eth_price"] / timeline["_btc_price"]
    result = result.merge(timeline[["prediction_time", "eth_btc"]], on="prediction_time", how="left")
    return result.sort_values("_relative_order").drop(columns="_relative_order").reset_index(drop=True)
