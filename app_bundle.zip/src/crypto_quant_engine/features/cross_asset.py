from __future__ import annotations

import pandas as pd


def empirical_stress_score(standardized_changes: pd.DataFrame, weights: pd.Series | None = None) -> pd.Series:
    """Cross-sectional weighted mean; signs must be defined by validated input transforms, not event narratives."""
    if standardized_changes.empty:
        return pd.Series(dtype=float)
    if weights is None:
        weights = pd.Series(1.0, index=standardized_changes.columns)
    aligned = weights.reindex(standardized_changes.columns).fillna(0.0)
    return standardized_changes.mul(aligned, axis=1).sum(axis=1) / aligned.abs().sum()

