"""Causal market-structure features built only from completed OHLCV bars."""
from __future__ import annotations

import numpy as np
import pandas as pd


def prepare_closed_bars(bars: pd.DataFrame, *, as_of, timeframe: str) -> pd.DataFrame:
    required = {"open", "high", "low", "close", "available_time"}
    missing = required - set(bars)
    if missing:
        raise ValueError(f"bar columns missing: {sorted(missing)}")
    cutoff = pd.Timestamp(as_of)
    cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    frame = bars.copy()
    frame["available_time"] = pd.to_datetime(frame["available_time"], utc=True)
    frame = frame[frame["available_time"] <= cutoff].sort_values("available_time")
    keys = [name for name in ("source", "instrument", "event_time") if name in frame]
    return frame.drop_duplicates(keys or ["available_time"], keep="last").reset_index(drop=True)


def build_structure_features(bars: pd.DataFrame, *, as_of, timeframe: str) -> pd.DataFrame:
    frame = prepare_closed_bars(bars, as_of=as_of, timeframe=timeframe)
    if frame.empty:
        return frame
    high, low, close = (pd.to_numeric(frame[name], errors="coerce") for name in ("high", "low", "close"))
    previous = close.shift(1)
    tr = pd.concat([(high-low), (high-previous).abs(), (low-previous).abs()], axis=1).max(axis=1)
    frame["atr14"] = tr.rolling(14, min_periods=14).mean()
    # A 2/2 pivot becomes available only on the second closed bar to its right.
    pivot_high = high.shift(2).eq(high.rolling(5).max())
    pivot_low = low.shift(2).eq(low.rolling(5).min())
    frame["confirmed_pivot_high"] = high.shift(2).where(pivot_high)
    frame["confirmed_pivot_low"] = low.shift(2).where(pivot_low)
    frame["structure_available_time"] = frame["available_time"]
    last_high = frame["confirmed_pivot_high"].ffill()
    last_low = frame["confirmed_pivot_low"].ffill()
    margin = 0.10 * frame["atr14"]
    frame["bos_up"] = close > last_high + margin
    frame["bos_down"] = close < last_low - margin
    return frame


def build_anchored_vwap(bars: pd.DataFrame, *, anchor_time) -> pd.Series:
    frame = bars.copy()
    times = pd.to_datetime(frame["available_time"], utc=True)
    anchor = pd.Timestamp(anchor_time)
    anchor = anchor.tz_localize("UTC") if anchor.tzinfo is None else anchor.tz_convert("UTC")
    volume = pd.to_numeric(frame.get("volume"), errors="coerce")
    price = (pd.to_numeric(frame["high"], errors="coerce") + pd.to_numeric(frame["low"], errors="coerce") + pd.to_numeric(frame["close"], errors="coerce")) / 3
    active = times >= anchor
    cumulative_volume = volume.where(active).cumsum()
    return (price.mul(volume).where(active).cumsum() / cumulative_volume.replace(0, np.nan)).rename("anchored_vwap")
