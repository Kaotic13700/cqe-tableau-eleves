from __future__ import annotations

import numpy as np
import pandas as pd

from .common import causal_zscore


def add_realized_volatility(
    frame: pd.DataFrame,
    price_column: str = "spot_price",
    periods: tuple[int, ...] = (16, 96, 672),
) -> pd.DataFrame:
    result = frame.sort_values(["asset", "prediction_time"]).copy()
    log_return = result.groupby("asset")[price_column].transform(lambda value: np.log(value).diff())
    for period in periods:
        volatility = log_return.groupby(result["asset"]).transform(
            lambda value: value.rolling(period, min_periods=max(4, period // 2)).std()
        )
        result[f"realized_volatility_{period}"] = volatility
        result[f"realized_volatility_{period}_z"] = volatility.groupby(result["asset"]).transform(
            lambda value: causal_zscore(value, window=max(96, period * 4), min_periods=max(16, period))
        )
    return result

