from __future__ import annotations

from datetime import timedelta
from functools import reduce

import numpy as np
import pandas as pd

from .common import assert_point_in_time, causal_zscore
from .cme import build_cme_basis_features
from .flows import build_etf_flow_features, build_liquidation_features, build_stablecoin_flow_features
from .options import build_options_features
from .perps import add_spot_perp_divergence, build_perp_features
from .relative import add_eth_btc, build_market_breadth_features
from .spot import build_spot_features
from .volatility import add_realized_volatility


class FeatureEngine:
    def __init__(self, exchange_weights: dict[str, float] | None = None, frequency: str = "15min") -> None:
        self.exchange_weights = exchange_weights or {}
        self.frequency = frequency

    def build(self, observations: pd.DataFrame) -> pd.DataFrame:
        if observations.empty:
            return pd.DataFrame()
        families = {
            family: observations[observations["data_family"] == family].copy()
            for family in (
                "SPOT", "PERPS", "OPTIONS", "ETF", "STABLECOINS", "LIQUIDATIONS", "CME_FUTURES", "MARKET_BREADTH"
            )
        }
        raw_blocks = [
            ("spot", build_spot_features(families["SPOT"], self.exchange_weights, self.frequency)),
            ("perp", build_perp_features(families["PERPS"], self.exchange_weights, self.frequency)),
            ("options", build_options_features(families["OPTIONS"], self.frequency)),
        ]
        blocks = []
        for name, block in raw_blocks:
            if not block.empty:
                blocks.append(block.rename(columns={"feature_available_time": f"feature_available_time_{name}"}))
        if not blocks:
            return pd.DataFrame()
        merged = reduce(
            lambda left, right: left.merge(
                right,
                on=["asset", "prediction_time"],
                how="outer",
            ),
            blocks,
        )
        available_columns = [column for column in merged.columns if column.startswith("feature_available_time_")]
        if available_columns:
            merged["feature_available_time"] = merged[available_columns].max(axis=1)
        else:
            merged["feature_available_time"] = merged["prediction_time"]
        # Buckets label the prediction time at the bucket start; availability may be later. Move the usable snapshot forward.
        merged["prediction_time"] = pd.concat(
            [pd.to_datetime(merged["prediction_time"], utc=True), pd.to_datetime(merged["feature_available_time"], utc=True)],
            axis=1,
        ).max(axis=1)
        context_blocks = [
            ("etf", build_etf_flow_features(families["ETF"]), timedelta(days=7), True),
            ("stablecoin", build_stablecoin_flow_features(families["STABLECOINS"]), timedelta(days=2), False),
            (
                "liquidations",
                build_liquidation_features(families["LIQUIDATIONS"], self.frequency),
                timedelta(minutes=30),
                True,
            ),
            ("cme", build_cme_basis_features(families["CME_FUTURES"]), timedelta(hours=2), True),
            (
                "market_breadth",
                build_market_breadth_features(families["MARKET_BREADTH"]),
                timedelta(days=2),
                False,
            ),
        ]
        for name, block, tolerance, match_asset in context_blocks:
            merged = self._attach_context(merged, block, name, tolerance, match_asset)
        merged = add_spot_perp_divergence(merged)
        if {"spot_price", "perp_price"}.issubset(merged.columns):
            derived_basis = merged["perp_price"] / merged["spot_price"] - 1
            if "oi_weighted_basis" in merged:
                merged["oi_weighted_basis"] = merged["oi_weighted_basis"].fillna(derived_basis)
            else:
                merged["oi_weighted_basis"] = derived_basis
        merged = add_eth_btc(merged)
        if "spot_price" in merged:
            merged = add_realized_volatility(merged)
            merged = merged.sort_values(["asset", "prediction_time"])
            prices = merged.groupby("asset")["spot_price"]
            for label, periods in (("1h", 4), ("4h", 16), ("24h", 96)):
                merged[f"return_{label}"] = prices.pct_change(periods, fill_method=None)
        if "oi_weighted_basis" in merged:
            merged["basis_z"] = merged.groupby("asset", group_keys=False)["oi_weighted_basis"].transform(
                lambda series: causal_zscore(series, 96, 32)
            )
        if "eth_btc" in merged:
            merged["eth_btc_return_24h"] = merged.groupby("asset")["eth_btc"].pct_change(96, fill_method=None)
        defaults: dict[str, object] = {
            "etf_daily_net_flow_usd": np.nan,
            "etf_information_age_seconds": np.nan,
            "etf_history_day_count": 0,
            "stablecoin_supply_usd": np.nan,
            "stablecoin_supply_change_1d_usd": np.nan,
            "stablecoin_information_age_seconds": np.nan,
            "observed_long_liquidation_notional_usd": np.nan,
            "observed_short_liquidation_notional_usd": np.nan,
            "observed_liquidation_order_count": np.nan,
            "liquidation_stream_live": False,
            "liquidation_snapshot_is_lower_bound": True,
            "perp_cex_exchange_coverage": 0,
            "perp_dex_exchange_coverage": 0,
            "cex_open_interest_notional_usd": np.nan,
            "cex_oi_weighted_funding": np.nan,
            "cex_oi_weighted_basis": np.nan,
            "dex_open_interest_notional_usd": np.nan,
            "dex_oi_weighted_funding": np.nan,
            "dex_oi_weighted_basis": np.nan,
            "dex_volume_24h_usd": np.nan,
            "dex_perp_information_age_seconds": np.nan,
            "cme_basis_fraction": np.nan,
            "cme_basis_annualized": np.nan,
            "cme_information_age_seconds": np.nan,
            "btc_dominance": np.nan,
            "eth_dominance": np.nan,
            "total3_market_cap_usd": np.nan,
            "total3_btc": np.nan,
            "market_breadth_information_age_seconds": np.nan,
            "market_breadth_backtest_eligible": False,
        }
        for name, default in defaults.items():
            if name not in merged:
                merged[name] = default
        available_columns = [column for column in merged if column.startswith("feature_available_time_")]
        if available_columns:
            merged["feature_available_time"] = merged[available_columns].max(axis=1)
        assert_point_in_time(merged)
        return merged.sort_values(["asset", "prediction_time"]).reset_index(drop=True)

    @staticmethod
    def _attach_context(
        features: pd.DataFrame,
        block: pd.DataFrame,
        name: str,
        tolerance: timedelta,
        match_asset: bool,
    ) -> pd.DataFrame:
        if block.empty:
            return features
        available_name = f"feature_available_time_{name}"
        right = block.copy().rename(columns={"feature_available_time": available_name})
        right[f"{name}_observation_time"] = pd.to_datetime(right[available_name], utc=True)
        right = right.drop(columns=["prediction_time", "available_time"], errors="ignore")
        left = features.copy()
        left["prediction_time"] = pd.to_datetime(left["prediction_time"], utc=True)
        by = "asset" if match_asset else None
        sort_left = ["prediction_time", "asset"] if match_asset else ["prediction_time"]
        sort_right = [f"{name}_observation_time", "asset"] if match_asset else [f"{name}_observation_time"]
        left = left.sort_values(sort_left)
        right = right.sort_values(sort_right).drop_duplicates(
            (["asset"] if match_asset else []) + [f"{name}_observation_time"], keep="last"
        )
        return pd.merge_asof(
            left,
            right,
            left_on="prediction_time",
            right_on=f"{name}_observation_time",
            by=by,
            direction="backward",
            tolerance=tolerance,
        )
