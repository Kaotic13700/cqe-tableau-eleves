from __future__ import annotations

import math
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import norm

from .common import canonical_bucket, column


MATURITY_BUCKETS = (
    ("0_7d", 0.0, 7.0),
    ("8_30d", 7.0, 30.0),
    ("31_90d", 30.0, 90.0),
    ("gt_90d", 90.0, math.inf),
)


def maturity_bucket(days: float) -> str | None:
    for name, lower, upper in MATURITY_BUCKETS:
        if lower <= days <= upper if lower == 0 else lower < days <= upper:
            return name
    return None


def _iv_decimal(iv_percent: float) -> float:
    return iv_percent / 100.0 if iv_percent > 3 else iv_percent


def _estimated_abs_delta(
    option_type: str,
    spot: float,
    strike: float,
    years: float,
    iv_percent: float,
    interest_rate: float = 0.0,
) -> float:
    if not all(np.isfinite([spot, strike, years, iv_percent])) or min(spot, strike, years, iv_percent) <= 0:
        return float("nan")
    sigma = _iv_decimal(iv_percent)
    rate = interest_rate if np.isfinite(interest_rate) else 0.0
    d1 = (math.log(spot / strike) + (rate + 0.5 * sigma * sigma) * years) / (sigma * math.sqrt(years))
    return float(norm.cdf(d1) if option_type == "call" else norm.cdf(-d1))


def estimated_gamma_per_usd(
    spot: float,
    strike: float,
    years: float,
    iv_percent: float,
    interest_rate: float = 0.0,
) -> float:
    """Black-Scholes gamma per base unit and per USD spot move.

    This is an unsigned contract sensitivity. It contains no claim about who is
    long or short the option and therefore is not dealer gamma.
    """
    if not all(np.isfinite([spot, strike, years, iv_percent])) or min(spot, strike, years, iv_percent) <= 0:
        return float("nan")
    sigma = _iv_decimal(iv_percent)
    rate = interest_rate if np.isfinite(interest_rate) else 0.0
    root_time = math.sqrt(years)
    d1 = (math.log(spot / strike) + (rate + 0.5 * sigma * sigma) * years) / (sigma * root_time)
    return float(norm.pdf(d1) / (spot * sigma * root_time))


def _interpolated_iv(group: pd.DataFrame, option_type: str, target_delta: float = 0.25) -> float:
    side = group[group["option_type"] == option_type][["abs_delta", "iv"]].dropna().sort_values("abs_delta")
    side = side.drop_duplicates("abs_delta")
    if len(side) < 2 or target_delta < side["abs_delta"].min() or target_delta > side["abs_delta"].max():
        return float("nan")
    return float(np.interp(target_delta, side["abs_delta"], side["iv"]))


def _safe_sum(values: pd.Series) -> float:
    return float(values.sum(min_count=1)) if values.notna().any() else float("nan")


def build_options_features(
    observations: pd.DataFrame,
    frequency: str = "15min",
    max_relative_spread: float = 0.35,
    min_open_interest: float = 1.0,
    target_maturities: Iterable[int] = (7, 30, 60, 90),
) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    frame = observations.copy()
    frame["bucket"] = canonical_bucket(frame, frequency)
    frame = frame.sort_values("available_time").drop_duplicates(
        ["asset", "bucket", "source", "instrument"], keep="last"
    )
    frame["expiration"] = pd.to_datetime(column(frame, "expiration"), utc=True, errors="coerce")
    frame["days"] = (frame["expiration"] - frame["bucket"]).dt.total_seconds() / 86400
    frame["option_type"] = column(frame, "call_or_put").astype(str)
    frame["strike"] = pd.to_numeric(column(frame, "strike"), errors="coerce")
    frame["spot"] = pd.to_numeric(column(frame, "underlying_price"), errors="coerce")
    frame["iv"] = pd.to_numeric(column(frame, "implied_volatility"), errors="coerce")
    frame["oi"] = pd.to_numeric(column(frame, "open_interest_contracts"), errors="coerce")
    frame["volume"] = pd.to_numeric(column(frame, "volume_contracts"), errors="coerce")
    frame["bid"] = pd.to_numeric(column(frame, "bid"), errors="coerce")
    frame["ask"] = pd.to_numeric(column(frame, "ask"), errors="coerce")
    frame["interest_rate"] = pd.to_numeric(column(frame, "interest_rate"), errors="coerce").fillna(0.0)
    frame["contract_multiplier"] = pd.to_numeric(
        column(frame, "contract_multiplier_base_units"), errors="coerce"
    )
    documented_multiplier = frame["asset"].map({"BTC": 1.0, "ETH": 1.0})
    frame["contract_multiplier"] = frame["contract_multiplier"].fillna(documented_multiplier)
    supplied_base_oi = pd.to_numeric(column(frame, "open_interest_base_units"), errors="coerce")
    frame["open_interest_base_units"] = supplied_base_oi.fillna(frame["oi"] * frame["contract_multiplier"])
    mid = (frame["bid"] + frame["ask"]) / 2
    frame["relative_spread"] = (frame["ask"] - frame["bid"]) / mid.replace(0, np.nan)
    frame["liquid"] = (
        frame["iv"].gt(0)
        & frame["oi"].ge(min_open_interest)
        & frame["relative_spread"].le(max_relative_spread)
        & frame["days"].gt(0)
    )
    supplied_delta = pd.to_numeric(column(frame, "delta"), errors="coerce").abs()
    estimated = [
        _estimated_abs_delta(t, s, k, d / 365.25, iv, rate)
        for t, s, k, d, iv, rate in zip(
            frame["option_type"],
            frame["spot"],
            frame["strike"],
            frame["days"],
            frame["iv"],
            frame["interest_rate"],
        )
    ]
    frame["abs_delta"] = supplied_delta.fillna(pd.Series(estimated, index=frame.index))
    frame["estimated_gamma_per_usd"] = [
        estimated_gamma_per_usd(s, k, d / 365.25, iv, rate)
        for s, k, d, iv, rate in zip(
            frame["spot"], frame["strike"], frame["days"], frame["iv"], frame["interest_rate"]
        )
    ]
    # USD change in dollar delta for an approximately 1% spot move.
    frame["estimated_gamma_usd_per_1pct"] = (
        frame["estimated_gamma_per_usd"]
        * frame["open_interest_base_units"]
        * frame["spot"].pow(2)
        * 0.01
    )
    frame["near_spot_5pct"] = np.log(frame["strike"] / frame["spot"]).abs().le(math.log(1.05))
    frame["front_7d"] = frame["days"].le(7.0)
    frame["maturity_bucket"] = frame["days"].map(maturity_bucket)

    rows: list[dict[str, object]] = []
    for (asset, bucket), snapshot in frame.groupby(["asset", "bucket"], sort=True):
        liquid = snapshot[snapshot["liquid"]].copy()
        row: dict[str, object] = {
            "asset": asset,
            "prediction_time": bucket,
            "feature_available_time": snapshot["available_time"].max(),
            "options_contract_count": len(snapshot),
            "options_liquid_contract_count": len(liquid),
            "options_surface_reliable": len(liquid) >= 8 and liquid["expiration"].nunique() >= 2,
            "options_information_age_seconds": snapshot["information_age_seconds"].max(),
            "estimated_dealer_gamma_sign_observed": False,
            "estimated_gamma_method": "BLACK_SCHOLES_MARK_IV_POINT_IN_TIME",
            "estimated_gamma_backtest_eligible": False,
        }
        for bucket_name in ("global",) + tuple(item[0] for item in MATURITY_BUCKETS):
            sample = liquid if bucket_name == "global" else liquid[liquid["maturity_bucket"] == bucket_name]
            put_oi = _safe_sum(sample.loc[sample["option_type"] == "put", "oi"])
            call_oi = _safe_sum(sample.loc[sample["option_type"] == "call", "oi"])
            put_volume = _safe_sum(sample.loc[sample["option_type"] == "put", "volume"])
            call_volume = _safe_sum(sample.loc[sample["option_type"] == "call", "volume"])
            row[f"put_oi_{bucket_name}"] = put_oi
            row[f"call_oi_{bucket_name}"] = call_oi
            row[f"put_volume_{bucket_name}"] = put_volume
            row[f"call_volume_{bucket_name}"] = call_volume
            row[f"pcr_oi_{bucket_name}"] = put_oi / call_oi if call_oi and np.isfinite(call_oi) else np.nan
            row[f"pcr_volume_{bucket_name}"] = (
                put_volume / call_volume if call_volume and np.isfinite(call_volume) else np.nan
            )
            gross_gamma = _safe_sum(sample["estimated_gamma_usd_per_1pct"])
            call_gamma = _safe_sum(
                sample.loc[sample["option_type"] == "call", "estimated_gamma_usd_per_1pct"]
            )
            put_gamma = _safe_sum(
                sample.loc[sample["option_type"] == "put", "estimated_gamma_usd_per_1pct"]
            )
            row[f"estimated_gamma_gross_usd_per_1pct_{bucket_name}"] = gross_gamma
            row[f"estimated_gamma_call_usd_per_1pct_{bucket_name}"] = call_gamma
            row[f"estimated_gamma_put_usd_per_1pct_{bucket_name}"] = put_gamma
            row[f"estimated_gamma_call_minus_put_ratio_{bucket_name}"] = (
                (call_gamma - put_gamma) / gross_gamma
                if gross_gamma and np.isfinite(gross_gamma) and np.isfinite(call_gamma) and np.isfinite(put_gamma)
                else np.nan
            )
        gross_global = row["estimated_gamma_gross_usd_per_1pct_global"]
        near_spot_gamma = _safe_sum(
            liquid.loc[liquid["near_spot_5pct"], "estimated_gamma_usd_per_1pct"]
        )
        front_gamma = _safe_sum(liquid.loc[liquid["front_7d"], "estimated_gamma_usd_per_1pct"])
        front_near_gamma = _safe_sum(
            liquid.loc[liquid["near_spot_5pct"] & liquid["front_7d"], "estimated_gamma_usd_per_1pct"]
        )
        strike_gamma = (
            liquid.groupby("strike", as_index=False)["estimated_gamma_usd_per_1pct"]
            .sum(min_count=1)
            .dropna()
            .sort_values("estimated_gamma_usd_per_1pct", ascending=False)
        )
        reference_spot = float(liquid["spot"].median()) if not liquid.empty else np.nan
        strike_gamma_total = _safe_sum(strike_gamma["estimated_gamma_usd_per_1pct"])
        for rank in range(3):
            if rank < len(strike_gamma):
                strike_row = strike_gamma.iloc[rank]
                strike_value = float(strike_row["strike"])
                gamma_value = float(strike_row["estimated_gamma_usd_per_1pct"])
                row[f"estimated_gamma_top_strike_{rank + 1}"] = strike_value
                row[f"estimated_gamma_top_strike_{rank + 1}_share"] = (
                    gamma_value / strike_gamma_total if strike_gamma_total and np.isfinite(strike_gamma_total) else np.nan
                )
                row[f"estimated_gamma_top_strike_{rank + 1}_distance_pct"] = (
                    100.0 * (strike_value / reference_spot - 1.0)
                    if np.isfinite(reference_spot) and reference_spot > 0
                    else np.nan
                )
            else:
                row[f"estimated_gamma_top_strike_{rank + 1}"] = np.nan
                row[f"estimated_gamma_top_strike_{rank + 1}_share"] = np.nan
                row[f"estimated_gamma_top_strike_{rank + 1}_distance_pct"] = np.nan
        valid_gamma = int(liquid["estimated_gamma_usd_per_1pct"].notna().sum())
        row["estimated_gamma_input_coverage"] = valid_gamma / len(liquid) if len(liquid) else 0.0
        row["estimated_gamma_near_spot_5pct_share"] = (
            near_spot_gamma / gross_global if gross_global and np.isfinite(near_spot_gamma) else np.nan
        )
        row["estimated_gamma_front_7d_share"] = (
            front_gamma / gross_global if gross_global and np.isfinite(front_gamma) else np.nan
        )
        row["estimated_gamma_front_7d_near_spot_share"] = (
            front_near_gamma / gross_global if gross_global and np.isfinite(front_near_gamma) else np.nan
        )
        row["estimated_dealer_gamma_lower_bound_usd_per_1pct"] = (
            -gross_global if np.isfinite(gross_global) else np.nan
        )
        row["estimated_dealer_gamma_upper_bound_usd_per_1pct"] = (
            gross_global if np.isfinite(gross_global) else np.nan
        )
        row["estimated_gamma_reliable"] = bool(
            row["options_surface_reliable"]
            and row["estimated_gamma_input_coverage"] >= 0.8
            and np.isfinite(gross_global)
            and gross_global > 0
        )
        for target in target_maturities:
            if liquid.empty:
                row[f"atm_iv_{target}d"] = np.nan
                row[f"skew_{target}d"] = np.nan
                continue
            candidate = liquid.assign(
                maturity_distance=(liquid["days"] - target).abs(),
                moneyness_distance=(np.log(liquid["strike"] / liquid["spot"])).abs(),
            )
            nearest_expiry = candidate.loc[candidate["maturity_distance"].idxmin(), "expiration"]
            expiry_slice = candidate[candidate["expiration"] == nearest_expiry]
            atm = expiry_slice.loc[expiry_slice["moneyness_distance"].idxmin(), "iv"] if not expiry_slice.empty else np.nan
            put_iv = _interpolated_iv(expiry_slice, "put")
            call_iv = _interpolated_iv(expiry_slice, "call")
            row[f"atm_iv_{target}d"] = atm
            # Repository-wide convention: put 25-delta IV minus call 25-delta IV.
            row[f"skew_{target}d"] = put_iv - call_iv if np.isfinite(put_iv) and np.isfinite(call_iv) else np.nan
        row["iv_7d_minus_30d"] = row.get("atm_iv_7d", np.nan) - row.get("atm_iv_30d", np.nan)
        row["iv_30d_minus_90d"] = row.get("atm_iv_30d", np.nan) - row.get("atm_iv_90d", np.nan)
        rows.append(row)
    result = pd.DataFrame(rows).sort_values(["asset", "prediction_time"])
    if not result.empty:
        for name in ("put", "call"):
            result[f"delta_{name}_oi"] = result.groupby("asset")[f"{name}_oi_global"].diff()
    return result.reset_index(drop=True)
