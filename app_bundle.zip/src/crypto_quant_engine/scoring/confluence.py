"""Bounded descriptive confluence. Scores are evidence indexes, never probabilities."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

from ..schema import FeatureState


@dataclass(frozen=True)
class ConfluenceResult:
    score: float | None
    direction: float
    bullish_mass: float
    bearish_mass: float
    coverage: float
    contradiction: float
    contradiction_label: str
    status: str
    family_scores: Mapping[str, float]
    family_weights: Mapping[str, float]
    reason_codes: tuple[str, ...]
    version: str = "confluence-v1"


def compute_confluence(
    states: Sequence[FeatureState], regime: Mapping[str, object], structure: Mapping[str, object], *,
    horizon: str, as_of, config: Mapping[str, object], previous_state: ConfluenceResult | None = None,
) -> ConfluenceResult:
    priors = dict(config.get("priors", {}).get(horizon, {}))
    expected = sum(float(value) for value in priors.values()) or 1.0
    grouped: dict[str, list[FeatureState]] = {}
    for state in states:
        if state.status == "fresh" and state.family in priors and isinstance(state.value, (int, float)) and np.isfinite(state.value):
            grouped.setdefault(state.family, []).append(state)
    scores, raw = {}, {}
    for family, members in grouped.items():
        scores[family] = float(np.clip(np.mean([float(item.value) for item in members]), -1, 1))
        quality = min(item.quality for item in members)
        lineage_count = len({lineage for item in members for lineage in item.lineage_ids})
        redundancy = 1.0 / max(1.0, lineage_count / len(members))
        raw[family] = float(priors[family]) * quality * redundancy
    # Family and group caps; leave excess unallocated rather than inflate sparse evidence.
    weights = {family: min(value, 0.35) for family, value in raw.items()}
    for group, cap in (({"technical", "spot"}, .50), ({"leverage", "liquidations"}, .40), ({"macro", "flows"}, .45)):
        total = sum(weights.get(name, 0) for name in group)
        if total > cap:
            for name in group:
                if name in weights:
                    weights[name] *= cap / total
    coverage = sum(weights.values()) / expected
    bullish = sum(weights[name] * max(score, 0) for name, score in scores.items())
    bearish = sum(weights[name] * max(-score, 0) for name, score in scores.items())
    direction = bullish - bearish
    total_signal = bullish + bearish
    contradiction = 2 * min(bullish, bearish) / total_signal if total_signal else 0.0
    label = "LOW" if contradiction < .25 else "MODERATE" if contradiction < .50 else "HIGH" if contradiction < .75 else "EXTREME"
    reasons = []
    critical_structure = structure.get("valid", True) is False
    unknown_regime = regime.get("required_unknown", False) is True
    if coverage < .60: reasons.append("COVERAGE_BELOW_60_PERCENT")
    if len(grouped) < 3: reasons.append("FEWER_THAN_3_INDEPENDENT_FAMILIES")
    if critical_structure: reasons.append("INVALID_CRITICAL_STRUCTURE")
    if unknown_regime: reasons.append("REQUIRED_REGIME_UNKNOWN")
    if reasons:
        status, score = "INSUFFICIENT_EVIDENCE", None
    elif label in {"HIGH", "EXTREME"} or abs(direction) < .15:
        status, score = "NO_TRADE", 50 + 50 * direction
    else:
        status, score = ("BULLISH" if direction > 0 else "BEARISH"), 50 + 50 * direction
    return ConfluenceResult(score, direction, bullish, bearish, coverage, contradiction, label, status,
                            scores, weights, tuple(reasons))

