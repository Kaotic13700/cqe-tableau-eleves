from __future__ import annotations

import numpy as np
import pandas as pd


def effective_sample_size(values: pd.Series, max_lag: int | None = None) -> float:
    clean = values.dropna().astype(float)
    count = len(clean)
    if count < 3:
        return float(count)
    lags = min(max_lag or int(np.sqrt(count)), count - 2)
    autocorrelations = [clean.autocorr(lag=lag) for lag in range(1, lags + 1)]
    positive = [value for value in autocorrelations if np.isfinite(value) and value > 0]
    denominator = 1 + 2 * sum(positive)
    return max(1.0, count / denominator)

