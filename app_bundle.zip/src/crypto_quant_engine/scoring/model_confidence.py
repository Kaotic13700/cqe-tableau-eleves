from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import INSUFFICIENT_CONFIDENCE


@dataclass(frozen=True)
class ConfidenceReport:
    score: float
    status: str
    components: dict[str, float]
    reasons: tuple[str, ...]

    @property
    def allows_precise_probability(self) -> bool:
        return self.status == "STATISTICALLY_USABLE"


def effective_sample_factor(effective_sample_size: float, minimum: int = 200) -> float:
    if effective_sample_size <= 0:
        return 0.0
    return min(1.0, math.log1p(effective_sample_size) / math.log1p(minimum))


def score_model_confidence(
    *,
    effective_sample_size: float,
    data_quality_score: float,
    regime_similarity: float,
    model_agreement: float,
    calibration_quality: float,
    feature_completeness: float,
    freshness: float,
    distribution_stability: float,
    minimum_effective_samples: int = 200,
    threshold: float = 0.60,
) -> ConfidenceReport:
    components = {
        "effective_sample": effective_sample_factor(effective_sample_size, minimum_effective_samples),
        "data_quality": data_quality_score / 100,
        "regime_similarity": regime_similarity,
        "model_agreement": model_agreement,
        "calibration": calibration_quality,
        "feature_completeness": feature_completeness,
        "freshness": freshness,
        "distribution_stability": distribution_stability,
    }
    components = {name: min(1.0, max(0.0, float(value))) for name, value in components.items()}
    weights = {
        "effective_sample": 0.20,
        "data_quality": 0.18,
        "regime_similarity": 0.12,
        "model_agreement": 0.12,
        "calibration": 0.16,
        "feature_completeness": 0.08,
        "freshness": 0.07,
        "distribution_stability": 0.07,
    }
    score = sum(components[name] * weights[name] for name in components)
    hard_failure = effective_sample_size < minimum_effective_samples or data_quality_score < 70 or calibration_quality < 0.5
    usable = score >= threshold and not hard_failure
    reasons = []
    if effective_sample_size < minimum_effective_samples:
        reasons.append("INSUFFICIENT_EFFECTIVE_SAMPLE")
    if data_quality_score < 70:
        reasons.append("LOW_DATA_QUALITY")
    if calibration_quality < 0.5:
        reasons.append("UNVALIDATED_OR_POOR_CALIBRATION")
    if distribution_stability < 0.5:
        reasons.append("DISTRIBUTION_SHIFT")
    return ConfidenceReport(
        round(score, 4),
        "STATISTICALLY_USABLE" if usable else INSUFFICIENT_CONFIDENCE,
        components,
        tuple(reasons),
    )

