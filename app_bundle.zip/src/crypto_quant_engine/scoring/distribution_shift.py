from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp


def population_stability_index(reference: pd.Series, current: pd.Series, bins: int = 10) -> float:
    reference = reference.dropna().to_numpy(dtype=float)
    current = current.dropna().to_numpy(dtype=float)
    if len(reference) < bins or len(current) < bins:
        return float("nan")
    edges = np.unique(np.quantile(reference, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    ref_counts, _ = np.histogram(reference, bins=edges)
    cur_counts, _ = np.histogram(current, bins=edges)
    ref = np.clip(ref_counts / ref_counts.sum(), 1e-6, None)
    cur = np.clip(cur_counts / cur_counts.sum(), 1e-6, None)
    return float(np.sum((cur - ref) * np.log(cur / ref)))


def shift_report(reference: pd.DataFrame, current: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    rows = []
    for feature in features:
        reference_values, current_values = reference[feature].dropna(), current[feature].dropna()
        statistic, p_value = (
            ks_2samp(reference_values, current_values) if len(reference_values) and len(current_values) else (np.nan, np.nan)
        )
        rows.append(
            {
                "feature": feature,
                "psi": population_stability_index(reference_values, current_values),
                "ks_statistic": statistic,
                "ks_p_value": p_value,
            }
        )
    return pd.DataFrame(rows)

