from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class DataQualityReport:
    score: float
    components: dict[str, float]
    flags: tuple[str, ...]


def score_data_quality(
    frame: pd.DataFrame,
    required_columns: list[str],
    *,
    age_column: str = "information_age_seconds",
    stale_after_seconds: float = 1800,
    expected_sources: int = 1,
    observed_sources: int | None = None,
    timestamp_consistent: bool = True,
    options_surface_reliable: bool | None = None,
) -> DataQualityReport:
    if frame.empty:
        return DataQualityReport(0.0, {"completeness": 0.0}, ("NO_DATA",))
    completeness = (
        float(frame.reindex(columns=required_columns).notna().mean().mean()) if required_columns else 1.0
    )
    if age_column in frame:
        ages = pd.to_numeric(frame[age_column], errors="coerce")
        freshness = float(np.clip(1 - ages.median() / stale_after_seconds, 0, 1)) if ages.notna().any() else 0.0
    else:
        freshness = 0.5
    source_count = expected_sources if observed_sources is None else observed_sources
    source_coverage = min(1.0, source_count / max(expected_sources, 1))
    timestamp_score = 1.0 if timestamp_consistent else 0.0
    surface_score = 1.0 if options_surface_reliable is not False else 0.4
    components = {
        "completeness": completeness,
        "freshness": freshness,
        "source_coverage": source_coverage,
        "timestamp_consistency": timestamp_score,
        "options_surface": surface_score,
    }
    weights = {"completeness": 0.35, "freshness": 0.25, "source_coverage": 0.20, "timestamp_consistency": 0.15, "options_surface": 0.05}
    score = 100 * sum(components[name] * weights[name] for name in components)
    flags: list[str] = []
    if completeness < 0.8:
        flags.append("INCOMPLETE_FEATURES")
    if freshness < 0.5:
        flags.append("STALE_DATA")
    if source_coverage < 1:
        flags.append("REDUCED_SOURCE_COVERAGE")
    if not timestamp_consistent:
        flags.append("TIMESTAMP_INCONSISTENCY")
    if options_surface_reliable is False:
        flags.append("UNRELIABLE_OPTIONS_SURFACE")
    return DataQualityReport(round(score, 2), components, tuple(flags))
