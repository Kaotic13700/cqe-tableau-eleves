from __future__ import annotations


def quality_alerts(data_quality_score: float, confidence_status: str, flags: tuple[str, ...]) -> list[str]:
    alerts = list(flags)
    if data_quality_score < 70:
        alerts.append("MODEL_OUTPUT_SUPPRESSED_LOW_DATA_QUALITY")
    if confidence_status != "STATISTICALLY_USABLE":
        alerts.append("PRECISE_PROBABILITY_SUPPRESSED")
    return sorted(set(alerts))

