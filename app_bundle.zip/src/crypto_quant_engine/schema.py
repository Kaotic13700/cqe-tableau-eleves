from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Mapping

from .constants import ASSETS
from .time import ensure_utc, isoformat_z


@dataclass(frozen=True)
class Observation:
    source: str
    data_family: str
    asset: str
    instrument: str
    event_time: datetime
    exchange_time: datetime
    received_time: datetime
    available_time: datetime
    ingestion_time: datetime
    values: Mapping[str, Any]
    quote_currency: str | None = None
    information_age_seconds: float = 0.0
    transformation_version: str = "raw-v1"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.asset not in ASSETS and self.asset != "MACRO":
            raise ValueError(f"Unsupported asset: {self.asset}")
        for name in (
            "event_time",
            "exchange_time",
            "received_time",
            "available_time",
            "ingestion_time",
        ):
            object.__setattr__(self, name, ensure_utc(getattr(self, name)))
        if self.available_time > self.ingestion_time:
            raise ValueError("available_time cannot be after ingestion_time")
        if self.received_time > self.ingestion_time:
            raise ValueError("received_time cannot be after ingestion_time")
        if self.information_age_seconds < 0:
            raise ValueError("information_age_seconds cannot be negative")

    @property
    def observation_id(self) -> str:
        identity = {
            "source": self.source,
            "family": self.data_family,
            "asset": self.asset,
            "instrument": self.instrument,
            "event_time": isoformat_z(self.event_time),
            "available_time": isoformat_z(self.available_time),
            "version": self.transformation_version,
            "values": self.values,
        }
        payload = json.dumps(identity, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(payload.encode()).hexdigest()

    def to_record(self) -> dict[str, Any]:
        record = asdict(self)
        for name in (
            "event_time",
            "exchange_time",
            "received_time",
            "available_time",
            "ingestion_time",
        ):
            record[name] = isoformat_z(record[name])
        record["observation_id"] = self.observation_id
        record["values"] = dict(self.values)
        record["metadata"] = dict(self.metadata)
        return record


def validate_available_at(observations: list[Observation], prediction_time: datetime) -> None:
    cutoff = ensure_utc(prediction_time)
    leaking = [item.observation_id for item in observations if item.available_time > cutoff]
    if leaking:
        raise ValueError(f"{len(leaking)} observations were not available at prediction_time")

