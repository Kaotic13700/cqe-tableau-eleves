from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Iterable, Literal, Mapping

from .constants import ASSETS
from .time import ensure_utc, isoformat_z


FeatureStatus = Literal["fresh", "stale", "missing", "invalid"]


@dataclass(frozen=True)
class FeatureState:
    """Serializable point-in-time state for one feature, evaluated at an explicit clock."""

    name: str
    value: Any
    unit: str
    asset: str
    family: str
    source_ids: tuple[str, ...]
    lineage_ids: tuple[str, ...]
    event_time: datetime | None
    available_time: datetime | None
    evaluated_at: datetime
    age_seconds: float | None
    ttl_seconds: float
    status: FeatureStatus
    quality: float
    reason_codes: tuple[str, ...] = ()
    backtest_eligible: bool = False
    transformation_version: str = "feature-state-v1"

    def to_record(self) -> dict[str, Any]:
        record = asdict(self)
        for name in ("event_time", "available_time", "evaluated_at"):
            value = record[name]
            record[name] = isoformat_z(value) if value is not None else None
        record["source_ids"] = list(self.source_ids)
        record["lineage_ids"] = list(self.lineage_ids)
        record["reason_codes"] = list(self.reason_codes)
        return record


def evaluate_feature_states(states: Iterable[FeatureState], *, as_of: datetime) -> list[FeatureState]:
    """Re-age states without reviving missing, invalid, future or stale information."""
    cutoff = ensure_utc(as_of)
    evaluated: list[FeatureState] = []
    for state in states:
        reasons = list(state.reason_codes)
        available = ensure_utc(state.available_time) if state.available_time is not None else None
        if state.value is None or available is None:
            status: FeatureStatus = "missing"
            age = None
            reasons.append("MISSING_VALUE_OR_TIMESTAMP")
        elif available > cutoff:
            status = "invalid"
            age = None
            reasons.append("AVAILABLE_IN_FUTURE")
        else:
            age = (cutoff - available).total_seconds()
            if state.status == "invalid":
                status = "invalid"
            elif age > state.ttl_seconds:
                status = "stale"
                reasons.append("TTL_EXCEEDED")
            else:
                status = "fresh"
        evaluated.append(FeatureState(**{
            **asdict(state), "evaluated_at": cutoff, "age_seconds": age, "status": status,
            "quality": max(0.0, min(1.0, float(state.quality))),
            "reason_codes": tuple(dict.fromkeys(reasons)),
        }))
    return evaluated


@dataclass(frozen=True)
class Observation:
    source: str
    data_family: str
    asset: str
    instrument: str
    event_time: datetime
    exchange_time: datetime
    received_time: datetime
    available_time: datetime
    ingestion_time: datetime
    values: Mapping[str, Any]
    quote_currency: str | None = None
    information_age_seconds: float = 0.0
    transformation_version: str = "raw-v1"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.asset not in ASSETS and self.asset != "MACRO":
            raise ValueError(f"Unsupported asset: {self.asset}")
        for name in (
            "event_time",
            "exchange_time",
            "received_time",
            "available_time",
            "ingestion_time",
        ):
            object.__setattr__(self, name, ensure_utc(getattr(self, name)))
        if self.available_time > self.ingestion_time:
            raise ValueError("available_time cannot be after ingestion_time")
        if self.received_time > self.ingestion_time:
            raise ValueError("received_time cannot be after ingestion_time")
        if self.information_age_seconds < 0:
            raise ValueError("information_age_seconds cannot be negative")

    @property
    def observation_id(self) -> str:
        identity = {
            "source": self.source,
            "family": self.data_family,
            "asset": self.asset,
            "instrument": self.instrument,
            "event_time": isoformat_z(self.event_time),
            "available_time": isoformat_z(self.available_time),
            "version": self.transformation_version,
            "values": self.values,
        }
        payload = json.dumps(identity, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(payload.encode()).hexdigest()

    def to_record(self) -> dict[str, Any]:
        record = asdict(self)
        for name in (
            "event_time",
            "exchange_time",
            "received_time",
            "available_time",
            "ingestion_time",
        ):
            record[name] = isoformat_z(record[name])
        record["observation_id"] = self.observation_id
        record["values"] = dict(self.values)
        record["metadata"] = dict(self.metadata)
        return record


def validate_available_at(observations: list[Observation], prediction_time: datetime) -> None:
    cutoff = ensure_utc(prediction_time)
    leaking = [item.observation_id for item in observations if item.available_time > cutoff]
    if leaking:
        raise ValueError(f"{len(leaking)} observations were not available at prediction_time")
