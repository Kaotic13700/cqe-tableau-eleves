from __future__ import annotations

import numpy as np


def embargo_before_test(test_start: int, observations: int) -> np.ndarray:
    return np.arange(max(0, test_start - observations), test_start)

