from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class PurgedWalkForwardSplit:
    minimum_train_size: int
    test_size: int
    step_size: int | None = None
    embargo_size: int = 0

    def split(
        self,
        prediction_times: pd.Series,
        label_end_times: pd.Series,
    ):
        times = pd.to_datetime(prediction_times, utc=True).reset_index(drop=True)
        ends = pd.to_datetime(label_end_times, utc=True).reset_index(drop=True)
        if not times.is_monotonic_increasing:
            raise ValueError("prediction_times must be sorted")
        step = self.step_size or self.test_size
        test_start = self.minimum_train_size
        while test_start + self.test_size <= len(times):
            test_stop = test_start + self.test_size
            test_indices = np.arange(test_start, test_stop)
            cutoff = times.iloc[test_start]
            candidate = np.arange(0, max(0, test_start - self.embargo_size))
            # Purge any training label whose outcome window touches the test interval.
            valid = ends.iloc[candidate].notna().to_numpy() & (ends.iloc[candidate] < cutoff).to_numpy()
            train_indices = candidate[valid]
            if len(train_indices):
                yield train_indices, test_indices
            test_start += step

