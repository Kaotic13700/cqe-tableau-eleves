from __future__ import annotations

import pandas as pd


def threshold_sensitivity(feature: pd.Series, target: pd.Series, thresholds: list[float]) -> pd.DataFrame:
    rows = []
    for threshold in thresholds:
        selected = target[feature < threshold].dropna()
        rows.append(
            {
                "threshold": threshold,
                "sample_count": len(selected),
                "conditional_rate": selected.mean() if len(selected) else float("nan"),
                "base_rate": target.mean(),
            }
        )
    return pd.DataFrame(rows)

