from __future__ import annotations

from collections.abc import Callable

import pandas as pd


def family_ablation(
    evaluator: Callable[[list[str]], dict[str, float]],
    feature_families: dict[str, list[str]],
) -> pd.DataFrame:
    all_features = [feature for values in feature_families.values() for feature in values]
    baseline = evaluator(all_features)
    rows = [{"removed_family": "NONE", **baseline}]
    for family, removed in feature_families.items():
        remaining = [feature for feature in all_features if feature not in removed]
        rows.append({"removed_family": family, **evaluator(remaining)})
    return pd.DataFrame(rows)

