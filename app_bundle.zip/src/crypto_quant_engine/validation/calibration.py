from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, log_loss


def calibration_table(y_true, probability, bins: int = 10) -> pd.DataFrame:
    frame = pd.DataFrame({"actual": y_true, "probability": probability}).dropna()
    frame["bin"] = pd.cut(frame["probability"], bins=np.linspace(0, 1, bins + 1), include_lowest=True)
    return frame.groupby("bin", observed=False).agg(
        sample_count=("actual", "size"),
        mean_probability=("probability", "mean"),
        observed_rate=("actual", "mean"),
    ).reset_index()


def calibration_metrics(y_true, probability, bins: int = 10) -> dict[str, float]:
    table = calibration_table(y_true, probability, bins)
    total = table["sample_count"].sum()
    ece = (
        (table["sample_count"] / total * (table["mean_probability"] - table["observed_rate"]).abs()).sum()
        if total
        else float("nan")
    )
    return {
        "brier": float(brier_score_loss(y_true, probability)),
        "log_loss": float(log_loss(y_true, probability, labels=[0, 1])),
        "expected_calibration_error": float(ece),
    }

