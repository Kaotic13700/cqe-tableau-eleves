from __future__ import annotations

from collections.abc import Callable

import pandas as pd
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

from .purged_cv import PurgedWalkForwardSplit


def walk_forward_evaluate(
    frame: pd.DataFrame,
    model_factory: Callable[[], object],
    target_column: str,
    splitter: PurgedWalkForwardSplit,
    time_column: str = "prediction_time",
    label_end_column: str = "label_end_time",
) -> tuple[pd.DataFrame, pd.DataFrame]:
    ordered = frame.sort_values(time_column).reset_index(drop=True)
    predictions: list[pd.DataFrame] = []
    metrics: list[dict[str, float | int]] = []
    for fold, (train_indices, test_indices) in enumerate(
        splitter.split(ordered[time_column], ordered[label_end_column])
    ):
        train, test = ordered.iloc[train_indices], ordered.iloc[test_indices]
        test = test[test[target_column].notna()]
        if test.empty:
            continue
        model = model_factory()
        model.fit(train, train[target_column])
        probability = model.predict_proba(test)[:, 1]
        actual = test[target_column].astype(int).to_numpy()
        fold_predictions = test[[time_column, target_column]].copy()
        fold_predictions["probability"] = probability
        fold_predictions["fold"] = fold
        predictions.append(fold_predictions)
        metrics.append(
            {
                "fold": fold,
                "train_count": len(train),
                "test_count": len(test),
                "brier": brier_score_loss(actual, probability),
                "log_loss": log_loss(actual, probability, labels=[0, 1]),
                "roc_auc": roc_auc_score(actual, probability) if len(set(actual)) == 2 else float("nan"),
            }
        )
    prediction_frame = pd.concat(predictions, ignore_index=True) if predictions else pd.DataFrame()
    return prediction_frame, pd.DataFrame(metrics)

