from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_regression


def correlation_report(frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
    numeric = frame.select_dtypes(include=np.number).dropna(axis=1, how="all")
    return {"pearson": numeric.corr(), "spearman": numeric.corr(method="spearman")}


def vif_report(frame: pd.DataFrame) -> pd.DataFrame:
    numeric = frame.select_dtypes(include=np.number).dropna()
    if numeric.empty:
        return pd.DataFrame(columns=["feature", "vif"])
    matrix = numeric.to_numpy(dtype=float)
    values = []
    for index in range(matrix.shape[1]):
        target = matrix[:, index]
        predictors = np.delete(matrix, index, axis=1)
        predictors = np.column_stack([np.ones(len(predictors)), predictors])
        fitted = predictors @ np.linalg.lstsq(predictors, target, rcond=None)[0]
        residual = np.sum((target - fitted) ** 2)
        total = np.sum((target - target.mean()) ** 2)
        r_squared = 1 - residual / total if total else 1.0
        values.append(float("inf") if r_squared >= 1 else 1 / (1 - r_squared))
    return pd.DataFrame({"feature": numeric.columns, "vif": values})


def mutual_information(frame: pd.DataFrame, target: pd.Series) -> pd.Series:
    valid = frame.notna().all(axis=1) & target.notna()
    values = mutual_info_regression(frame.loc[valid], target.loc[valid], random_state=20260825)
    return pd.Series(values, index=frame.columns, name="mutual_information")
