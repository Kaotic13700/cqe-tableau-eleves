from __future__ import annotations

from collections.abc import Callable

import pandas as pd
from pandas.testing import assert_frame_equal


def assert_available_before_prediction(
    frame: pd.DataFrame,
    available_column: str = "available_time",
    prediction_column: str = "prediction_time",
) -> None:
    available = pd.to_datetime(frame[available_column], utc=True)
    prediction = pd.to_datetime(frame[prediction_column], utc=True)
    if (available > prediction).any():
        raise AssertionError("future information is present in features")


def assert_prefix_invariant(
    builder: Callable[[pd.DataFrame], pd.DataFrame],
    data: pd.DataFrame,
    prefix_length: int,
    comparable_columns: list[str],
) -> None:
    prefix = builder(data.iloc[:prefix_length].copy())
    full_prefix = builder(data.copy()).iloc[: len(prefix)]
    assert_frame_equal(
        prefix[comparable_columns].reset_index(drop=True),
        full_prefix[comparable_columns].reset_index(drop=True),
        check_dtype=False,
    )

