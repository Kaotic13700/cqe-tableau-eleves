from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

from ..schema import Observation
from ..time import ensure_utc, isoformat_z


DDL = """
CREATE TABLE IF NOT EXISTS observations (
    observation_id TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    data_family TEXT NOT NULL,
    asset TEXT NOT NULL,
    instrument TEXT NOT NULL,
    quote_currency TEXT,
    event_time TEXT NOT NULL,
    exchange_time TEXT NOT NULL,
    received_time TEXT NOT NULL,
    available_time TEXT NOT NULL,
    ingestion_time TEXT NOT NULL,
    information_age_seconds REAL NOT NULL,
    transformation_version TEXT NOT NULL,
    values_json TEXT NOT NULL,
    metadata_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_observations_lookup
ON observations(asset, data_family, available_time);
CREATE INDEX IF NOT EXISTS idx_observations_event
ON observations(source, instrument, event_time);
CREATE INDEX IF NOT EXISTS idx_observations_family_available
ON observations(data_family, available_time);
"""


class NormalizedStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.executescript(DDL)

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def insert(self, observations: Iterable[Observation]) -> int:
        rows = []
        for item in observations:
            rows.append(
                (
                    item.observation_id,
                    item.source,
                    item.data_family,
                    item.asset,
                    item.instrument,
                    item.quote_currency,
                    isoformat_z(item.event_time),
                    isoformat_z(item.exchange_time),
                    isoformat_z(item.received_time),
                    isoformat_z(item.available_time),
                    isoformat_z(item.ingestion_time),
                    item.information_age_seconds,
                    item.transformation_version,
                    json.dumps(dict(item.values), sort_keys=True, default=str),
                    json.dumps(dict(item.metadata), sort_keys=True, default=str),
                )
            )
        if not rows:
            return 0
        with self.connect() as connection:
            before = connection.total_changes
            connection.executemany(
                "INSERT OR IGNORE INTO observations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                rows,
            )
            return connection.total_changes - before

    def latest_event_time(
        self,
        *,
        source: str,
        data_family: str,
        asset: str,
        transformation_version: str | None = None,
    ) -> datetime | None:
        clauses = ["source = ?", "data_family = ?", "asset = ?"]
        parameters: list[str] = [source, data_family, asset]
        if transformation_version is not None:
            clauses.append("transformation_version = ?")
            parameters.append(transformation_version)
        with self.connect() as connection:
            row = connection.execute(
                "SELECT event_time FROM observations WHERE "
                + " AND ".join(clauses)
                + " ORDER BY julianday(event_time) DESC LIMIT 1",
                parameters,
            ).fetchone()
        if row is None:
            return None
        return ensure_utc(pd.Timestamp(row[0]))

    def latest_payload(
        self,
        *,
        source: str,
        data_family: str,
        asset: str,
        instrument: str | None = None,
        transformation_version: str | None = None,
    ) -> dict[str, Any] | None:
        """Return the latest normalized payload for restart-safe collector state.

        State is read from the same append-only observation that carries the
        aggregate. A trade cursor therefore advances only after the observation
        has been inserted successfully; no mutable sidecar can get ahead of the
        normalized database.
        """

        clauses = ["source = ?", "data_family = ?", "asset = ?"]
        parameters: list[str] = [source, data_family, asset]
        if instrument is not None:
            clauses.append("instrument = ?")
            parameters.append(instrument)
        if transformation_version is not None:
            clauses.append("transformation_version = ?")
            parameters.append(transformation_version)
        # Column names and clauses are fixed by this method; all caller values
        # remain bound parameters. This is intentionally dynamic but not
        # user-controlled SQL.
        statement = (
            "SELECT event_time, exchange_time, received_time, available_time, "
            "ingestion_time, values_json, metadata_json FROM observations WHERE "
            + " AND ".join(clauses)
            + " ORDER BY julianday(available_time) DESC LIMIT 1"
        )
        with self.connect() as connection:
            row = connection.execute(statement, parameters).fetchone()
        if row is None:
            return None
        return {
            "event_time": ensure_utc(pd.Timestamp(row[0])),
            "exchange_time": ensure_utc(pd.Timestamp(row[1])),
            "received_time": ensure_utc(pd.Timestamp(row[2])),
            "available_time": ensure_utc(pd.Timestamp(row[3])),
            "ingestion_time": ensure_utc(pd.Timestamp(row[4])),
            "values": json.loads(row[5]),
            "metadata": json.loads(row[6]),
        }

    def query(
        self,
        *,
        asset: str | None = None,
        data_family: str | None = None,
        prediction_time: datetime | None = None,
        transformation_version: str | None = None,
        available_after: datetime | None = None,
    ) -> pd.DataFrame:
        clauses: list[str] = []
        parameters: list[str] = []
        if asset:
            clauses.append("asset = ?")
            parameters.append(asset)
        if data_family:
            clauses.append("data_family = ?")
            parameters.append(data_family)
        if prediction_time:
            clauses.append("julianday(available_time) <= julianday(?)")
            parameters.append(isoformat_z(ensure_utc(prediction_time)))
        if transformation_version:
            clauses.append("transformation_version = ?")
            parameters.append(transformation_version)
        if available_after:
            # New observations use a fixed-width UTC ISO representation, so
            # textual comparison is chronological and can use the covering index.
            clauses.append("available_time >= ?")
            parameters.append(isoformat_z(ensure_utc(available_after)))
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        with self.connect() as connection:
            frame = pd.read_sql_query(
                "SELECT * FROM observations" + where + " ORDER BY julianday(available_time)",
                connection,
                params=parameters,
            )
        if frame.empty:
            return frame
        for name in ("event_time", "exchange_time", "received_time", "available_time", "ingestion_time"):
            # Valid ISO-8601 timestamps can legitimately mix second and microsecond
            # precision. Pandas otherwise infers one strict format from the first row.
            frame[name] = pd.to_datetime(frame[name], utc=True, format="mixed")
        values = pd.json_normalize(frame.pop("values_json").map(json.loads)).add_prefix("value.")
        metadata = pd.json_normalize(frame.pop("metadata_json").map(json.loads)).add_prefix("meta.")
        return pd.concat([frame.reset_index(drop=True), values, metadata], axis=1)
