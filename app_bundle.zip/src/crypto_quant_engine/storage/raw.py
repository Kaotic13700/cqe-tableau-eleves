from __future__ import annotations

import hashlib
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from ..time import ensure_utc, isoformat_z, utc_now


class RawStore:
    """Append-only JSONL store. A raw payload is never updated in place."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self._lock = threading.Lock()

    def append(
        self,
        source: str,
        endpoint: str,
        payload: Any,
        received_time: datetime,
        request_metadata: dict[str, Any] | None = None,
    ) -> str:
        received = ensure_utc(received_time)
        serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        digest = hashlib.sha256(serialized.encode()).hexdigest()
        path = self.root / source / received.strftime("%Y/%m/%d") / "responses.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        envelope = {
            "content_hash": digest,
            "source": source,
            "endpoint": endpoint,
            "received_time": isoformat_z(received),
            "ingestion_time": isoformat_z(utc_now()),
            "request_metadata": request_metadata or {},
            "payload": payload,
        }
        line = json.dumps(envelope, sort_keys=True, default=str) + "\n"
        with self._lock, path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(line)
            handle.flush()
        return digest

