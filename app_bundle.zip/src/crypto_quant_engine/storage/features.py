from __future__ import annotations

import json
import uuid
from pathlib import Path

import pandas as pd


class FeatureStore:
    """Versioned CSV snapshots; an existing version is never overwritten."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)

    def write(self, frame: pd.DataFrame, dataset_version: str, metadata: dict[str, object]) -> Path:
        directory = self.root / dataset_version
        directory.mkdir(parents=True, exist_ok=True)
        data_path = directory / "features.csv.gz"
        metadata_path = directory / "metadata.json"
        if data_path.exists() or metadata_path.exists():
            raise FileExistsError(f"feature dataset version already exists: {dataset_version}")
        frame.to_csv(data_path, index=False, compression="gzip")
        metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True, default=str), encoding="utf-8")
        return data_path

    def read(self, dataset_version: str) -> pd.DataFrame:
        return pd.read_csv(self.root / dataset_version / "features.csv.gz")

    def write_live(self, frame: pd.DataFrame, feature_version: str, metadata: dict[str, object]) -> Path:
        """Atomically refresh a non-historical cache under an explicitly versioned schema."""

        directory = self.root / feature_version
        directory.mkdir(parents=True, exist_ok=True)
        data_path = directory / "features.csv.gz"
        metadata_path = directory / "metadata.json"
        token = uuid.uuid4().hex
        data_tmp = directory / f".{token}.features.csv.gz.tmp"
        metadata_tmp = directory / f".{token}.metadata.json.tmp"
        frame.to_csv(data_tmp, index=False, compression="gzip")
        metadata_tmp.write_text(
            json.dumps(metadata, indent=2, sort_keys=True, default=str), encoding="utf-8"
        )
        data_tmp.replace(data_path)
        metadata_tmp.replace(metadata_path)
        return data_path
