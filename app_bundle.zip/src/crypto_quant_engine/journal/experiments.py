from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DDL = """
CREATE TABLE IF NOT EXISTS experiments (
    experiment_id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    code_version TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    feature_version TEXT NOT NULL,
    model_config_json TEXT NOT NULL,
    train_dates TEXT NOT NULL,
    validation_dates TEXT NOT NULL,
    test_dates TEXT NOT NULL,
    random_seed INTEGER NOT NULL,
    metrics_json TEXT NOT NULL,
    status TEXT NOT NULL,
    notes TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS experiments_no_delete
BEFORE DELETE ON experiments BEGIN SELECT RAISE(ABORT, 'experiments must be retained'); END;
CREATE TRIGGER IF NOT EXISTS experiments_no_update
BEFORE UPDATE ON experiments BEGIN SELECT RAISE(ABORT, 'experiments are immutable'); END;
"""


class ExperimentRegistry:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as connection:
            connection.executescript(DDL)

    def record(self, experiment: dict[str, Any]) -> str:
        experiment_id = str(uuid.uuid4())
        required = (
            "code_version",
            "dataset_version",
            "feature_version",
            "model_config",
            "train_dates",
            "validation_dates",
            "test_dates",
            "random_seed",
            "metrics",
            "status",
        )
        missing = [name for name in required if name not in experiment]
        if missing:
            raise ValueError(f"missing experiment fields: {missing}")
        with sqlite3.connect(self.path) as connection:
            connection.execute(
                "INSERT INTO experiments VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    experiment_id,
                    datetime.now(timezone.utc).isoformat(),
                    experiment["code_version"],
                    experiment["dataset_version"],
                    experiment["feature_version"],
                    json.dumps(experiment["model_config"], sort_keys=True),
                    experiment["train_dates"],
                    experiment["validation_dates"],
                    experiment["test_dates"],
                    experiment["random_seed"],
                    json.dumps(experiment["metrics"], sort_keys=True),
                    experiment["status"],
                    experiment.get("notes", ""),
                ),
            )
        return experiment_id
