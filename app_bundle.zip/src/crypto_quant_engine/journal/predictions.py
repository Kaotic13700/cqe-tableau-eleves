from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any


DDL = """
CREATE TABLE IF NOT EXISTS predictions (
    prediction_id TEXT PRIMARY KEY,
    prediction_timestamp TEXT NOT NULL,
    available_data_timestamp TEXT NOT NULL,
    asset TEXT NOT NULL,
    price REAL NOT NULL,
    raw_features_json TEXT NOT NULL,
    normalized_features_json TEXT NOT NULL,
    macro_regime TEXT NOT NULL,
    market_regime_json TEXT NOT NULL,
    model_version TEXT NOT NULL,
    training_window TEXT NOT NULL,
    raw_probability REAL,
    calibrated_probability REAL,
    confidence_json TEXT NOT NULL,
    data_quality_json TEXT NOT NULL,
    expected_mae REAL,
    expected_mfe REAL,
    status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS realized_outcomes (
    prediction_id TEXT NOT NULL,
    horizon TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    outcome_json TEXT NOT NULL,
    PRIMARY KEY (prediction_id, horizon),
    FOREIGN KEY (prediction_id) REFERENCES predictions(prediction_id)
);
CREATE TRIGGER IF NOT EXISTS predictions_no_update
BEFORE UPDATE ON predictions BEGIN SELECT RAISE(ABORT, 'predictions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS predictions_no_delete
BEFORE DELETE ON predictions BEGIN SELECT RAISE(ABORT, 'predictions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS outcomes_no_update
BEFORE UPDATE ON realized_outcomes BEGIN SELECT RAISE(ABORT, 'outcomes are append-only'); END;
CREATE TRIGGER IF NOT EXISTS outcomes_no_delete
BEFORE DELETE ON realized_outcomes BEGIN SELECT RAISE(ABORT, 'outcomes are append-only'); END;
"""


class PredictionJournal:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.executescript(DDL)

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def record(self, prediction: dict[str, Any]) -> str:
        required = {
            "prediction_timestamp",
            "available_data_timestamp",
            "asset",
            "price",
            "raw_features",
            "normalized_features",
            "macro_regime",
            "market_regime",
            "model_version",
            "training_window",
            "confidence",
            "data_quality",
            "status",
        }
        missing = required - prediction.keys()
        if missing:
            raise ValueError(f"missing prediction fields: {sorted(missing)}")
        identity = json.dumps(
            {key: prediction[key] for key in ("prediction_timestamp", "asset", "model_version")},
            sort_keys=True,
        )
        prediction_id = hashlib.sha256(identity.encode()).hexdigest()
        values = (
            prediction_id,
            prediction["prediction_timestamp"],
            prediction["available_data_timestamp"],
            prediction["asset"],
            prediction["price"],
            json.dumps(prediction["raw_features"], sort_keys=True, default=str),
            json.dumps(prediction["normalized_features"], sort_keys=True, default=str),
            prediction["macro_regime"],
            json.dumps(prediction["market_regime"], sort_keys=True, default=str),
            prediction["model_version"],
            prediction["training_window"],
            prediction.get("raw_probability"),
            prediction.get("calibrated_probability"),
            json.dumps(prediction["confidence"], sort_keys=True, default=str),
            json.dumps(prediction["data_quality"], sort_keys=True, default=str),
            prediction.get("expected_mae"),
            prediction.get("expected_mfe"),
            prediction["status"],
        )
        with self.connect() as connection:
            connection.execute("INSERT INTO predictions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", values)
        return prediction_id

    def append_outcome(self, prediction_id: str, horizon: str, recorded_at: str, outcome: dict[str, Any]) -> None:
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO realized_outcomes VALUES (?,?,?,?)",
                (prediction_id, horizon, recorded_at, json.dumps(outcome, sort_keys=True, default=str)),
            )

