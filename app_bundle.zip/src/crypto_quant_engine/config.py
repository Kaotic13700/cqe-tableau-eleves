from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml


def repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_yaml(name: str, config_dir: str | Path | None = None) -> dict[str, Any]:
    directory = Path(config_dir) if config_dir else repository_root() / "config"
    with (directory / name).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    return value or {}


def data_dir() -> Path:
    configured = os.getenv("CQE_DATA_DIR")
    return Path(configured) if configured else repository_root() / "data"

