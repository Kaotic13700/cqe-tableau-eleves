from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import pandas as pd


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def ensure_utc(value: Any) -> datetime:
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        raise ValueError(f"Timestamp must be timezone-aware: {value!r}")
    return timestamp.tz_convert("UTC").to_pydatetime()


def milliseconds_to_utc(value: int | float | str) -> datetime:
    return pd.Timestamp(int(value), unit="ms", tz="UTC").to_pydatetime()


def isoformat_z(value: datetime) -> str:
    # A fixed precision keeps textual timestamps sortable in SQLite while the
    # parser remains compatible with older rows that used whole seconds.
    return ensure_utc(value).isoformat(timespec="microseconds").replace("+00:00", "Z")
