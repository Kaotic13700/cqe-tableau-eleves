from __future__ import annotations

import numpy as np
import pandas as pd


def classify_dimension(impulse_z: pd.Series, positive: str, neutral: str, negative: str) -> pd.Series:
    return pd.Series(
        np.select([impulse_z > 0.5, impulse_z < -0.5], [positive, negative], default=neutral),
        index=impulse_z.index,
    ).mask(impulse_z.isna(), "UNCERTAIN")


def classify_liquidity(impulse_z: pd.Series) -> pd.Series:
    return classify_dimension(impulse_z, "EXPANDING", "NEUTRAL", "CONTRACTING")


def classify_macro_regimes(frame: pd.DataFrame) -> pd.DataFrame:
    """Classify four independent macro dimensions; missing dimensions remain uncertain."""
    result = frame.copy()
    index = result.index
    result["growth_regime"] = classify_dimension(
        result.get("growth_impulse_z", pd.Series(np.nan, index=index)),
        "ACCELERATING",
        "STABLE",
        "DECELERATING",
    )
    result["inflation_regime"] = classify_dimension(
        result.get("inflation_impulse_z", pd.Series(np.nan, index=index)),
        "ACCELERATING",
        "STABLE",
        "DECELERATING",
    )
    result["liquidity_regime"] = classify_liquidity(
        result.get("liquidity_impulse_z", pd.Series(np.nan, index=index))
    )
    # Positive policy impulse means tightening pressure by convention here.
    result["policy_regime"] = classify_dimension(
        result.get("policy_tightening_impulse_z", pd.Series(np.nan, index=index)),
        "TIGHTENING",
        "NEUTRAL",
        "EASING",
    )
    result["macro_regime"] = result[[
        "growth_regime", "inflation_regime", "liquidity_regime", "policy_regime"
    ]].astype(str).agg(" / ".join, axis=1)
    return result
