from __future__ import annotations

import numpy as np
import pandas as pd


def classify_positioning(
    funding_z: pd.Series,
    oi_change_z: pd.Series,
    skew_30d: pd.Series | None = None,
) -> pd.Series:
    skew = skew_30d if skew_30d is not None else pd.Series(np.nan, index=funding_z.index)
    result = np.select(
        [
            (funding_z > 1) & (oi_change_z > 0.5),
            (funding_z < -1) & (oi_change_z > 0.5),
            (funding_z > 0) & (skew > 0),
            (funding_z < 0) & (skew < 0),
            funding_z.abs() <= 1,
        ],
        ["LONG_CROWDED", "SHORT_CROWDED", "HEDGED_BULLISH", "HEDGED_BEARISH", "NEUTRAL"],
        default="UNCERTAIN",
    )
    return pd.Series(result, index=funding_z.index)

