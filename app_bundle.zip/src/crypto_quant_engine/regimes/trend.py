from __future__ import annotations

import numpy as np
import pandas as pd


def classify_trend(price: pd.Series, fast: int = 16, slow: int = 64, tolerance: float = 0.005) -> pd.Series:
    fast_mean = price.ewm(span=fast, adjust=False, min_periods=fast).mean()
    slow_mean = price.ewm(span=slow, adjust=False, min_periods=slow).mean()
    distance = fast_mean / slow_mean - 1
    return pd.Series(
        np.select([distance > tolerance, distance < -tolerance], ["UP", "DOWN"], default="RANGE"),
        index=price.index,
    ).mask(slow_mean.isna(), "UNCERTAIN")

