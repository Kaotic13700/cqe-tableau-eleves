from __future__ import annotations

import numpy as np
import pandas as pd


def classify_volatility(price: pd.Series, window: int = 96) -> pd.Series:
    realized = np.log(price).diff().rolling(window, min_periods=window // 2).std()
    history = realized.shift(1).rolling(window * 10, min_periods=window * 2)
    low, high, stress = history.quantile(0.25), history.quantile(0.75), history.quantile(0.95)
    values = np.select(
        [realized >= stress, realized >= high, realized <= low],
        ["STRESS", "HIGH", "LOW"],
        default="NORMAL",
    )
    return pd.Series(values, index=price.index).mask(realized.isna(), "UNCERTAIN")

