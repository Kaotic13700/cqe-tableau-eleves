from __future__ import annotations

import numpy as np
import pandas as pd


def classify_driver(spot_flow_z: pd.Series, perp_flow_z: pd.Series, minimum_signal: float = 0.5) -> pd.Series:
    spot_strength = spot_flow_z.abs()
    perp_strength = perp_flow_z.abs()
    return pd.Series(
        np.select(
            [
                (spot_strength >= minimum_signal) & (spot_strength > perp_strength * 1.25),
                (perp_strength >= minimum_signal) & (perp_strength > spot_strength * 1.25),
                (spot_strength >= minimum_signal) | (perp_strength >= minimum_signal),
            ],
            ["SPOT_DRIVEN", "LEVERAGE_DRIVEN", "MIXED"],
            default="UNCERTAIN",
        ),
        index=spot_flow_z.index,
    )

