from __future__ import annotations

import numpy as np
import pandas as pd

from .driver import classify_driver
from .positioning import classify_positioning
from .trend import classify_trend
from .volatility import classify_volatility


def classify_regimes(features: pd.DataFrame) -> pd.DataFrame:
    if features.empty:
        return features.copy()
    result = features.sort_values(["asset", "prediction_time"]).copy()
    result["trend_regime"] = result.groupby("asset", group_keys=False)["spot_price"].apply(classify_trend)
    result["volatility_regime"] = result.groupby("asset", group_keys=False)["spot_price"].apply(classify_volatility)
    index = result.index
    result["driver_regime"] = classify_driver(
        result.get("spot_flow_z", pd.Series(np.nan, index=index)),
        result.get("perp_flow_z", pd.Series(np.nan, index=index)),
    )
    result["positioning_regime"] = classify_positioning(
        result.get("funding_z", pd.Series(np.nan, index=index)),
        result.get("oi_change_z", pd.Series(np.nan, index=index)),
        result.get("skew_30d"),
    )
    result["liquidity_regime"] = result.get("liquidity_regime", "UNCERTAIN")
    result["macro_regime"] = result.get("macro_regime", "UNCERTAIN")
    return result

