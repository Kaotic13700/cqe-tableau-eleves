from __future__ import annotations

import pandas as pd

from .macro import classify_liquidity


def liquidity_regime(liquidity_impulse_z: pd.Series) -> pd.Series:
    return classify_liquidity(liquidity_impulse_z)

