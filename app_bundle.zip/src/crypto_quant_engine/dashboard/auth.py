"""Contrôle d'accès Google OIDC, fermé par défaut et réévalué à chaque exécution."""
from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Protocol, cast

import streamlit as st

LOGGER = logging.getLogger(__name__)


class UserIdentity(Protocol):
    """Interface minimale de l'identité fournie par Streamlit."""

    is_logged_in: bool

    def get(self, key: str, default: object = None) -> object: ...


def _normalized_list(value: object) -> set[str]:
    # Une chaîne ou une configuration mal formée n'accorde aucun droit.
    if not isinstance(value, (list, tuple)) or any(not isinstance(x, str) for x in value):
        return set()
    return {x.strip().lower() for x in value if x.strip()}


def _access_policy() -> Mapping[str, object]:
    try:
        access = st.secrets.get("access", {})
    except (FileNotFoundError, KeyError):
        access = {}
    if not isinstance(access, Mapping):
        access = {}
    if not any(key in access for key in ("allowed_emails", "allowed_domains")):
        LOGGER.warning("Liste blanche absente : accès refusé à tous les utilisateurs.")
    return access


def require_auth(*, show_identity: bool = True) -> UserIdentity:
    """Arrête la page sans autorisation ; retourne sinon l'identité OIDC.

    Le lanceur masque uniquement l'identité latérale, affichée par la page finale.
    Aucun résultat d'autorisation n'est mis en cache.
    """
    access = _access_policy()
    # En 1.42, l'identité native portait encore le nom experimental_user.
    user = cast(UserIdentity, st.user if hasattr(st, "user") else st.experimental_user)
    if not getattr(user, "is_logged_in", False):
        st.title("Boussole Crypto")
        st.write("Connectez-vous avec votre compte Google autorisé pour accéder au tableau.")
        if st.button("Se connecter avec Google", key="google_login"):
            st.login()
        st.stop()

    raw_email = user.get("email")
    email = raw_email.strip().lower() if isinstance(raw_email, str) else ""
    parts = email.split("@")
    valid_email = len(parts) == 2 and all(parts) and not any(c.isspace() for c in email)
    allowed = valid_email and (
        email in _normalized_list(access.get("allowed_emails"))
        or parts[1] in _normalized_list(access.get("allowed_domains"))
    )
    # Google doit avoir vérifié l'adresse : ne pas autoriser une simple déclaration.
    if not allowed or user.get("email_verified") is not True:
        st.error("Accès refusé : ce compte Google n'est pas autorisé ou son adresse n'est pas vérifiée.")
        if st.button("Se déconnecter", key="denied_logout"):
            st.logout()
        st.stop()

    if show_identity:
        name = user.get("name")
        st.sidebar.text(f"Connecté : {name}" if isinstance(name, str) and name else "Connecté")
        st.sidebar.text(email)
        if st.sidebar.button("Se déconnecter", key="authorized_logout"):
            st.logout()
            st.stop()
    return user
