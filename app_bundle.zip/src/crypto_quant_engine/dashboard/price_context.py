"""Repères descriptifs du prix, sans probabilité ni pondération prédictive."""
from __future__ import annotations

import numpy as np
import pandas as pd


def describe_price_window(frame: pd.DataFrame, complete: bool) -> str | None:
    """Décrit uniquement une fenêtre causale déjà filtrée par l'appelant.

    Les extrema portent sur les relevés, pas sur les mèches OHLC ni sur
    des ordres observés : ils ne prouvent pas la présence de liquidité.
    """
    if not complete or "spot_price" not in frame or len(frame) < 3:
        return None
    prices = pd.to_numeric(frame["spot_price"], errors="coerce").to_numpy(dtype=float)
    if not np.isfinite(prices).all() or (prices <= 0).any():
        return None
    low, high, last = float(prices.min()), float(prices.max()), float(prices[-1])
    change = 100 * (last / prices[0] - 1)
    # L'efficacité compare le déplacement net au chemin effectivement observé.
    path = float(np.abs(np.diff(np.log(prices))).sum())
    efficiency = abs(float(np.log(last / prices[0]))) / path if path > 0 else 0.0
    position = f"{100 * (last-low)/(high-low):.0f} %" if high > low else "indéfinie (prix constant)"
    return (
        f"Lecture du prix sur la fenêtre : variation {change:+.2f} % ; "
        f"plage des relevés {low:,.2f}–{high:,.2f} ; position dans cette plage {position} "
        f"(0 % = bas, 100 % = haut). Efficacité du déplacement {efficiency:.0%} "
        "(proche de 0 : allers-retours ; proche de 100 % : parcours unidirectionnel). "
        "Repères historiques observés, ni objectifs futurs, ni niveaux de liquidation ; "
        "l’efficacité n’est pas une probabilité de réussite."
    )
