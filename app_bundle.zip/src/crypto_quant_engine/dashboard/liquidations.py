"""Public-facing liquidation coverage; missing is never displayed as zero."""
import json
import pandas as pd

SOURCES = {
    "binance_liquidation_stream": ("Binance", "Prix d’exécution ; échantillon limité"),
    "bybit_liquidation_stream": ("Bybit", "Prix de faillite × quantité ; non égal au prix d’exécution"),
    "okx_liquidation_stream": ("OKX", "Prix de liquidation × quantité convertie ; flux partiel"),
    "bitget_liquidation_stream": ("Bitget", "Montant USDT diffusé ; plus gros événement par sens et seconde"),
    "gate_liquidation_stream": ("Gate", "Prix de l’ordre × multiplicateur ; non égal à une exécution finale"),
}


def liquidation_source_table(features):
    try:
        states = json.loads(features.get("liquidation_sources_json", "{}"))
    except (TypeError, ValueError):
        states = {}
    rows = []
    reference = pd.to_datetime(features.get("prediction_time"), utc=True, errors="coerce")
    for key, (name, basis) in SOURCES.items():
        state = states.get(key, {})
        received = pd.to_datetime(state.get("received_at"), utc=True, errors="coerce")
        fresh = pd.notna(received) and pd.notna(reference) and 0 <= (reference-received).total_seconds() <= 120
        active = bool(state.get("connected")) and fresh
        observed = bool(state.get("observed"))
        event = pd.to_datetime(state.get("last_event_time"), utc=True, errors="coerce")
        rows.append({"Plateforme": name,
                     "État": "Écoute confirmée au relevé" if active else "Événements reçus / écoute à vérifier" if observed else "Non disponible",
                     "Longs · USDT indicatifs": state.get("long") if active or observed else None,
                     "Shorts · USDT indicatifs": state.get("short") if active or observed else None,
                     "Événements capturés": state.get("events") if active or observed else None,
                     "Dernier prix diffusé · USDT": state.get("last_price"),
                     "Heure du prix UTC": event.strftime("%d/%m %H:%M:%S") if pd.notna(event) else "Aucun prix capturé",
                     "Dernier message UTC": received.strftime("%d/%m %H:%M:%S") if pd.notna(received) else "—",
                     "Valorisation / limite": basis})
    return pd.DataFrame(rows)


def show_liquidations(features):
    import streamlit as st
    st.subheader("Liquidations observées · par plateforme")
    st.caption("Messages reçus dans l’intervalle de 15 minutes du relevé, observation partielle depuis le démarrage de l’écoute. "
               "Long = position acheteuse liquidée ; short = position vendeuse liquidée.")
    table = liquidation_source_table(features)
    totals = liquidation_totals(table)
    long_box, short_box, total_box = st.columns(3)
    def amount(value):
        return f"{value:,.2f} USDT" if pd.notna(value) else "Aucun montant reçu"
    long_box.metric("Longs liquidés · total observé", amount(totals["long"]))
    short_box.metric("Shorts liquidés · total observé", amount(totals["short"]))
    total_box.metric("Total longs + shorts", amount(totals["total"]))
    st.caption(f"Agrégat sur {totals['sources']}/{len(SOURCES)} plateformes renseignées dans cet intervalle ; "
               "Binance, Bybit, OKX, Bitget et Gate sont interrogées en parallèle. "
               "Total des événements capturés, pas estimation du total mondial. Les valorisations publiées diffèrent selon les sources.")
    display = table.drop(columns=["Valorisation / limite"]).copy()
    display["Dernier prix diffusé · USDT"] = display["Dernier prix diffusé · USDT"].map(
        lambda value: f"{value:,.2f}" if pd.notna(value) else "Aucun prix reçu")
    st.dataframe(display, hide_index=True, width="stretch")
    with st.expander("Comprendre les prix et la couverture des plateformes"):
        for name, basis in SOURCES.values():
            st.write(f"{name} : {basis}.")
    st.caption("Zéro signifie aucun événement capturé pendant l’écoute, pas absence de liquidations sur le marché. "
               "Le dernier prix peut provenir d’un intervalle antérieur : son heure est indiquée séparément. "
               "Les montants sont en USDT et valorisés aux prix diffusés, qui diffèrent selon la plateforme. "
               "Les interruptions et les flux filtrés empêchent de garantir un total exhaustif ; aucun historique manquant n’est inventé.")


def liquidation_totals(table):
    longs = pd.to_numeric(table["Longs · USDT indicatifs"], errors="coerce")
    shorts = pd.to_numeric(table["Shorts · USDT indicatifs"], errors="coerce")
    valid = longs.notna() & shorts.notna() & (longs >= 0) & (shorts >= 0)
    long_total, short_total = longs[valid].sum(min_count=1), shorts[valid].sum(min_count=1)
    return {"long":long_total, "short":short_total, "total":long_total+short_total,"sources":int(valid.sum())}
