"""Causal price levels and a readable, descriptive market playbook."""
from __future__ import annotations

from html import escape
import math
import numpy as np
import pandas as pd

VERSION = "scenario-plan-v1-observed-levels"


def causal_prices(features, history, days):
    frame = pd.DataFrame() if history is None else history.copy()
    now = pd.to_datetime(features.get("prediction_time"), utc=True, errors="coerce")
    if frame.empty or pd.isna(now) or not {"prediction_time", "spot_price"}.issubset(frame):
        return pd.DataFrame(columns=["prediction_time", "spot_price"])
    frame["prediction_time"] = pd.to_datetime(frame["prediction_time"], utc=True, errors="coerce", format="mixed")
    if "asset" in frame:
        frame = frame[frame["asset"].eq(features.get("asset"))]
    for name in ("available_time", "feature_available_time"):
        if name in frame:
            known = pd.to_datetime(frame[name], utc=True, errors="coerce", format="mixed")
            frame = frame[known.notna() & (known <= frame["prediction_time"])]
    frame = frame[frame["prediction_time"].between(now - pd.Timedelta(days=days), now)]
    frame["spot_price"] = pd.to_numeric(frame["spot_price"], errors="coerce")
    frame = frame[np.isfinite(frame["spot_price"]) & frame["spot_price"].gt(0)]
    return frame.sort_values("prediction_time").drop_duplicates("prediction_time", keep="last")


def price_plan(features, history, days, sigma, bias, confirmation):
    price = float(features["spot_price"])
    frame = causal_prices(features, history, days)
    prices = frame["spot_price"]
    # Quantiles of actually observed prices, never fictitious exchange candles.
    buffer = max(price * .0005, price * sigma * .05)
    below = prices[prices < price - buffer]
    above = prices[prices > price + buffer]
    support_observed = len(below) >= 3
    resistance_observed = len(above) >= 3
    support = float(below.quantile(.25)) if support_observed else price * math.exp(-.5 * sigma)
    resistance = float(above.quantile(.75)) if resistance_observed else price * math.exp(.5 * sigma)
    spread = max(resistance - support, price * sigma * .5)
    if bias == "HAUSSIER":
        activation = min(resistance, price + max(buffer, (resistance - price) * .4))
        target_1 = resistance
        target_2 = resistance + spread * .5
        invalidation = support
        trigger = f"clôture {confirmation} au-dessus de ${activation:,.0f}, puis maintien de ce niveau au retest"
        invalidation_text = f"clôture {confirmation} sous ${support:,.0f} : abandon de la thèse haussière"
        summary = f"{features.get('asset', '')} · acheteurs favorisés. Reprise de ${activation:,.0f} pour viser ${target_1:,.0f}, puis ${target_2:,.0f} si la demande persiste. Le support ${support:,.0f} doit tenir."
    elif bias == "BAISSIER":
        activation = max(support, price - max(buffer, (price - support) * .4))
        target_1 = support
        target_2 = max(support - spread * .5, support * .5)
        invalidation = resistance
        trigger = f"clôture {confirmation} sous ${activation:,.0f}, puis échec du retour au-dessus"
        invalidation_text = f"clôture {confirmation} au-dessus de ${resistance:,.0f} : abandon de la thèse baissière"
        summary = f"{features.get('asset', '')} · vendeurs favorisés. Perte de ${activation:,.0f} pour viser ${target_1:,.0f}, puis ${target_2:,.0f} si l’offre domine encore. Une reprise de ${resistance:,.0f} invalide cette lecture."
    else:
        activation = (support + resistance) / 2
        target_1, target_2 = support, resistance
        invalidation = support
        trigger = f"rejet de ${resistance:,.0f} et défense de ${support:,.0f} ; retour vers l’équilibre ${activation:,.0f}"
        invalidation_text = f"clôture {confirmation} hors de ${support:,.0f}–${resistance:,.0f}, suivie d’un maintien hors du couloir"
        summary = f"{features.get('asset', '')} · équilibre entre acheteurs et vendeurs. Rotation privilégiée entre ${support:,.0f} et ${resistance:,.0f}, autour de ${activation:,.0f}. Une sortie confirmée ouvre un nouveau scénario directionnel."
    return dict(support=support, resistance=resistance, activation=activation, target_1=target_1,
                target_2=target_2, invalidation=invalidation, trigger_text=trigger,
                invalidation_text=invalidation_text, summary=summary, version=VERSION,
                support_origin="zone observée" if support_observed else "repère estimé par volatilité",
                resistance_origin="zone observée" if resistance_observed else "repère estimé par volatilité",
                observation_count=len(frame), extension_method="demi-largeur du couloir ajoutée au premier objectif")


def evidence_rows(features, thesis):
    """Each argument states its own observed inputs; OI level alone has no sign."""
    def number(key, scale=1, suffix="", decimals=2):
        try:
            value = float(features.get(key))
        except (ValueError, TypeError):
            return "non reçu"
        return f"{value * scale:+,.{decimals}f}{suffix}" if math.isfinite(value) else "non reçu"
    details = {
        "Analyse technique": f"Prix : 1 h {number('return_1h',100,'%')} · 4 h {number('return_4h',100,'%')} · 24 h {number('return_24h',100,'%')}. Structure calculée sur la fenêtre de cet horizon.",
        "Spot": f"Flux acheteurs/vendeurs {number('spot_buy_sell_imbalance')} ; carnet {number('spot_order_book_imbalance')}. Positif : pression acheteuse observée.",
        "Perpétuels": f"Funding courant {number('cex_oi_weighted_funding',100,'%',4)} ; prime {number('cex_oi_weighted_basis',100,'%')}. OI notionnel {number('cex_open_interest_notional_usd',1e-9,' Md$',2)} : taille des positions, sans direction à lui seul.",
        "Options": f"Put/call OI {number('pcr_oi_global')} ; skew 30 j {number('skew_30d',1,' pts')}. Mesures de demande de protection et d’asymétrie.",
        "ETF / liquidité": f"ETF spot {features.get('asset','')} : dernière séance {number('etf_daily_net_flow_usd',1e-6,' M$',1)}, cinq séances {number('etf_flow_5d_usd',1e-6,' M$',1)}. Offre stablecoins 7 j {number('stablecoin_supply_change_7d_usd',1e-6,' M$',1)}.",
        "Macro / taux": f"Croissance {number('macro_growth_signal')} ; inflation {number('macro_inflation_signal')} ; liquidité {number('macro_liquidity_signal')} ; politique monétaire {number('macro_policy_signal')}. Indices signés de contexte.",
        "Liquidations": f"Déséquilibre observé {number('observed_liquidation_imbalance')} : liquidations courtes moins longues ; couverture limitée aux sources reçues.",
        "Force relative": f"ETH/BTC sur 24 h {number('eth_btc_return_24h',100,'%')}. Le signe est inversé pour la lecture BTC.",
        "Dérivés DEX": f"Prime {number('dex_oi_weighted_basis',100,'%')} ; funding {number('dex_oi_weighted_funding',100,'%',4)} sur les contrats décentralisés.",
    }
    return [{"Famille": family, "Lecture": "Haussière" if value >= .2 else "Baissière" if value <= -.2 else "Équilibrée",
             "Argument": details.get(family,""), "score": value}
            for family, value in sorted(thesis["family_evidence"].items(), key=lambda item: abs(item[1]) * thesis.get("family_weights",{}).get(item[0],1.), reverse=True)]


def plan_figure(features, history, thesis):
    import plotly.graph_objects as go
    plan = thesis["price_plan"]
    days = thesis["horizon_days"]
    frame = causal_prices(features, history, days)
    now = pd.to_datetime(features.get("prediction_time"), utc=True)
    price = float(features["spot_price"])
    end = now + pd.Timedelta(days=days)
    figure = go.Figure()
    if not frame.empty:
        # Break the historical line across gaps rather than visually repairing them.
        xs, ys = [], []
        previous = None
        for row in frame.iloc[::max(1,len(frame)//500)].itertuples():
            if previous is not None and row.prediction_time - previous > pd.Timedelta(minutes=30) * max(1,len(frame)//500):
                xs.append(row.prediction_time.isoformat()); ys.append(None)
            xs.append(row.prediction_time.isoformat()); ys.append(row.spot_price)
            previous = row.prediction_time
        figure.add_trace(go.Scatter(x=xs,y=ys,name="Prix observé",line=dict(color="#f4efe3",width=2),connectgaps=False,
                                    hovertemplate="%{x}<br>Prix observé $%{y:,.2f}<extra></extra>"))
    bullish = thesis["bias"] == "HAUSSIER"
    ranging = thesis["bias"] == "CONSOLIDATION"
    color = "#d8a63a" if ranging else "#2dcc75" if bullish else "#ef5964"
    levels = [("Borne basse" if ranging else "Objectif 1",plan["target_1"],color),
              ("Borne haute" if ranging else "Objectif 2 · extension",plan["target_2"],color),
              ("Équilibre" if ranging else "Déclencheur",plan["activation"],"#d8a63a")]
    if not ranging:
        levels.append(("Invalidation",plan["invalidation"],"#ef5964" if bullish else "#2dcc75"))
    for label, value, line_color in levels:
        figure.add_shape(type="line",x0=now.isoformat(),x1=end.isoformat(),y0=value,y1=value,
                         line=dict(color=line_color,width=1.2,dash="dot"))
        figure.add_annotation(x=1.01,xref="paper",y=value,text=f"{label}<br><b>${value:,.0f}</b>",
                              showarrow=False,xanchor="left",font=dict(color=line_color,size=11))
    if not ranging:
        # Milestones of a conditional plan, deliberately no artificial future price series.
        figure.add_trace(go.Scatter(x=[end.isoformat(),end.isoformat()],y=[plan['target_1'],plan['target_2']],
                                   mode="markers",marker=dict(color=color,size=10,symbol="diamond"),name="Objectifs conditionnels",
                                   hovertemplate="Objectif $%{y:,.2f}<extra></extra>"))
    figure.add_trace(go.Scatter(x=[now.isoformat()],y=[price],name="Dernier relevé",mode="markers",
                               marker=dict(color="#d8a63a",size=10),hovertemplate="Dernier relevé $%{y:,.2f}<extra></extra>"))
    figure.add_shape(type="line",x0=now.isoformat(),x1=now.isoformat(),y0=0,y1=1,yref="paper",line=dict(color="#d8a63a",width=1,dash="dash"))
    figure.add_annotation(x=now.isoformat(),y=1.03,yref="paper",text="DERNIER RELEVÉ",showarrow=False,font=dict(color="#d8a63a",size=10))
    figure.add_annotation(x=(now+pd.Timedelta(days=days*.5)).isoformat(),y=1.12,yref="paper",text="PLAN CONDITIONNEL",showarrow=False,font=dict(color=color,size=11))
    figure.update_layout(height=510,margin=dict(l=10,r=170,t=65,b=25),paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="#101216",
                         font=dict(color="#f4efe3"),hovermode="x unified",legend=dict(orientation="h",y=-.18),
                         xaxis=dict(title="Heure UTC · historique à gauche, niveaux à surveiller à droite",range=[(now-pd.Timedelta(days=days)).isoformat(),end.isoformat()],gridcolor="rgba(216,166,58,.07)"),
                         yaxis=dict(tickprefix="$",separatethousands=True,gridcolor="rgba(216,166,58,.08)",fixedrange=False))
    return figure


def render_scenario_plan(rows, current_features, key_suffix, default):
    import streamlit as st
    from .decision import DECISION_HORIZONS
    from .scenarios import directional_thesis
    st.subheader("Scénario de marché · niveaux et conditions")
    label = st.segmented_control("Horizon de la fourchette",list(DECISION_HORIZONS),default=default,key=f"scenario_trajectory_horizon_{key_suffix}")
    ordered = rows.copy()
    ordered["prediction_time"] = pd.to_datetime(ordered["prediction_time"],utc=True,errors="coerce")
    ordered = ordered.dropna(subset=["prediction_time"]).sort_values("prediction_time")
    if current_features.get("asset") and "asset" in ordered:
        ordered = ordered[ordered["asset"].eq(current_features["asset"])]
    if ordered.empty:
        st.info("Premier relevé de prix attendu."); return
    features = {**ordered.iloc[-1].to_dict(), **current_features}
    horizon = DECISION_HORIZONS.get(label,DECISION_HORIZONS[default])
    thesis = directional_thesis(features,ordered,horizon=horizon)
    if not thesis.get("available"):
        st.info("Prix ou amplitude de marché indisponible pour construire les niveaux."); return
    plan = thesis["price_plan"]
    bias = thesis["bias"]
    color = "#2dcc75" if bias == "HAUSSIER" else "#ef5964" if bias == "BAISSIER" else "#d8a63a"
    st.markdown(f"<div class='bc-scenario-card'><div><span class='bc-scenario-label'>{escape(str(features.get('asset','')))} · {escape(str(label))}</span><span class='bc-scenario-value' style='color:{color}'>{bias}</span></div><div><span class='bc-scenario-label'>PRIX OBSERVÉ</span><span class='bc-scenario-value'>${float(features['spot_price']):,.2f}</span></div><div><span class='bc-scenario-label'>CONFLUENCE</span><span class='bc-scenario-value'>{thesis['conviction_label']}</span></div></div>",unsafe_allow_html=True)
    st.write(thesis["summary"].replace("$",r"\$"))
    st.plotly_chart(plan_figure(features,ordered,thesis),width="stretch",key=f"scenario_trajectory_chart_{key_suffix}")
    st.caption("La courbe blanche représente les prix observés. À droite : niveaux du plan, à activer par les conditions ci-dessous. Aucune trajectoire future n’est présentée comme acquise.")
    cols = st.columns(3)
    cols[0].markdown("**01 · Activation**"); cols[0].write(plan["trigger_text"].replace("$",r"\$"))
    cols[1].markdown("**02 · Développement**")
    cols[1].write((f"Rotation entre ${plan['support']:,.0f} et ${plan['resistance']:,.0f}." if bias == "CONSOLIDATION" else f"Premier objectif ${plan['target_1']:,.0f}. Extension vers ${plan['target_2']:,.0f} seulement après franchissement et maintien du premier objectif.").replace("$",r"\$"))
    cols[2].markdown("**03 · Changement de scénario**"); cols[2].write(plan["invalidation_text"].replace("$",r"\$"))
    arguments = evidence_rows(features,thesis)
    st.markdown("**Pourquoi ce biais sur cet actif et cet horizon**")
    positive = [row['Famille'] for row in arguments if row['score'] >= .2]
    negative = [row['Famille'] for row in arguments if row['score'] <= -.2]
    st.write("**Soutiens à la hausse :** " + (", ".join(positive) or "signaux équilibrés") +
             ". **Pressions à la baisse :** " + (", ".join(negative) or "aucune famille nettement baissière") + ".")
    for row in arguments:
        st.markdown(f"<div class='bc-evidence-row'><strong>{escape(row['Famille'])} · {row['Lecture']}</strong><span>{escape(row['Argument'])}</span></div>",unsafe_allow_html=True)
    sign = 1 if bias == "HAUSSIER" else -1 if bias == "BAISSIER" else 0
    opposing = [row['Famille'] for row in arguments if row['score'] * sign < -.2]
    if opposing:
        st.write("**Ce qui peut contrarier ce plan :** " + ", ".join(opposing) + ". Surveiller leur évolution avant de considérer le déclencheur comme confirmé.")
    from .scenarios import directional_family_scores
    background = {name:value for name,value in directional_family_scores(features).items()
                  if name not in thesis['family_evidence'] and name in ('Macro / taux','ETF / liquidité','Force relative','Perpétuels','Options')}
    if background:
        with st.expander("Contexte complémentaire de cet actif"):
            st.caption("Ces facteurs décrivent le contexte courant ; leur temporalité ne leur donne pas de vote direct sur cet horizon.")
            for row in evidence_rows(features,{"family_evidence":background}):
                st.write(f"**{row['Famille']} · {row['Lecture']}** — {row['Argument']}")
    with st.expander("Origine des niveaux et qualité de la lecture"):
        st.write(f"Support : {plan['support_origin']}. Résistance : {plan['resistance_origin']}. {plan['observation_count']} relevés de prix retenus, connus à la date du scénario.")
        st.write("Déclencheur : 40 % du chemin entre le prix et le premier objectif, à confirmer par clôture et retest. Extension : demi-largeur du couloir au-delà du premier objectif. Ces règles descriptives sont explicites et non ajustées pour optimiser les résultats passés.")
        st.write("Confluence : accord et intensité des familles disponibles. Elle ne représente pas un taux de réussite.")
        for reason in thesis.get("blocking_reasons",[]):
            st.write("Qualité à surveiller : " + reason)
        for note in thesis.get("horizon_notes",[]):
            st.write(note)
