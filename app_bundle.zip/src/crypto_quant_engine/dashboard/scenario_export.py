"""Export JSON de la page « Scénario » (BTC / ETH) et envoi vers un dépôt GitHub.

Ce module reconstruit, SANS interface Streamlit, exactement ce que la page affiche aujourd'hui :
mêmes fonctions de calcul (decision.py, scenarios.py, scenario_plan.py), mêmes textes, mêmes chiffres.
Il produit un fichier ``scenario.json`` (voir ``build_payload``) puis, si les variables d'environnement
SCENARIO_GH_TOKEN et SCENARIO_GH_REPO sont définies, le dépose dans le dépôt GitHub indiqué.

Branchement (appli hébergée) : appeler ``export_after_refresh(runtime_dir)`` à la fin de chaque
rafraîchissement (voir LISEZ-MOI-DEV.txt). Aucune exception ne remonte : un échec d'export ne doit
jamais casser l'appli ; le détail est écrit dans ``<runtime>/scenario_export_status.json``.

Remarque : les fonctions ``_read_feature_file``, ``_fill_causal_relative_return``, ``read_latest_features``,
``read_macro_observations``, ``_utc_label`` et ``_decision_change_display`` sont des copies de celles de
``dashboard/app.py`` (qu'on ne peut pas importer : c'est un script Streamlit). Si elles changent dans
app.py, il faut les répercuter ici (ou, mieux, les déplacer dans un module partagé).
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from crypto_quant_engine.collectors.historical.funding_context import read_context
from crypto_quant_engine.dashboard.decision import DECISION_HORIZONS, build_decision_snapshot
from crypto_quant_engine.dashboard.macro import build_macro_context, macro_feature_overlay
from crypto_quant_engine.dashboard.pedagogy import attach_current_relative_context
from crypto_quant_engine.dashboard.scenario_plan import evidence_rows, plan_figure
from crypto_quant_engine.dashboard.scenarios import directional_family_scores, directional_scenario_table, directional_thesis
from crypto_quant_engine.storage import NormalizedStore

SCHEMA = 1
SOURCE_NAME = "Market Compass · BTC / ETH"
ASSETS = ("BTC", "ETH")
HORIZONS = ("7 jours", "30 jours")  # horizons repris par le tableau de bord (les horizons courts sont ignorés)
FRAMES_NOTE = (
    "Les pourcentages des objectifs sont mesurés depuis le prix observé. Un obstacle technique peut rester proche sur plusieurs horizons : "
    "il ne représente pas le potentiel total de la période. L’extension n’est envisagée qu’après franchissement du premier objectif. "
    "L’enveloppe utilise le prix × exp(± amplitude) ; elle peut être dépassée et n’est pas un intervalle de confiance calibré."
)
CHANGES_NOTE = "Comparaison du prix et de la volatilité effectivement archivés ; aucune macro actuelle n’est réinjectée dans le passé."
CONTEXT_NOTE = "Ces facteurs décrivent le contexte courant ; leur temporalité ne leur donne pas de vote direct sur cet horizon."
STALE_WARNING = "Le dernier relevé dépasse 30 minutes : le biais reste visible, mais sa fraîcheur est explicitement dégradée."


# ----------------------------------------------------------------------------- copies de dashboard/app.py
def _read_feature_file(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    for column in ("prediction_time", "feature_available_time"):
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], utc=True, format="mixed", errors="coerce")
    return frame.dropna(subset=["prediction_time"]) if "prediction_time" in frame else frame


def _fill_causal_relative_return(frame: pd.DataFrame, *, tolerance_minutes: int = 30) -> pd.DataFrame:
    if frame.empty or not {"asset", "prediction_time", "eth_btc"}.issubset(frame.columns):
        return frame
    result = frame.sort_values(["asset", "prediction_time"]).copy()
    if "eth_btc_return_24h" not in result:
        result["eth_btc_return_24h"] = float("nan")
    tolerance = pd.Timedelta(minutes=int(tolerance_minutes))
    for asset, indexes in result.groupby("asset", sort=False).groups.items():
        group = result.loc[indexes, ["prediction_time", "eth_btc", "eth_btc_return_24h"]].sort_values("prediction_time")
        known = group.dropna(subset=["eth_btc"])
        if known.empty:
            continue
        for index, row in group[group["eth_btc_return_24h"].isna() & group["eth_btc"].notna()].iterrows():
            target = pd.Timestamp(row["prediction_time"]) - pd.Timedelta(hours=24)
            candidates = known[(known["prediction_time"] <= target) & (known["prediction_time"] >= target - tolerance)]
            if candidates.empty:
                continue
            previous = float(candidates.iloc[-1]["eth_btc"])
            if previous > 0:
                result.at[index, "eth_btc_return_24h"] = float(row["eth_btc"]) / previous - 1.0
    return result.sort_values(["asset", "prediction_time"]).reset_index(drop=True)


def read_latest_features(root: Path) -> tuple[pd.DataFrame, str | None]:
    stable_candidates = list(root.glob("*/features.csv.gz"))
    live_candidates = list((root.parent / "live").glob("*/features.csv.gz"))
    if not stable_candidates and not live_candidates:
        return pd.DataFrame(), None
    selected: list[Path] = []
    if stable_candidates:
        selected.append(max(stable_candidates, key=lambda path: path.stat().st_mtime))
    if live_candidates:
        selected.append(max(live_candidates, key=lambda path: path.stat().st_mtime))
    blocks = [_read_feature_file(path) for path in selected]
    frame = pd.concat(blocks, ignore_index=True, sort=False)
    if {"asset", "prediction_time"}.issubset(frame.columns):
        frame = frame.sort_values("prediction_time").drop_duplicates(["asset", "prediction_time"], keep="last")
    frame = _fill_causal_relative_return(frame)
    return frame.reset_index(drop=True), " + ".join(path.parent.name for path in selected)


def read_macro_observations(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    store = NormalizedStore(path)
    blocks = [store.query(data_family=family) for family in ("MACRO", "FED", "RATES")]
    blocks = [block for block in blocks if not block.empty]
    return pd.concat(blocks, ignore_index=True) if blocks else pd.DataFrame()


def _utc_label(value: object) -> str:
    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        return timestamp.tz_convert("UTC").strftime("%d/%m/%Y %H:%M UTC")
    except (TypeError, ValueError):
        return "—"


def _decision_change_display(snapshot: dict) -> pd.DataFrame:
    changes = snapshot.get("changes") or {}
    rows = changes.get("rows")
    if not isinstance(rows, pd.DataFrame) or rows.empty:
        return pd.DataFrame()
    display = rows.copy()

    def format_current(row: pd.Series) -> str:
        value, unit = row["Maintenant"], row["Unité"]
        if value is None or (not isinstance(value, str) and pd.isna(value)):
            return "—"
        if unit == "price_pct":
            return f"${float(value):,.2f}"
        if unit == "points":
            return f"{float(value):.1f} / 100"
        if unit == "percentage_points":
            return f"{float(value):.2f} %"
        return str(value)

    def format_delta(row: pd.Series) -> str:
        value, unit = row["Évolution"], row["Unité"]
        if value is None or (not isinstance(value, str) and pd.isna(value)):
            return "—"
        if unit == "price_pct":
            return f"{float(value):+.2f} %"
        if unit == "points":
            return f"{float(value):+.1f} point(s)"
        if unit == "percentage_points":
            return f"{float(value):+.2f} pt(s)"
        return str(value)

    display["Maintenant"] = display.apply(format_current, axis=1)
    display["Depuis le relevé précédent"] = display.apply(format_delta, axis=1)
    return display[["Mesure", "Maintenant", "Depuis le relevé précédent"]]


# ----------------------------------------------------------------------------- construction du JSON
def _int0(value: float) -> int:
    """Arrondi à l'entier comme l'affichage (« {:,.0f} »)."""
    return int(float(f"{float(value):.0f}"))


def _epoch(value: object) -> int:
    return int(round(pd.Timestamp(value).timestamp()))


def _frame(row: pd.Series) -> dict:
    out: dict = {"h": str(row["Horizon"]), "bias": str(row["Biais"])}
    if row["Biais"] == "INDISPONIBLE":
        out["note"] = ["Niveaux indisponibles pour cet horizon."]
        return out
    price = float(row["Prix"])

    def level(value: float) -> dict:
        return {"v": _int0(value), "pct": float(f"{100 * (float(value) / price - 1):+.2f}")}

    if row["Biais"] == "CONSOLIDATION":
        out["note"] = ["Rotation dans le couloir"]
        out["lo"] = level(row["Objectif 1"])
        out["hi"] = level(row["Objectif 2"])
    else:
        out["note"] = ["Parcours conditionnel · mêmes niveaux que le graphique"]
        out["t1"] = {"kind": "obstacle technique", **level(row["Objectif 1"])}
        out["t2"] = {"kind": "extension", **level(row["Objectif 2"])}
    out["act"] = str(row["Condition"])
    out["inv"] = str(row["Invalidation détaillée"])
    out["env"] = [_int0(row["Enveloppe basse"]), _int0(row["Enveloppe haute"])]
    out["scale"] = float(f"{float(row['Amplitude implicite']):.2f}")
    return out


def _chart(features: dict, ordered: pd.DataFrame, thesis: dict) -> dict:
    """Mêmes données que le graphique du plan (plan_figure) : prix observés + niveaux."""
    fig = plan_figure(features, ordered, thesis)
    trace = next((t for t in fig.data if t.name == "Prix observé"), None)
    xs, ys = [], []
    if trace is not None:
        for x, y in zip(trace.x, trace.y):
            if y is None or (isinstance(y, float) and math.isnan(y)):
                continue  # trou dans les données : on n'invente rien
            xs.append(_epoch(x))
            ys.append(round(float(y), 2))
    n = len(xs)
    step = max(1, math.ceil(n / 220))
    tt, yy = xs[::step], ys[::step]
    if xs and tt[-1] != xs[-1]:
        tt.append(xs[-1])
        yy.append(ys[-1])
    levels = []
    for ann in fig.layout.annotations or []:
        text = str(ann.text or "")
        if "$" in text and isinstance(ann.y, (int, float)) and ann.y > 100:
            label = text.replace("<br>", " ").replace("<b>", "").replace("</b>", "")
            label = label.split("$")[0].strip()
            levels.append({"k": " ".join(label.split()), "v": round(float(ann.y), 2)})
    shape = fig.layout.shapes[0] if fig.layout.shapes else None
    return {"t": tt, "y": yy, "levels": levels, "end": _epoch(shape.x1) if shape is not None else None, "n": n}


def _horizon_block(asset: str, label: str, features: dict, ordered: pd.DataFrame) -> dict | None:
    thesis = directional_thesis(features, ordered, horizon=DECISION_HORIZONS[label])
    if not thesis.get("available"):
        return None
    plan, bias = thesis["price_plan"], thesis["bias"]
    arguments = evidence_rows(features, thesis)
    positive = [row["Famille"] for row in arguments if row["score"] >= 0.2]
    negative = [row["Famille"] for row in arguments if row["score"] <= -0.2]
    why = ("Soutiens à la hausse : " + (", ".join(positive) or "signaux équilibrés")
           + ". Pressions à la baisse : " + (", ".join(negative) or "aucune famille nettement baissière") + ".")
    dev = (f"Rotation entre ${plan['support']:,.0f} et ${plan['resistance']:,.0f}." if bias == "CONSOLIDATION"
           else f"Premier objectif ${plan['target_1']:,.0f}. Extension vers ${plan['target_2']:,.0f} seulement après franchissement et maintien du premier objectif.")
    return {
        "asset": asset, "hz": label, "bias": bias, "confl": thesis["conviction_label"],
        "plan": thesis["summary"],
        "chart": _chart(features, ordered, thesis),
        "steps": {"act": plan["trigger_text"], "dev": dev, "chg": plan["invalidation_text"]},
        "why": why,
        "fams": [{"f": row["Famille"], "v": row["Lecture"], "t": row["Argument"]} for row in arguments],
    }


def _asset_block(asset: str, all_rows: pd.DataFrame, macro_context: dict, db_path: Path, now: pd.Timestamp) -> dict | None:
    rows = all_rows[all_rows["asset"] == asset].copy() if not all_rows.empty else pd.DataFrame()
    if rows.empty:
        return None
    rows = attach_current_relative_context(rows, all_rows)
    cutoff = rows["prediction_time"].max()
    snapshot = build_decision_snapshot(
        rows,
        {**macro_feature_overlay(macro_context), "settled_funding_context": read_context(db_path, asset, cutoff)},
        now=now,
    )
    if not snapshot.get("available"):
        return None
    latest, thesis, votes, quality = snapshot["latest"], snapshot["thesis_7d"], snapshot["votes"], snapshot["quality"]
    bias = str(thesis.get("bias", "INDISPONIBLE"))
    target = f"${float(thesis['dominant_target']):,.0f}" if thesis.get("available") else "—"
    invalidation = f"${float(thesis['invalidation_level']):,.0f}" if thesis.get("available") else "—"
    if thesis.get("available") and bias == "CONSOLIDATION":
        invalidation = f"hors ${float(thesis['support']):,.0f}–${float(thesis['resistance']):,.0f}"

    g: dict = {
        "asset": asset,
        "asof": pd.Timestamp(cutoff).tz_convert("UTC").strftime("%Y-%m-%dT%H:%M:00Z"),
        "price": round(float(latest["spot_price"]), 2),
        "read": "7 JOURS",
        "bias": bias,
        "votes": f"{votes['bullish']} H · {votes['neutral']} N · {votes['bearish']} B",
        "fam": f"{votes['available']}/{votes['total']} familles",
        "quality": f"{float(quality['score']):.0f}/100 · {quality['label']}",
        "meas": f"{quality['present_measures']}/{quality['expected_measures']} mesures",
        "target": f"{target} / {invalidation}",
    }
    if thesis.get("available"):
        g["plan"] = "Plan de marché à 7 jours · à confirmer par les niveaux : " + str(thesis["summary"])
        if thesis.get("drivers"):
            g["drivers"] = "Moteurs dominants : " + " · ".join(str(item) for item in thesis["drivers"])

    matrix = snapshot.get("multi_horizon")
    g["frames"] = [_frame(r) for _, r in matrix.iterrows() if r["Horizon"] in HORIZONS] if isinstance(matrix, pd.DataFrame) else []
    g["framesNote"] = FRAMES_NOTE

    changes = snapshot.get("changes") or {}
    display = _decision_change_display(snapshot)
    if display.empty:
        g["changes"] = {"note": [], "table": []}
    else:
        g["changes"] = {
            "note": [f"Comparaison causale : {_utc_label(changes.get('previous_time'))} → {_utc_label(changes.get('current_time'))}.", CHANGES_NOTE],
            "table": [list(display.columns)] + [[str(v) for v in r] for r in display.itertuples(index=False)],
        }

    evidence = snapshot.get("evidence")
    opposing: list[str] = []
    if isinstance(evidence, pd.DataFrame) and not evidence.empty:
        opposing_label = "↓ BAISSIER" if "HAUSSI" in bias else "↑ HAUSSIER" if "BAISSI" in bias else None
        if opposing_label:
            opposing = evidence.loc[evidence["Lecture"] == opposing_label, "Couche"].astype(str).tolist()
    risks = []
    if thesis.get("available"):
        risks.append(f"Condition d’invalidation à 7 jours : {thesis['invalidation']}.")
    opposition_text = " · ".join(opposing) if opposing else "aucune parmi les familles renseignées"
    if bias == "CONSOLIDATION":
        opposition_text = "pas de direction dominante ; surveiller les deux bornes du couloir"
    risks.append("Familles actuellement opposées : " + opposition_text)
    meeting = str((macro_context.get("cme") or {}).get("meeting_date") or "date non disponible")
    risks.append(f"Prochaine échéance Fed suivie : {meeting}.")
    if not quality.get("fresh"):
        risks.append(STALE_WARNING)
    g["risks"] = risks

    # Plan par horizon : mêmes entrées que render_scenario_plan (ligne du dernier relevé + synthèse courante)
    ordered = rows.copy()
    ordered["prediction_time"] = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce")
    ordered = ordered.dropna(subset=["prediction_time"]).sort_values("prediction_time")
    ordered = ordered[ordered["asset"].eq(asset)]
    features = {**ordered.iloc[-1].to_dict(), **latest}

    # « Contexte complémentaire » : premier bloc de la page = horizon 7 jours
    t7 = directional_thesis(features, ordered, horizon=DECISION_HORIZONS["7 jours"])
    if t7.get("available"):
        background = {name: value for name, value in directional_family_scores(features).items()
                      if name not in t7["family_evidence"] and name in ("Macro / taux", "ETF / liquidité", "Force relative", "Perpétuels", "Options")}
        if background:
            g["context"] = [CONTEXT_NOTE] + [f"{r['Famille']} · {r['Lecture']} — {r['Argument']}"
                                             for r in evidence_rows(features, {"family_evidence": background})]

    table = directional_scenario_table(latest, rows, horizon=7)
    if not table.empty:
        shown = table.drop(columns=["Poids de thèse"], errors="ignore")
        g["thesis"] = [list(shown.columns)] + [[str(v) for v in r] for r in shown.itertuples(index=False)]

    block = {"g": g, "H": {}}
    for label in HORIZONS:
        h = _horizon_block(asset, label, features, ordered)
        if h:
            block["H"][label] = h
    return block


def build_payload(root: str | Path, now: object | None = None) -> dict:
    """Lit le cache de données ``root`` (dossier qui contient normalized/, features/, live/) et construit le JSON."""
    root = Path(root)
    now_ts = pd.to_datetime(now, utc=True) if now is not None else pd.Timestamp.now(tz="UTC")
    all_rows, _version = read_latest_features(root / "features")
    macro_context = build_macro_context(read_macro_observations(root / "normalized" / "market.db"))
    db_path = root / "normalized" / "market.db"
    payload: dict = {"schema": SCHEMA}
    stamps: dict = {}
    for asset in ASSETS:
        block = _asset_block(asset, all_rows, macro_context, db_path, now_ts)
        if block:
            payload[asset] = block
            stamps[asset] = now_ts.strftime("%Y-%m-%dT%H:%M:%S+00:00")
    if not any(a in payload for a in ASSETS):
        raise RuntimeError("aucun relevé exploitable : rien à exporter")
    payload["t"] = stamps
    payload["src"] = {"name": SOURCE_NAME}
    payload["updated"] = now_ts.strftime("%Y-%m-%dT%H:%M:%S+00:00")
    return payload


def dumps(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


# ----------------------------------------------------------------------------- envoi GitHub
def push_to_github(text: str, *, repo: str, token: str, path: str = "scenario.json", branch: str = "main",
                   message: str | None = None, timeout: float = 20.0) -> str:
    """Crée ou met à jour ``path`` dans ``repo`` (« compte/dépôt ») via l'API GitHub. Retourne « created » / « updated »."""
    import requests

    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    sha = None
    got = requests.get(url, headers=headers, params={"ref": branch}, timeout=timeout)
    if got.status_code == 200:
        sha = got.json().get("sha")
    elif got.status_code != 404:
        got.raise_for_status()
    body = {"message": message or "Mise à jour automatique des scénarios", "branch": branch,
            "content": base64.b64encode(text.encode("utf-8")).decode("ascii")}
    if sha:
        body["sha"] = sha
    put = requests.put(url, headers=headers, json=body, timeout=timeout)
    put.raise_for_status()
    return "updated" if sha else "created"


# ----------------------------------------------------------------------------- point d'entrée appelé après chaque rafraîchissement
_lock = threading.Lock()
HEARTBEAT_MINUTES = 55  # même sans nouvelle donnée, on renvoie le fichier environ toutes les heures (preuve de vie)


def _setting(name: str) -> str:
    """Variable d'environnement, sinon « secrets » Streamlit (Community Cloud les expose aussi comme variables)."""
    value = os.environ.get(name, "").strip()
    if value:
        return value
    try:
        import streamlit as st

        return str(st.secrets.get(name, "")).strip()
    except Exception:  # noqa: BLE001  pas de Streamlit ou pas de secrets : valeur absente
        return ""


def _status(root: Path, **fields: object) -> None:
    # une ligne dans les journaux (« Manage app » > Logs sur Streamlit Community Cloud) : jamais le jeton
    print("[scenario_export]", " ".join(f"{k}={v}" for k, v in fields.items() if k != "note"), flush=True)
    try:
        (root / "scenario_export_status.json").write_text(
            json.dumps({"checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), **fields}, ensure_ascii=False, indent=1),
            encoding="utf-8")
    except OSError:
        pass


def export_after_refresh(runtime: str | Path, *, force: bool = False) -> dict:
    """À appeler à la fin de ``refresh_hosted_data``. Ne lève jamais d'exception."""
    root = Path(runtime)
    if not _lock.acquire(blocking=False):
        return {"status": "busy"}
    try:
        payload = build_payload(root)
        text = dumps(payload)
        (root / "scenario.json").write_text(text, encoding="utf-8")
        # signature du contenu SANS les horodatages d'export : on n'envoie que si quelque chose a changé
        stable = {k: v for k, v in payload.items() if k not in ("t", "updated")}
        digest = hashlib.sha256(dumps(stable).encode("utf-8")).hexdigest()
        stamp = root / ".scenario_export_state.json"
        try:
            state = json.loads(stamp.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            state = {}
        age_min = None
        if state.get("pushed_at"):
            age_min = (datetime.now(timezone.utc) - datetime.fromisoformat(state["pushed_at"])).total_seconds() / 60
        unchanged = state.get("digest") == digest and age_min is not None and age_min < HEARTBEAT_MINUTES
        token, repo = _setting("SCENARIO_GH_TOKEN"), _setting("SCENARIO_GH_REPO")
        if not token or not repo:
            _status(root, status="local_only", note="SCENARIO_GH_TOKEN / SCENARIO_GH_REPO non définis : fichier écrit en local seulement")
            return {"status": "local_only"}
        if unchanged and not force:
            _status(root, status="unchanged")
            return {"status": "unchanged"}
        result = push_to_github(text, repo=repo, token=token,
                                path=_setting("SCENARIO_GH_PATH") or "scenario.json",
                                branch=_setting("SCENARIO_GH_BRANCH") or "main")
        stamp.write_text(json.dumps({"digest": digest, "pushed_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}), encoding="utf-8")
        _status(root, status="pushed", github=result, asof={a: payload[a]["g"]["asof"] for a in ASSETS if a in payload})
        return {"status": "pushed", "github": result}
    except Exception as exc:  # noqa: BLE001  l'export ne doit jamais casser l'appli
        _status(root, status="error", error=f"{type(exc).__name__}: {str(exc)[:300]}")
        return {"status": "error", "error": str(exc)}
    finally:
        _lock.release()


if __name__ == "__main__":  # test à la main : python -m crypto_quant_engine.dashboard.scenario_export <dossier-de-données>
    import sys

    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(os.environ.get("CQE_DATA_DIR", "data"))
    out = build_payload(target)
    Path("scenario.json").write_text(dumps(out), encoding="utf-8")
    print("scenario.json écrit :", {a: list(out[a]["H"]) for a in ASSETS if a in out})
