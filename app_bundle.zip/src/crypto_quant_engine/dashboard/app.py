from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components

from crypto_quant_engine.config import data_dir
from crypto_quant_engine.constants import INSUFFICIENT_CONFIDENCE
from crypto_quant_engine.dashboard.scenarios import (
    directional_evidence_table,
    directional_scenario_table,
    directional_thesis,
    direction_label,
    exploratory_direction_index,
    gamma_exposure_summary,
    gamma_path_scenarios,
    implied_scenario_table,
    forward_band_calibration,
    tactical_exploitability,
)
from crypto_quant_engine.dashboard.macro import build_macro_context, macro_feature_overlay
from crypto_quant_engine.dashboard.pedagogy import (
    BEGINNER_GLOSSARY,
    attach_current_relative_context,
    confidence_proof_table,
    data_history_table,
    simple_direction_reading,
    simple_macro_reading,
    simple_market_ranges,
)
from crypto_quant_engine.dashboard.publication import is_public_student_mode
from crypto_quant_engine.storage import NormalizedStore


MINIMUM_HISTORY_DAYS = 180
MINIMUM_CANONICAL_BUCKETS = 17_520
PUBLIC_STUDENT_MODE = is_public_student_mode()

page_title = "Observatoire BTC / ETH · Espace élève" if PUBLIC_STUDENT_MODE else "BTC / ETH · Lecture du marché"
st.set_page_config(page_title=page_title, layout="wide")
st.markdown(
    """
    <style>
    .block-container {padding-top: 2rem; padding-bottom: 3rem; max-width: 1500px;}
    [data-testid="stMetric"] {border: 1px solid rgba(128,128,128,.20); border-radius: 12px; padding: 12px 16px;}
    [data-testid="stMetricLabel"] {font-weight: 650;}
    </style>
    """,
    unsafe_allow_html=True,
)
st.title(page_title)
if PUBLIC_STUDENT_MODE:
    st.caption(
        "Support pédagogique en lecture seule. Commencez par l’essentiel, puis ouvrez "
        "l’approfondissement pour comprendre les indicateurs. Une donnée absente reste absente."
    )
else:
    st.caption(
        "Une lecture simple en premier, les données et méthodes complètes en arrière-plan. "
        "Aucun indicateur manquant n’est remplacé par une estimation inventée."
    )
reading_mode = st.segmented_control(
    "Niveau de lecture",
    ["Essentiel", "Détaillé"],
    default="Essentiel",
    format_func=(
        (lambda value: "Comprendre en 2 minutes" if value == "Essentiel" else "Approfondir")
        if PUBLIC_STUDENT_MODE
        else None
    ),
    help="Essentiel traduit les indicateurs en langage courant. Détaillé conserve toutes les mesures techniques.",
)


def read_latest_predictions(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    with sqlite3.connect(path) as connection:
        return pd.read_sql_query(
            "SELECT * FROM predictions ORDER BY prediction_timestamp DESC LIMIT 2000",
            connection,
        )


def read_latest_features(root: Path) -> tuple[pd.DataFrame, str | None]:
    candidates = list(root.glob("*/features.csv.gz"))
    candidates.extend((root.parent / "live").glob("*/features.csv.gz"))
    if not candidates:
        return pd.DataFrame(), None
    latest = max(candidates, key=lambda path: path.stat().st_mtime)
    frame = pd.read_csv(latest)
    for column in ("prediction_time", "feature_available_time"):
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], utc=True, format="mixed")
    return frame, latest.parent.name


def read_research_summary(root: Path) -> dict[str, object] | None:
    pointer_path = root / "latest.json"
    if not pointer_path.exists():
        return None
    try:
        pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
        summary_path = Path(pointer["summary_path"])
        if not summary_path.is_absolute():
            summary_path = root.parents[1] / summary_path
        if not summary_path.exists():
            summary_path = pointer_path.parent / pointer["research_version"] / "summary.json"
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        freeze_path = summary_path.parent / "freeze_manifest.json"
        summary["_freeze_manifest"] = (
            json.loads(freeze_path.read_text(encoding="utf-8")) if freeze_path.exists() else {}
        )
        return summary
    except (OSError, KeyError, json.JSONDecodeError):
        return None


def read_macro_observations(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    store = NormalizedStore(path)
    blocks = [store.query(data_family=family) for family in ("MACRO", "FED", "RATES")]
    blocks = [block for block in blocks if not block.empty]
    return pd.concat(blocks, ignore_index=True) if blocks else pd.DataFrame()


def _fmt(value: object, suffix: str = "", digits: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    return f"{number:.{digits}f}{suffix}" if pd.notna(number) else "—"


def _thesis_conviction_label(value: object) -> str:
    """Translate the internal confluence score into a classroom decision label."""

    try:
        conviction = float(value)
    except (TypeError, ValueError):
        return "EN CONSTRUCTION"
    if conviction >= 70:
        return "FORTE"
    if conviction >= 40:
        return "AFFIRMÉE"
    return "PRUDENTE"


def _utc_label(value: object) -> str:
    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        return timestamp.tz_convert("UTC").strftime("%d/%m/%Y %H:%M UTC")
    except (TypeError, ValueError):
        return "—"


def show_macro_context(context: dict[str, object]) -> None:
    st.subheader("Économie mondiale et taux : Fed, BCE et Banque du Japon")
    if not context.get("available"):
        st.warning("Les sources économiques officielles n'ont pas encore livré un relevé exploitable.")
        return
    current = context.get("current", {})
    combined = context.get("combined_signal")
    macro_direction = (
        "Plutôt favorable" if combined is not None and float(combined) >= 0.20
        else "Plutôt défavorable" if combined is not None and float(combined) <= -0.20
        else "Partagé / neutre"
    )
    left, middle, right = st.columns(3)
    left.metric(
        "Contexte macro actuel",
        str(context.get("combined_label", "—")),
        macro_direction,
        delta_color="off",
    )
    cme = context.get("cme") or {}
    middle.metric(
        "Fed · prochaine réunion selon CME FedWatch",
        str(cme.get("meeting_date") or "INDISPONIBLE"),
        f"données CME au {_utc_label(cme.get('event_time'))}" if cme else "source non disponible",
        delta_color="off",
    )
    fed = context.get("fed") or {}
    target_low, target_high = fed.get("target_lower_pct"), fed.get("target_upper_pct")
    right.metric(
        "Cible Fed constatée",
        f"{target_low:.2f}–{target_high:.2f}%" if target_low is not None and target_high is not None else "—",
        f"réunion {fed.get('meeting_date', '—')}",
        delta_color="off",
    )

    regions = context.get("regions") or {}
    macro_rows = pd.DataFrame(
        [
            {
                "Zone": state.get("region_label", region),
                "Banque centrale": state.get("central_bank", "—"),
                "Croissance": f"{state.get('growth_label', '—')} · {_fmt(state.get('growth_value_pct'), '%')}",
                "Inflation": f"{state.get('inflation_label', '—')} · {_fmt(state.get('inflation_value_pct'), '%')}",
                "Monnaie / liquidité": f"{state.get('liquidity_label', '—')} · {_fmt(state.get('liquidity_value_pct'), '%')}",
                "Politique de taux": f"{state.get('policy_label', '—')} · {_fmt(state.get('policy_value_pct'), '%')}",
            }
            for region, state in regions.items()
        ]
    )
    if macro_rows.empty:
        macro_rows = pd.DataFrame(
            [
                {"Zone": "États-Unis", "Banque centrale": "Réserve fédérale (Fed)", "Croissance": current.get("growth_label"), "Inflation": current.get("inflation_label"), "Monnaie / liquidité": current.get("liquidity_label"), "Politique de taux": current.get("policy_label")}
            ]
        )
    st.dataframe(macro_rows, hide_index=True, use_container_width=True)

    if cme:
        c1, c2, c3 = st.columns(3)
        c1.metric("Fed via CME · baisse", _fmt(100 * cme.get("ease_probability"), "%", 1) if cme.get("ease_probability") is not None else "—")
        c2.metric("Fed via CME · statu quo", _fmt(100 * cme.get("unchanged_probability"), "%", 1) if cme.get("unchanged_probability") is not None else "—")
        c3.metric("Fed via CME · hausse", _fmt(100 * cme.get("hike_probability"), "%", 1) if cme.get("hike_probability") is not None else "—")
        targets = cme.get("target_probabilities")
        if isinstance(targets, list):
            target_table = pd.DataFrame(targets)
            if not target_table.empty:
                target_table = target_table[target_table["probability"] > 0].copy()
                target_table["Fourchette cible"] = target_table.apply(lambda row: f"{int(row['lower_bps'])}–{int(row['upper_bps'])} pb", axis=1)
                target_table["Probabilité CME"] = target_table["probability"].map(lambda value: f"{100 * value:.1f}%")
                st.dataframe(target_table[["Fourchette cible", "Probabilité CME"]], hide_index=True, use_container_width=True)
        st.caption("Ces probabilités concernent uniquement la prochaine décision de la Réserve fédérale américaine. Elles sont implicites dans les futures 30-Day Fed Funds · source : CME FedWatch.")

    history = context.get("history")
    if isinstance(history, pd.DataFrame) and not history.empty:
        with st.expander("Historique des régimes macro / Fed"):
            display = history.tail(36).copy()
            display["date"] = pd.to_datetime(display["date"], utc=True).dt.date
            st.dataframe(
                display[["date", "growth_label", "inflation_label", "liquidity_label", "policy_label"]].rename(
                    columns={"date": "Date", "growth_label": "Croissance", "inflation_label": "Inflation", "liquidity_label": "Liquidité", "policy_label": "Fed"}
                ),
                hide_index=True,
                use_container_width=True,
            )
    if fed:
        with st.expander("Réunions et comptes rendus de la Fed"):
            st.write(f"Dernière réunion observée : **{fed.get('meeting_date', '—')}** · minutes publiées : **{fed.get('minutes_release_date', '—')}**")
            if fed.get("statement_url"):
                st.markdown(f"[Communiqué officiel Fed]({fed['statement_url']})")
            if fed.get("minutes_url"):
                st.markdown(f"[Compte rendu officiel Fed]({fed['minutes_url']})")
            st.caption("Les comptages de langage sont exploratoires ; ils ne deviennent jamais une probabilité sans validation hors échantillon.")
    st.caption("Lecture quotidienne : données officielles Fed/BEA/BLS pour les États-Unis, BCE/Eurostat pour la zone euro, BoJ/Statistiques du Japon pour le Japon. Les révisions connues aujourd'hui restent séparées des tests historiques.")


def show_macro_plain(context: dict[str, object]) -> None:
    st.subheader("Taux et économie, en clair")
    reading = simple_macro_reading(context)
    cme = context.get("cme") or {}
    left, right = st.columns(2)
    left.metric("Effet possible sur les actifs risqués", str(reading["label"]))
    right.metric("Prochaine décision de taux suivie", str(cme.get("meeting_date") or "Date indisponible"))
    st.write(str(reading["explanation"]))
    st.info(str(reading["rate_path"]))
    regions = context.get("regions") or {}
    available_dimensions = sum(
        state.get(name) not in (None, "INDISPONIBLE")
        for state in regions.values()
        for name in ("growth_label", "inflation_label", "liquidity_label", "policy_label")
    )
    st.caption(f"Couverture économique actuelle : {available_dimensions}/{max(4, 4 * len(regions))} dimensions nommées et sourcées.")


def _plain_family_table(features: dict[str, object]) -> pd.DataFrame:
    table = directional_evidence_table(features).copy()
    table["Couche"] = table["Couche"].replace(
        {
            "Spot": "Achats et ventes immédiats",
            "Perpétuels": "Contrats avec effet de levier",
            "Options": "Marché des options",
            "Macro / taux": "Économie et taux",
        }
    )
    table["Lecture"] = table["Lecture"].replace(
        {
            "↑ HAUSSIER": "Plutôt favorable à la hausse",
            "↓ BAISSIER": "Plutôt favorable à la baisse",
            "↔ NEUTRE": "Sans direction nette",
            "— INDISPONIBLE": "Données insuffisantes",
        }
    )
    return table.rename(
        columns={"Couche": "Type de données", "Lecture": "Ce qu’il indique", "Couverture": "Mesures présentes"}
    )[["Type de données", "Ce qu’il indique", "Mesures présentes"]]


def show_beginner_overview(
    rows: pd.DataFrame,
    research_summary: dict[str, object] | None,
    macro_context: dict[str, object],
) -> None:
    latest = rows.sort_values("prediction_time").iloc[-1]
    latest_dict = {**latest.to_dict(), **macro_feature_overlay(macro_context)}
    reading = simple_direction_reading(latest_dict)
    ranges = simple_market_ranges(latest_dict)
    gamma = gamma_exposure_summary(latest_dict)
    thesis = directional_thesis(latest_dict, rows, horizon=7)
    thesis_scenarios = directional_scenario_table(latest_dict, rows, horizon=7)

    st.subheader("L’essentiel maintenant")
    price_col, direction_col, force_col, history_col = st.columns(4)
    price_col.metric("Prix observé", f"${float(latest['spot_price']):,.2f}")
    active_bias = str(thesis.get("bias", reading["direction"]))
    direction_col.metric("Thèse active · 7 jours", active_bias, str(reading["direction"]), delta_color="off")
    force_col.metric(
        "Conviction directionnelle",
        _thesis_conviction_label(thesis.get("conviction", reading["conviction"])),
        f"{reading['family_count']}/8 familles présentes",
        delta_color="off",
    )
    if thesis.get("available"):
        history_col.metric(
            "Zone dominante · 7 jours",
            f"${float(thesis['dominant_target']):,.0f}",
            f"bascule ${float(thesis['invalidation_level']):,.0f}",
            delta_color="off",
        )
    else:
        history_col.metric("Zone dominante · 7 jours", "En calcul", "surface d’options attendue")

    if thesis.get("available"):
        st.success(f"**Notre lecture :** {thesis['summary']}")
        if thesis.get("drivers"):
            st.write("**Moteurs principaux :** " + " · ".join(str(item) for item in thesis["drivers"]))
    if not thesis_scenarios.empty:
        scenario_display = thesis_scenarios.copy()
        scenario_display["Poids de thèse"] = scenario_display["Poids de thèse"].map(lambda value: f"{value:.1f} %")
        st.dataframe(scenario_display, hide_index=True, width="stretch")
        st.caption("Les poids classent les scénarios de travail selon la confluence actuelle ; leur somme vaut 100.")

    st.subheader("Amplitude de marché intégrée dans les options")
    if ranges.empty:
        st.warning("Le marché des options ne fournit pas encore une fourchette assez fiable.")
    else:
        st.dataframe(ranges, hide_index=True, width="stretch")
        st.caption(
            "La zone habituelle couvre environ 68 % d’une distribution théorique issue des options. "
            "Elle mesure l’amplitude attendue, pas la direction."
        )

    st.subheader("Pourquoi cette direction ?")
    st.dataframe(_plain_family_table(latest_dict), hide_index=True, use_container_width=True)

    st.subheader("Options : le mouvement peut-il être freiné ou amplifié ?")
    if gamma.get("available"):
        strike = gamma.get("dominant_strike")
        strike_text = f"${float(strike):,.0f}" if strike is not None else "non identifié"
        st.write(
            f"La sensibilité des options est **{str(gamma['regime']).lower()}**. Le prix d’exercice le plus concentré "
            f"se situe autour de **{strike_text}**. Près de cette zone, le marché peut se stabiliser ou accélérer selon les flux."
        )
        st.caption(
            "La position réelle des intermédiaires n’est pas publique : le tableau de bord ne prétend donc pas savoir "
            "s’ils sont acheteurs ou vendeurs de gamma."
        )
    else:
        st.info("Pas assez de données d’options pour décrire la forme probable du mouvement.")

    history = data_history_table(rows, research_summary, str(latest["asset"]), macro_context)
    if PUBLIC_STUDENT_MODE:
        with st.expander("Fraîcheur et profondeur des sources"):
            st.dataframe(history, hide_index=True, width="stretch")
    else:
        st.subheader("Historique réellement disponible")
        st.dataframe(history, hide_index=True, width="stretch")
        st.subheader("Preuves de confiance : état précis et prochain seuil")
        st.dataframe(
            confidence_proof_table(rows, research_summary, str(latest["asset"]), macro_context),
            hide_index=True,
            width="stretch",
        )

    with st.expander("Petit dictionnaire sans acronymes"):
        for term, explanation in BEGINNER_GLOSSARY.items():
            st.markdown(f"**{term}** — {explanation}")
    st.caption(f"Dernière mise à jour utilisée : {_utc_label(latest.get('prediction_time'))}")


def show_simple_validation(summary: dict[str, object] | None, asset: str) -> None:
    st.subheader("Ce que l’historique permet vraiment d’affirmer")
    reference = _validated_four_hour_reference(summary, asset)
    left, middle, right = st.columns(3)
    if reference:
        left.metric("Socle prix/volume", "Validé")
        middle.metric("Fréquence moyenne de hausse · 4 h", f"{100 * float(reference['probability']):.1f}%")
        right.metric("Signal conditionnel supérieur", "Non démontré")
        st.info(
            "Le recul historique est suffisant pour mesurer une fréquence moyenne. En revanche, aucun modèle plus complexe "
            "n’a encore prouvé qu’il prédit mieux que cette moyenne sur des données jamais vues."
        )
    else:
        left.metric("Socle historique", "En attente")
        middle.metric("Probabilité publiable", "Aucune")
        right.metric("Protection statistique", "Active")
        st.warning("Le tableau de bord conserve les scénarios descriptifs, mais ne publie pas de probabilité de modèle.")


def _readable_feature_value(key: str, value: object) -> str:
    if value is None or (not isinstance(value, (list, dict)) and pd.isna(value)):
        return "NON REÇU"
    if isinstance(value, bool):
        return "OUI" if value else "NON"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if "information_age_seconds" in key:
        return f"{number / 60:.1f} min" if number < 7_200 else f"{number / 3_600:.1f} h"
    if key.endswith("_usd") or "notional_usd" in key:
        return _money_compact(number)
    if key in {"cme_basis_fraction", "cme_basis_annualized", "oi_weighted_basis", "oi_weighted_funding", "cex_oi_weighted_basis", "cex_oi_weighted_funding", "dex_oi_weighted_basis", "dex_oi_weighted_funding"}:
        return f"{100 * number:.3f} %"
    if key in {"btc_dominance", "eth_dominance"}:
        return f"{100 * number:.2f} %"
    return f"{number:,.4f}"


def show_feature_sections(features: dict[str, object]) -> None:
    sections: list[tuple[str, str, dict[str, str]]] = [
        (
            "Marché au comptant",
            "Achats/ventes immédiats et carnet d’ordres.",
            {
                "spot_cvd_aggregate": "Pression acheteuse nette",
                "spot_volume": "Volume observé",
                "absorption_score": "Absorption des ordres",
                "spot_order_book_imbalance": "Déséquilibre du carnet",
            },
        ),
        (
            "Contrats perpétuels",
            "Positionnement à effet de levier, séparé des liquidations forcées.",
            {
                "open_interest_notional_usd": "Positions ouvertes",
                "delta_open_interest_notional_usd": "Variation des positions ouvertes",
                "oi_weighted_funding": "Coût du financement",
                "oi_weighted_basis": "Écart perpétuel / spot",
                "perp_cvd_aggregate": "Pression acheteuse nette",
            },
        ),
        (
            "Options et sensibilité gamma",
            "Amplitude et forme possibles du mouvement ; le signe réel des intermédiaires demeure inconnu.",
            {
                "pcr_oi_global": "Ratio puts / calls en positions",
                "pcr_volume_global": "Ratio puts / calls en volume",
                "atm_iv_30d": "Volatilité anticipée à 30 jours",
                "skew_30d": "Protection baisse contre hausse",
                "estimated_gamma_gross_usd_per_1pct_global": "Sensibilité gamma brute par mouvement de 1 %",
                "estimated_gamma_front_7d_near_spot_share": "Part proche du prix et de l’échéance",
                "estimated_gamma_reliable": "Estimation jugée assez complète",
            },
        ),
        (
            "Flux quotidiens des ETF BTC / ETH",
            "Entrées ou sorties nettes publiées chaque jour ; usage descriptif jusqu’à validation prospective.",
            {
                "etf_trading_date": "Journée de marché concernée",
                "etf_daily_net_flow_usd": "Flux net du jour",
                "etf_flow_3d_usd": "Cumul sur 3 jours publiés",
                "etf_flow_5d_usd": "Cumul sur 5 jours publiés",
                "etf_flow_10d_usd": "Cumul sur 10 jours publiés",
                "etf_history_day_count": "Journées historiques consolidées",
                "etf_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Offre de stablecoins",
            "Proxy de liquidité globale ; ce n’est pas une mesure des dépôts sur les plateformes.",
            {
                "stablecoin_supply_usd": "Offre totale indexée sur le dollar",
                "stablecoin_supply_change_1d_usd": "Variation sur 1 jour",
                "stablecoin_supply_change_7d_usd": "Variation sur 7 jours",
                "stablecoin_supply_change_30d_usd": "Variation sur 30 jours",
                "stablecoin_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Liquidations forcées longues / courtes",
            "Flux Binance continu. Les montants sont une borne basse observée, jamais le total du marché.",
            {
                "observed_long_liquidation_notional_usd": "Positions longues liquidées",
                "observed_short_liquidation_notional_usd": "Positions courtes liquidées",
                "observed_liquidation_order_count": "Ordres capturés",
                "observed_liquidation_imbalance": "Déséquilibre courtes moins longues",
                "liquidation_stream_live": "Flux d’écoute actif",
                "liquidation_snapshot_is_lower_bound": "Montants signalés comme borne basse",
            },
        ),
        (
            "Dérivés décentralisés · Hyperliquid",
            "Positions ouvertes, prime et financement des contrats perpétuels d'un DEX. Relevé toutes les 15 minutes.",
            {
                "dex_open_interest_notional_usd": "Positions ouvertes sur le DEX",
                "dex_oi_weighted_basis": "Écart du perpétuel DEX / prix oracle",
                "dex_oi_weighted_funding": "Coût du financement DEX",
                "dex_volume_24h_usd": "Volume DEX sur 24 heures",
                "perp_dex_exchange_coverage": "DEX observés",
                "dex_perp_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Comparaison ETH / BTC",
            "Force relative calculée uniquement avec des valeurs déjà disponibles.",
            {
                "eth_btc": "Ratio ETH / BTC",
                "eth_btc_return_24h": "Variation relative sur 24 h",
                "btc_dominance": "Dominance BTC",
                "total3_btc": "Altcoins hors BTC/ETH contre BTC",
            },
        ),
    ]
    for title, explanation, fields in sections:
        st.markdown(f"#### {title}")
        st.caption(explanation)
        table = pd.DataFrame(
            [
                {
                    "Mesure": label,
                    "Valeur": _readable_feature_value(key, features.get(key)),
                    "Champ technique": key,
                }
                for key, label in fields.items()
            ]
        )
        st.dataframe(table, hide_index=True, use_container_width=True)


def scenario_history(rows: pd.DataFrame, horizon: int) -> pd.DataFrame:
    history: list[dict[str, object]] = []
    ordered = rows.sort_values("prediction_time").tail(384).reset_index(drop=True)
    for index, row in ordered.iterrows():
        thesis = directional_thesis(row.to_dict(), ordered.iloc[max(0, index - 96): index + 1], horizon=horizon)
        if not thesis.get("available"):
            continue
        history.append(
            {
                "Date": row["prediction_time"],
                "Support de thèse": thesis["support"],
                "Prix observé": row["spot_price"],
                "Cible dominante": thesis["dominant_target"],
                "Résistance de thèse": thesis["resistance"],
            }
        )
    return pd.DataFrame(history)


def _validated_four_hour_reference(
    summary: dict[str, object] | None, asset: str
) -> dict[str, object] | None:
    if not summary:
        return None
    evaluation = next(
        (
            item
            for item in summary.get("evaluations", [])
            if item.get("asset") == asset and item.get("target") == "up_4h"
        ),
        None,
    )
    if not evaluation:
        return None
    effective = float(evaluation["holdout"]["effective_sample_count"])
    if evaluation.get("selected_model") != "M0_UNCONDITIONAL" or effective < 500:
        return None
    return {
        "probability": float(evaluation["latest_research_probability"]),
        "holdout_rate": float(evaluation["holdout"]["base_rate"]),
        "effective_sample": effective,
    }


def _money_compact(value: float) -> str:
    magnitude = abs(value)
    if magnitude >= 1_000_000_000:
        return f"${value / 1_000_000_000:,.2f} Md"
    if magnitude >= 1_000_000:
        return f"${value / 1_000_000:,.1f} M"
    if magnitude >= 1_000:
        return f"${value / 1_000:,.1f} k"
    return f"${value:,.0f}"


def _summary_table(
    latest: dict[str, object],
    research_summary: dict[str, object] | None,
) -> pd.DataFrame:
    gate = tactical_exploitability(latest)
    asset = str(latest.get("asset", ""))
    reference = _validated_four_hour_reference(research_summary, asset)
    gamma = gamma_exposure_summary(latest)
    rows: list[dict[str, str]] = []
    if reference:
        probability = float(reference["probability"])
        statistical_reading = "↑ HAUSSIER LÉGER" if probability >= 0.525 else "↓ BAISSIER LÉGER" if probability <= 0.475 else "↔ NEUTRE"
        rows.append(
            {
                "Couche": "Statistique validée · 4 h",
                "Lecture directe": statistical_reading,
                "Chiffre": f"P(hausse) {100 * probability:.1f}%",
                "Solidité": f"BASE RATE · N eff. {reference['effective_sample']:,.0f}",
            }
        )
    else:
        rows.append(
            {
                "Couche": "Repère historique · 4 h",
                "Lecture directe": "HISTORIQUE EN CONSTRUCTION",
                "Chiffre": "Échantillon en cours",
                "Solidité": "COLLECTE ACTIVE",
            }
        )
    thesis = directional_thesis(latest, horizon=7)
    rows.append(
        {
            "Couche": "Thèse de marché · 7 jours",
            "Lecture directe": str(thesis.get("bias", gate["direction"])),
            "Chiffre": f"Conviction {float(thesis.get('conviction', 0)):.0f}/100",
            "Solidité": f"{gate['family_count']}/{gate['family_total']} familles",
        }
    )
    macro_values = [
        latest.get(name)
        for name in (
            "macro_growth_signal",
            "macro_inflation_signal",
            "macro_liquidity_signal",
            "macro_policy_signal",
            "cme_policy_expectation_signal",
        )
        if latest.get(name) is not None and pd.notna(latest.get(name))
    ]
    if macro_values:
        macro_index = 50.0 + 40.0 * float(pd.Series(macro_values, dtype=float).mean())
        rows.append(
            {
                "Couche": "Macro / Fed / CME · contexte",
                "Lecture directe": direction_label(macro_index).replace(" · exploratoire", ""),
                "Chiffre": "Régime courant descriptif",
                "Solidité": "ACTUEL · NON VINTAGE-SAFE",
            }
        )
    if gamma.get("available"):
        gross = float(gamma["gross_usd_per_1pct"])
        rows.append(
            {
                "Couche": "Gamma · forme du mouvement",
                "Lecture directe": str(gamma["regime"]),
                "Chiffre": f"Brut {_money_compact(gross)} / mouvement de 1%",
                "Solidité": str(gamma["reliability"]),
            }
        )
    else:
        rows.append(
            {
                "Couche": "Gamma · forme du mouvement",
                "Lecture directe": "— INDISPONIBLE",
                "Chiffre": "Aucune estimation",
                "Solidité": "INDISPONIBLE",
            }
        )
    return pd.DataFrame(rows)


def show_scenario_explorer(
    rows: pd.DataFrame,
    feature_version: str | None,
    research_summary: dict[str, object] | None,
    macro_context: dict[str, object],
) -> None:
    latest = rows.sort_values("prediction_time").iloc[-1]
    latest_dict = {**latest.to_dict(), **macro_feature_overlay(macro_context)}
    score, factors = exploratory_direction_index(latest_dict)
    gate = tactical_exploitability(latest_dict)
    scenario_table = implied_scenario_table(latest_dict)
    thesis = directional_thesis(latest_dict, rows, horizon=7)
    thesis_scenarios = directional_scenario_table(latest_dict, rows, horizon=7)

    price_col, bias_col, conviction_col, probability_col = st.columns(4)
    price_col.metric("Prix actuel", f"${float(latest['spot_price']):,.2f}")
    bias_direction = str(thesis.get("bias", gate["direction"]))
    bias_col.metric(
        "Lecture tactique",
        bias_direction,
        str(gate["direction"]),
        delta_color="off",
    )
    conviction_col.metric(
        "Conviction directionnelle",
        _thesis_conviction_label(thesis.get("conviction", 0)),
        f"{gate['family_count']}/{gate['family_total']} familles présentes",
        delta_color="off",
    )
    if thesis.get("available"):
        probability_col.metric(
            "Zone dominante · 7 jours",
            f"${float(thesis['dominant_target']):,.0f}",
            f"niveau de bascule ${float(thesis['invalidation_level']):,.0f}",
            delta_color="off",
        )
    else:
        probability_col.metric("Zone dominante · 7 jours", "EN CALCUL")

    if thesis.get("available"):
        st.success(f"**Thèse active :** {thesis['summary']}")
        if thesis.get("drivers"):
            st.write("**Confluences dominantes :** " + " · ".join(str(item) for item in thesis["drivers"]))
    st.subheader("Scénarios directionnels · horizon 7 jours")
    if thesis_scenarios.empty:
        st.warning("La surface d’options ne permet pas encore de chiffrer les zones de scénario.")
    else:
        directional_display = thesis_scenarios.copy()
        directional_display["Poids de thèse"] = directional_display["Poids de thèse"].map(
            lambda value: f"{value:.1f} %"
        )
        st.dataframe(directional_display, hide_index=True, width="stretch")
        st.caption("Ces poids ordonnent la thèse, la consolidation et son invalidation ; ils totalisent 100.")

    st.subheader("Tableau de confluence")
    st.dataframe(_summary_table(latest_dict, research_summary), hide_index=True, use_container_width=True)

    if not PUBLIC_STUDENT_MODE:
        st.subheader("Preuves de confiance et seuils restants")
        st.dataframe(
            confidence_proof_table(rows, research_summary, str(latest["asset"]), macro_context),
            hide_index=True,
            width="stretch",
        )

    st.subheader("Votes directionnels par marché")
    family_display = directional_evidence_table(latest_dict).drop(columns=["Interprétation"])
    st.dataframe(family_display, hide_index=True, use_container_width=True)
    st.caption(
        "Les votes séparent comptant, dérivés, options, macro/taux, ETF/liquidité, liquidations, force relative et CME futures."
    )

    st.subheader("Amplitude statistique issue des options")
    if scenario_table.empty:
        st.warning("Surface de volatilité implicite indisponible pour construire les fourchettes.")
    else:
        display = scenario_table.drop(columns=["Jours", "Source IV"]).copy()
        for column in ("Scénario bas", "Point central", "Scénario haut", "Zone 68% basse", "Zone 68% haute"):
            display[column] = display[column].map(lambda value: f"${value:,.2f}")
        for column in ("Amplitude implicite 1σ", "IV annualisée"):
            display[column] = display[column].map(lambda value: f"{value:.2f}%")
        for column in ("Probabilité zone centrale", "Probabilité chaque queue"):
            display[column] = display[column].map(lambda value: f"≈ {value:.0f}%")
        for column in ("P(|mouvement| ≥ 1%)", "P(|mouvement| ≥ 3%)", "P(|mouvement| ≥ 5%)"):
            display[column] = display[column].map(lambda value: f"≈ {value:.1f}%")
        st.dataframe(display, hide_index=True, use_container_width=True)
        calibration = forward_band_calibration(rows)
        st.markdown("**Calibration forward de la zone 68 %**")
        if not calibration.empty:
            calibration_display = calibration.copy()
            calibration_display["Couverture observée zone 68%"] = calibration_display["Couverture observée zone 68%"].map(
                lambda value: "—" if pd.isna(value) else f"{value:.1f}%"
            )
            calibration_display["Cible théorique"] = calibration_display["Cible théorique"].map(lambda value: f"{value:.2f}%")
            st.dataframe(calibration_display, hide_index=True, use_container_width=True)

    gamma = gamma_exposure_summary(latest_dict)
    st.subheader("Carte gamma · scénarios conditionnés par le marché")
    if not gamma.get("available"):
        st.warning("Gamma non calculable sur la surface disponible ; aucune position dealer n’est supposée.")
    else:
        gross = float(gamma["gross_usd_per_1pct"])
        gamma_left, gamma_middle, gamma_right = st.columns(3)
        gamma_left.metric("Gamma brut estimé / 1%", _money_compact(gross))
        gamma_middle.metric("Régime", str(gamma["regime"]))
        dominant = gamma.get("dominant_strike")
        gamma_right.metric("Strike gamma dominant", f"${float(dominant):,.0f}" if dominant else "—", str(gamma["reliability"]), delta_color="off")
        gamma_scenarios = gamma_path_scenarios(latest_dict)
        st.dataframe(gamma_scenarios, hide_index=True, use_container_width=True)
        st.caption(
            "ESTIMATED_DEALER_GAMMA : Black–Scholes sur mark IV/OI point-in-time. "
            "Le signe dealer reste inconnu : les scénarios sont donc activés par proximité des strikes, flux et volatilité réalisée, pas par une position inventée."
        )

    st.subheader("Évolution des scénarios")
    horizon = st.select_slider(
        "Horizon de la fourchette",
        options=[1, 7, 30],
        value=7,
        format_func=lambda days: f"{days} jour" if days == 1 else f"{days} jours",
    )
    history = scenario_history(rows, horizon)
    if history.empty:
        st.info("L’historique des scénarios se remplira avec les prochaines collectes.")
    else:
        figure = go.Figure()
        figure.add_trace(
            go.Scatter(
                x=history["Date"],
                y=history["Support de thèse"],
                name="Support de thèse",
                line={"color": "#ef4444", "dash": "dot"},
            )
        )
        figure.add_trace(
            go.Scatter(
                x=history["Date"],
                y=history["Résistance de thèse"],
                name="Résistance de thèse",
                fill="tonexty",
                fillcolor="rgba(59, 130, 246, 0.12)",
                line={"color": "#22c55e", "dash": "dot"},
            )
        )
        figure.add_trace(
            go.Scatter(
                x=history["Date"],
                y=history["Cible dominante"],
                name="Cible dominante",
                line={"color": "#f59e0b", "width": 2},
            )
        )
        figure.add_trace(
            go.Scatter(
                x=history["Date"],
                y=history["Prix observé"],
                name="Prix observé",
                line={"color": "#60a5fa", "width": 3},
            )
        )
        figure.update_layout(
            height=420,
            margin={"l": 10, "r": 10, "t": 20, "b": 10},
            hovermode="x unified",
            yaxis_title="Prix USD",
            legend={"orientation": "h"},
        )
        st.plotly_chart(figure, use_container_width=True)

    first_time = rows["prediction_time"].min()
    last_time = rows["prediction_time"].max()
    history_days = max(0.0, (last_time - first_time).total_seconds() / 86_400)
    historical_rows = len(rows)
    if research_summary:
        boundary = research_summary.get("_freeze_manifest", {}).get("boundaries", {}).get(str(latest["asset"]), {})
        if boundary:
            history_days = max(
                0.0,
                (pd.Timestamp(boundary["history_end"]) - pd.Timestamp(boundary["history_start"])).total_seconds()
                / 86_400,
            )
            historical_rows = int(boundary.get("row_count", historical_rows))
    day_ratio = min(history_days / MINIMUM_HISTORY_DAYS, 1.0)
    bucket_ratio = min(historical_rows / MINIMUM_CANONICAL_BUCKETS, 1.0)
    st.subheader("Progression du backtest")
    maturity_left, maturity_right = st.columns(2)
    with maturity_left:
        st.progress(day_ratio, text=f"Historique : {history_days:.2f} / {MINIMUM_HISTORY_DAYS} jours")
    with maturity_right:
        st.progress(bucket_ratio, text=f"Intervalles : {historical_rows:,} / {MINIMUM_CANONICAL_BUCKETS:,}")

    with st.expander("Méthode et preuves de la lecture tactique"):
        st.write(
            "Les huit familles votent séparément afin de ne pas multiplier artificiellement des indicateurs corrélés. "
            "La conviction combine leur couverture, leur accord et leur intensité ; la thèse donne toujours son niveau "
            "de bascule pour pouvoir être réfutée par le marché."
        )
        if factors:
            factor_frame = pd.DataFrame(
                {
                    "Facteur": list(factors.keys()),
                    "Sens": [
                        "Favorable à la hausse" if value > 0.05 else "Favorable à la baisse" if value < -0.05 else "Neutre"
                        for value in factors.values()
                    ],
                    "Intensité": [
                        "Marquée" if abs(value) >= 0.55 else "Modérée" if abs(value) >= 0.20 else "Faible"
                        for value in factors.values()
                    ],
                }
            )
            st.dataframe(factor_frame, hide_index=True, use_container_width=True)

    with st.expander("Données de marché détaillées"):
        show_feature_sections(latest_dict)
    if PUBLIC_STUDENT_MODE:
        st.caption(f"Données observées au {_utc_label(latest.get('prediction_time'))}.")
    else:
        st.caption(f"Snapshot {latest.get('prediction_time')} · version {feature_version}")


TARGET_LABELS = {
    "up_4h": "Hausse à 4 h",
    "up_24h": "Hausse à 24 h",
    "up_72h": "Hausse à 72 h",
    "up_7d": "Hausse à 7 j",
    "first_touch_plus_3_before_minus_3_72h": "+3 % avant −3 % (72 h)",
}


def show_historical_validation(summary: dict[str, object] | None, asset: str) -> None:
    st.subheader("Backtest historique gelé")
    if not summary:
        st.info("Aucun rapport historique versionné n’est encore disponible.")
        return
    evaluations = [item for item in summary.get("evaluations", []) if item.get("asset") == asset]
    if not evaluations:
        st.info(f"Aucun résultat historique disponible pour {asset}.")
        return
    four_hour = next((item for item in evaluations if item["target"] == "up_4h"), None)
    if four_hour and float(four_hour["holdout"]["effective_sample_count"]) >= 500:
        left, middle, right = st.columns(3)
        left.metric(
            "Taux de base historique 4 h",
            f"{100 * float(four_hour['latest_research_probability']):.1f}%",
        )
        middle.metric(
            "Brier holdout 4 h",
            f"{float(four_hour['holdout']['brier']):.4f}",
        )
        right.metric(
            "Échantillon effectif 4 h",
            f"{float(four_hour['holdout']['effective_sample_count']):,.0f}",
        )
        st.info(
            "Ce chiffre est un taux de référence non conditionnel, pas un signal de marché actuel. "
            "Les modèles régime/logistique n’ont pas démontré d’amélioration robuste après correction multiple."
        )

    rows = []
    for item in evaluations:
        holdout = item["holdout"]
        effective = float(holdout["effective_sample_count"])
        status = item["status"]
        if item["selected_model"] == "M0_UNCONDITIONAL" and effective < 500:
            status = "ÉCHANTILLON EFFECTIF INSUFFISANT"
        elif item["selected_model"] == "M0_UNCONDITIONAL":
            status = "TAUX DE BASE VALIDÉ · PAS D’EDGE CONDITIONNEL"
        rows.append(
            {
                "Horizon / cible": TARGET_LABELS.get(item["target"], item["target"]),
                "Statut": status,
                "Modèle retenu": "M0 taux de base" if item["selected_model"] == "M0_UNCONDITIONAL" else item["selected_model"],
                "Taux observé holdout": f"{100 * float(holdout['base_rate']):.2f}%",
                "Brier": f"{float(holdout['brier']):.4f}",
                "ECE": f"{float(holdout['expected_calibration_error']):.4f}",
                "N brut": f"{int(holdout['sample_count']):,}",
                "N effectif": f"{effective:,.1f}",
            }
        )
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    if PUBLIC_STUDENT_MODE:
        st.caption(
            "Contrôle honnête : test final gardé à part, validation dans l’ordre du temps, "
            "période de sécurité entre apprentissage et test, et correction des essais multiples."
        )
    else:
        st.caption(
            f"Dataset {summary.get('dataset_version')} · recherche {summary.get('research_version')} · "
            "holdout final 20 % gelé, walk-forward purgé, embargo 7 jours, correction Benjamini–Hochberg."
        )
    with st.expander("Pourquoi aucun modèle plus complexe n’est publié"):
        st.write(
            "À 4 h, la logistique a légèrement réduit le Brier pendant le développement, mais l’effet "
            "n’était ni significatif après correction multiple ni stable entre régimes. Aux horizons plus "
            "longs, les modèles conditionnels ont généralement fait moins bien que le taux de base. "
            "Le boosting reste donc exclu de la production, conformément au protocole anti-surapprentissage."
        )


def show_prediction_journal(predictions: pd.DataFrame, asset: str) -> None:
    # This is an internal statistical audit surface. Even if a future layout
    # calls it accidentally, never expose its technical statuses to students.
    if PUBLIC_STUDENT_MODE:
        return
    asset_predictions = predictions[predictions["asset"] == asset] if not predictions.empty else pd.DataFrame()
    if asset_predictions.empty:
        st.warning(
            "Le modèle statistique n’est pas encore validé. L’explorateur continue néanmoins "
            "d’afficher et d’archiver l’évolution des scénarios observables."
        )
        with st.expander("Statut technique de validation"):
            st.code(INSUFFICIENT_CONFIDENCE)
            st.write("Aucune probabilité calibrée ni performance hors échantillon n’est encore revendiquée.")
        return

    asset_predictions = asset_predictions.sort_values("prediction_timestamp", ascending=False)
    latest_prediction = asset_predictions.iloc[0]
    confidence = json.loads(latest_prediction["confidence_json"])
    quality = json.loads(latest_prediction["data_quality_json"])
    regimes = json.loads(latest_prediction["market_regime_json"])
    left, middle, right = st.columns(3)
    left.metric("Prix journalisé", f"${latest_prediction['price']:,.2f}")
    quality_score = float(quality.get("score", 0))
    quality_label = "SUFFISANTE" if quality_score >= 80 else "PARTIELLE" if quality_score >= 50 else "INSUFFISANTE"
    middle.metric("Qualité des données", quality_label, "voir les preuves famille par famille", delta_color="off")
    status_label = (
        "TAUX DE BASE SEULEMENT"
        if latest_prediction["status"] == "VALIDATED_BASE_RATE_ONLY"
        else "NON EXPLOITABLE POUR PRÉDICTION"
    )
    right.metric("Usage statistique", status_label)
    st.json({"macro": latest_prediction["macro_regime"], **regimes})
    if latest_prediction["status"] == "VALIDATED_BASE_RATE_ONLY" and pd.notna(latest_prediction["calibrated_probability"]):
        st.metric("Taux de base journalisé", f"{100 * latest_prediction['calibrated_probability']:.1f}%")
        st.info("Référence non conditionnelle journalisée pour le suivi prospectif ; ce n’est pas un signal.")
    elif (
        latest_prediction["status"] in {"STATISTICALLY_USABLE", "BACKTEST_VALIDATED_FORWARD_PENDING"}
        and pd.notna(latest_prediction["calibrated_probability"])
    ):
        st.metric("Probabilité calibrée", f"{100 * latest_prediction['calibrated_probability']:.1f}%")
    else:
        st.warning("Probabilité du modèle non validée ; utilisez uniquement l’explorateur descriptif.")
    st.caption(f"Modèle {latest_prediction['model_version']} · snapshot {latest_prediction['prediction_timestamp']}")
    with st.expander("Diagnostic technique brut (pour audit)"):
        st.json({"data_quality": quality, "confidence": confidence})


journal_path = Path(os.getenv("CQE_JOURNAL_DB", data_dir() / "predictions" / "journal.db"))
predictions = read_latest_predictions(journal_path)
feature_snapshots, feature_version = read_latest_features(data_dir() / "features")
research_summary = read_research_summary(data_dir() / "research" / "runs")
macro_observations = read_macro_observations(data_dir() / "normalized" / "market.db")
macro_context = build_macro_context(macro_observations)
if reading_mode == "Essentiel":
    show_macro_plain(macro_context)
else:
    show_macro_context(macro_context)
st.divider()
asset = st.segmented_control("Actif", ["BTC", "ETH"], default="BTC")

asset_features = (
    feature_snapshots[feature_snapshots["asset"] == asset].copy()
    if not feature_snapshots.empty
    else pd.DataFrame()
)
if not asset_features.empty:
    asset_features = attach_current_relative_context(asset_features, feature_snapshots)
if asset_features.empty:
    st.info("Aucun snapshot de marché. Lancez ACTUALISER_DONNEES.bat.")
elif reading_mode == "Essentiel":
    show_beginner_overview(asset_features, research_summary, macro_context)
else:
    show_scenario_explorer(asset_features, feature_version, research_summary, macro_context)

st.divider()
if reading_mode == "Essentiel":
    if not PUBLIC_STUDENT_MODE:
        show_simple_validation(research_summary, asset)
    with st.expander("Voir toute l’analyse technique, les graphiques et les tests"):
        show_macro_context(macro_context)
        if not asset_features.empty:
            show_scenario_explorer(asset_features, feature_version, research_summary, macro_context)
        if not PUBLIC_STUDENT_MODE:
            st.subheader("Couche statistique complète")
            show_historical_validation(research_summary, asset)
            show_prediction_journal(predictions, asset)
else:
    if not PUBLIC_STUDENT_MODE:
        st.subheader("Couche statistique validée")
        show_historical_validation(research_summary, asset)
        show_prediction_journal(predictions, asset)

if PUBLIC_STUDENT_MODE:
    components.html(
        "<script>setTimeout(function(){window.parent.location.reload();}, 900000);</script>",
        height=0,
        width=0,
    )
