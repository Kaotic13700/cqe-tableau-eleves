from __future__ import annotations

import json
import os
import sqlite3
from html import escape
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from crypto_quant_engine.config import data_dir
from crypto_quant_engine.constants import INSUFFICIENT_CONFIDENCE
from crypto_quant_engine.dashboard.charting import (
    prepare_forward_scenario_chart,
    prepare_scenario_chart,
    scenario_axis_config,
    scenario_lookback,
)
from crypto_quant_engine.dashboard.decision import (
    DECISION_HORIZONS,
    build_decision_snapshot,
)
from crypto_quant_engine.dashboard.scenarios import (
    directional_evidence_table,
    directional_scenario_table,
    directional_thesis,
    direction_label,
    exploratory_direction_index,
    gamma_exposure_summary,
    gamma_path_scenarios,
    implied_scenario_table,
    forward_band_calibration,
    tactical_exploitability,
)
from crypto_quant_engine.dashboard.macro import build_macro_context, macro_feature_overlay
from crypto_quant_engine.dashboard.pedagogy import (
    BEGINNER_GLOSSARY,
    attach_current_relative_context,
    confidence_proof_table,
    data_history_table,
    simple_macro_reading,
    simple_market_ranges,
)
from crypto_quant_engine.dashboard.publication import is_public_student_mode
from crypto_quant_engine.dashboard.liquidations import show_liquidations
from crypto_quant_engine.storage import NormalizedStore


MINIMUM_HISTORY_DAYS = 180
MINIMUM_CANONICAL_BUCKETS = 17_520
PUBLIC_STUDENT_MODE = is_public_student_mode()

page_title = "Observatoire BTC / ETH · Espace élève" if PUBLIC_STUDENT_MODE else "BTC / ETH · Lecture du marché"
st.set_page_config(page_title=page_title, page_icon="🧭", layout="wide")
st.markdown(
    """
    <style>
    :root {
        --bc-bg: #090a0d;
        --bc-surface: #13151a;
        --bc-surface-2: #1b1d23;
        --bc-gold: #d8a63a;
        --bc-gold-soft: #f0ca73;
        --bc-ivory: #f4efe3;
        --bc-muted: #a9a59b;
        --bc-green: #2dcc75;
        --bc-red: #ef5964;
    }
    .stApp {
        color: var(--bc-ivory);
        background:
            radial-gradient(circle at 12% 0%, rgba(216,166,58,.12), transparent 28rem),
            radial-gradient(circle at 92% 18%, rgba(216,166,58,.055), transparent 24rem),
            linear-gradient(180deg, #0d0f13 0%, var(--bc-bg) 46%, #08090b 100%);
    }
    [data-testid="stHeader"] {background: rgba(9,10,13,.82); backdrop-filter: blur(12px);}
    .block-container {padding-top: 1.45rem; padding-bottom: 3rem; max-width: 1460px;}
    h1, h2, h3, h4 {color: var(--bc-ivory); letter-spacing: -.02em;}
    h3 {margin-top: 1.65rem !important;}
    a {color: var(--bc-gold-soft) !important;}
    .bc-hero {
        display: grid;
        grid-template-columns: auto 1fr auto;
        gap: 1.15rem;
        align-items: center;
        padding: 1.2rem 1.35rem;
        border: 1px solid rgba(216,166,58,.50);
        border-radius: 18px;
        background: linear-gradient(135deg, rgba(31,29,23,.96), rgba(17,19,24,.96) 58%, rgba(10,11,14,.98));
        box-shadow: 0 18px 55px rgba(0,0,0,.34), inset 0 1px 0 rgba(255,255,255,.045);
        margin-bottom: .8rem;
    }
    .bc-mark {
        width: 64px;
        height: 64px;
        display: grid;
        place-items: center;
        border: 1px solid rgba(216,166,58,.64);
        border-radius: 17px;
        background: radial-gradient(circle, rgba(216,166,58,.22), rgba(216,166,58,.035) 68%);
        color: var(--bc-gold-soft);
        box-shadow: inset 0 0 24px rgba(216,166,58,.08);
    }
    .bc-mark svg {width: 54px; height: 54px; display: block;}
    .bc-eyebrow {color: var(--bc-gold-soft); font-size: .72rem; font-weight: 800; letter-spacing: .21em; margin: 0 0 .2rem;}
    .bc-hero h1 {font-size: clamp(1.55rem, 3vw, 2.35rem); line-height: 1.05; margin: 0;}
    .bc-subtitle {color: var(--bc-muted); margin: .35rem 0 0; font-size: .94rem;}
    .bc-pill {
        color: #171208;
        background: linear-gradient(135deg, var(--bc-gold-soft), var(--bc-gold));
        border-radius: 999px;
        padding: .48rem .78rem;
        font-size: .68rem;
        font-weight: 900;
        letter-spacing: .12em;
        white-space: nowrap;
    }
    .bc-route {display: grid; grid-template-columns: repeat(6, 1fr); gap: .42rem; margin: .25rem 0 1.15rem;}
    .bc-route span {
        color: var(--bc-muted); font-size: .66rem; letter-spacing: .08em; font-weight: 780;
        border: 1px solid rgba(216,166,58,.16); border-radius: 10px; padding: .5rem .6rem;
        background: rgba(19,21,26,.54);
    }
    .bc-route i {color: var(--bc-gold); font-style: normal; margin-right: .38rem;}
    .bc-livebar {
        display: flex; align-items: center; justify-content: space-between; gap: .75rem; flex-wrap: wrap;
        border: 1px solid rgba(216,166,58,.24); border-radius: 12px; padding: .62rem .82rem;
        background: linear-gradient(90deg, rgba(216,166,58,.08), rgba(19,21,26,.72));
        color: var(--bc-muted); font-size: .76rem; margin: .25rem 0 1rem;
    }
    .bc-livebar strong {color: var(--bc-ivory); letter-spacing: .05em;}
    .bc-live-dot {display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: .42rem; box-shadow: 0 0 12px currentColor;}
    .bc-livebar.fresh .bc-live-dot {color: var(--bc-green); background: var(--bc-green);}
    .bc-livebar.catchup .bc-live-dot {color: var(--bc-gold); background: var(--bc-gold);}
    .bc-livebar.stale .bc-live-dot {color: var(--bc-red); background: var(--bc-red);}
    .bc-scenario-card {
        display: grid; grid-template-columns: 1.25fr repeat(3, minmax(0, 1fr)); gap: .65rem;
        border: 1px solid rgba(216,166,58,.28); border-radius: 14px; padding: .8rem;
        background: linear-gradient(135deg, rgba(25,27,32,.96), rgba(12,14,17,.96)); margin: .2rem 0 .8rem;
    }
    .bc-scenario-card > div {padding: .45rem .55rem; border-right: 1px solid rgba(216,166,58,.14);}
    .bc-scenario-card > div:last-child {border-right: 0;}
    .bc-scenario-label {display: block; color: var(--bc-muted); font-size: .68rem; letter-spacing: .08em; margin-bottom: .16rem;}
    .bc-scenario-value {display: block; color: var(--bc-ivory); font-weight: 850; font-size: 1rem;}
    .bc-scenario-value.up {color: var(--bc-green);}
    .bc-scenario-value.down {color: var(--bc-red);}
    .bc-scenario-value.flat {color: var(--bc-gold-soft);}
    .bc-desk-strip {
        display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 1px;
        border: 1px solid rgba(216,166,58,.30); border-radius: 14px; overflow: hidden;
        background: rgba(216,166,58,.18); margin: .2rem 0 .55rem;
    }
    .bc-desk-strip > div {background: linear-gradient(145deg, rgba(27,29,35,.97), rgba(14,16,20,.97)); padding: .75rem .8rem; min-width: 0;}
    .bc-desk-label {display: block; color: var(--bc-muted); font-size: .64rem; letter-spacing: .08em; margin-bottom: .2rem;}
    .bc-desk-value {display: block; color: var(--bc-ivory); font-weight: 850; font-size: .94rem; line-height: 1.18; overflow-wrap: anywhere;}
    .bc-desk-value.up {color: var(--bc-green);}
    .bc-desk-value.down {color: var(--bc-red);}
    .bc-desk-value.flat {color: var(--bc-gold-soft);}
    [data-testid="stMetric"] {
        border: 1px solid rgba(216,166,58,.28);
        border-radius: 14px;
        padding: 13px 16px;
        background: linear-gradient(145deg, rgba(27,29,35,.94), rgba(16,18,22,.94));
        box-shadow: 0 10px 30px rgba(0,0,0,.18);
    }
    [data-testid="stMetricLabel"] {font-weight: 680; color: var(--bc-muted);}
    [data-testid="stMetricValue"] {color: var(--bc-ivory);}
    [data-testid="stMetricValue"] > div {
        white-space: normal;
        overflow: visible;
        text-overflow: clip;
        line-height: 1.12;
        font-size: clamp(1.28rem, 2.25vw, 2rem);
    }
    [data-testid="stDataFrame"], [data-testid="stPlotlyChart"] {
        border: 1px solid rgba(216,166,58,.20);
        border-radius: 14px;
        overflow: hidden;
        background: rgba(15,17,21,.76);
    }
    [data-testid="stExpander"] {
        border: 1px solid rgba(216,166,58,.18);
        border-radius: 12px;
        background: rgba(19,21,26,.62);
    }
    [data-testid="stAlert"] {border-radius: 12px; border-color: rgba(216,166,58,.30);}
    div[data-baseweb="select"] > div, div[role="radiogroup"] {
        border-radius: 12px;
    }
    button[kind="segmented_controlActive"] {
        color: #171208 !important;
        background: linear-gradient(135deg, var(--bc-gold-soft), var(--bc-gold)) !important;
        border-color: var(--bc-gold) !important;
    }
    hr {border-color: rgba(216,166,58,.18) !important;}
    @media (max-width: 720px) {
        .bc-hero {grid-template-columns: auto 1fr; padding: 1rem;}
        .bc-pill {display: none;}
        .bc-mark {width: 52px; height: 52px;}
        .bc-mark svg {width: 45px; height: 45px;}
        .bc-route {grid-template-columns: repeat(2, 1fr);}
        .bc-scenario-card {grid-template-columns: repeat(2, 1fr);}
        .bc-scenario-card > div {border-right: 0; border-bottom: 1px solid rgba(216,166,58,.12);}
        .bc-desk-strip {grid-template-columns: repeat(2, minmax(0, 1fr));}
    }
    </style>
    """,
    unsafe_allow_html=True,
)
st.markdown(
    f"""
    <div class="bc-hero">
      <div class="bc-mark" aria-label="Boussole Crypto">
        <svg viewBox="0 0 64 64" role="img" aria-hidden="true">
          <circle cx="32" cy="32" r="27" fill="#111319" stroke="#d8a63a" stroke-width="2"/>
          <circle cx="32" cy="32" r="20" fill="none" stroke="rgba(240,202,115,.35)" stroke-width="1"/>
          <path d="M32 7 L36 27 L57 32 L36 36 L32 57 L28 36 L7 32 L28 28 Z" fill="#d8a63a"/>
          <path d="M13 39 C19 34 23 34 29 39" fill="none" stroke="#ef5964" stroke-width="3" stroke-linecap="round"/>
          <path d="M35 39 C42 34 47 31 53 24" fill="none" stroke="#2dcc75" stroke-width="3" stroke-linecap="round"/>
          <circle cx="32" cy="32" r="8" fill="#17191f" stroke="#f0ca73" stroke-width="1.5"/>
          <text x="32" y="36" text-anchor="middle" fill="#f0ca73" font-size="11" font-weight="900">₿</text>
        </svg>
      </div>
      <div>
        <p class="bc-eyebrow">BOUSSOLE CRYPTO</p>
        <h1>{'Market Compass · BTC / ETH' if PUBLIC_STUDENT_MODE else 'Lecture du marché · BTC / ETH'}</h1>
        <p class="bc-subtitle">Comprendre le marché. Lire la liquidité. Décider avec méthode.</p>
      </div>
      <div class="bc-pill">{'ESPACE ÉLÈVE' if PUBLIC_STUDENT_MODE else 'DESK LOCAL'}</div>
    </div>
    <div class="bc-route">
      <span><i>01</i>CONTEXTE</span><span><i>02</i>STRUCTURE</span><span><i>03</i>LIQUIDITÉ</span><span><i>04</i>CONFIRMATION</span><span><i>05</i>RISQUE</span><span><i>06</i>EXÉCUTION</span>
    </div>
    """,
    unsafe_allow_html=True,
)
reading_mode = st.segmented_control(
    "Niveau de lecture",
    ["Essentiel", "Détaillé"],
    default="Essentiel",
    format_func=(
        (lambda value: "Comprendre en 2 minutes" if value == "Essentiel" else "Approfondir")
        if PUBLIC_STUDENT_MODE
        else None
    ),
    help="Essentiel traduit les indicateurs en langage courant. Détaillé conserve toutes les mesures techniques.",
)


def read_latest_predictions(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    with sqlite3.connect(path) as connection:
        return pd.read_sql_query(
            "SELECT * FROM predictions ORDER BY prediction_timestamp DESC LIMIT 2000",
            connection,
        )


def _read_feature_file(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    for column in ("prediction_time", "feature_available_time"):
        if column in frame:
            frame[column] = pd.to_datetime(frame[column], utc=True, format="mixed", errors="coerce")
    return frame.dropna(subset=["prediction_time"]) if "prediction_time" in frame else frame


def _fill_causal_relative_return(frame: pd.DataFrame, *, tolerance_minutes: int = 30) -> pd.DataFrame:
    """Recover a missing 24 h ETH/BTC move from already published point-in-time rows.

    A hosted restart can create a current live row after a long application sleep.
    The immutable snapshot still contains the observation around ``t - 24 h``;
    this helper joins only backwards and refuses targets outside the tolerance.
    """

    if frame.empty or not {"asset", "prediction_time", "eth_btc"}.issubset(frame.columns):
        return frame
    result = frame.sort_values(["asset", "prediction_time"]).copy()
    if "eth_btc_return_24h" not in result:
        result["eth_btc_return_24h"] = float("nan")
    tolerance = pd.Timedelta(minutes=int(tolerance_minutes))
    for asset, indexes in result.groupby("asset", sort=False).groups.items():
        group = result.loc[indexes, ["prediction_time", "eth_btc", "eth_btc_return_24h"]].sort_values(
            "prediction_time"
        )
        known = group.dropna(subset=["eth_btc"])
        if known.empty:
            continue
        for index, row in group[group["eth_btc_return_24h"].isna() & group["eth_btc"].notna()].iterrows():
            target = pd.Timestamp(row["prediction_time"]) - pd.Timedelta(hours=24)
            candidates = known[
                (known["prediction_time"] <= target)
                & (known["prediction_time"] >= target - tolerance)
            ]
            if candidates.empty:
                continue
            previous = float(candidates.iloc[-1]["eth_btc"])
            if previous > 0:
                result.at[index, "eth_btc_return_24h"] = float(row["eth_btc"]) / previous - 1.0
    return result.sort_values(["asset", "prediction_time"]).reset_index(drop=True)


def read_latest_features(root: Path) -> tuple[pd.DataFrame, str | None]:
    """Read the immutable history and extend it with the current hosted cache.

    The former implementation selected the newest *file*.  On Streamlit Cloud
    that file is deliberately small, so it erased the historical context needed
    by relative strength, rolling scores and the scenario trajectory.  We now
    select one immutable snapshot plus one live extension and de-duplicate rows.
    """

    stable_candidates = list(root.glob("*/features.csv.gz"))
    live_candidates = list((root.parent / "live").glob("*/features.csv.gz"))
    if not stable_candidates and not live_candidates:
        return pd.DataFrame(), None
    selected: list[Path] = []
    if stable_candidates:
        selected.append(max(stable_candidates, key=lambda path: path.stat().st_mtime))
    if live_candidates:
        selected.append(max(live_candidates, key=lambda path: path.stat().st_mtime))
    blocks = [_read_feature_file(path) for path in selected]
    frame = pd.concat(blocks, ignore_index=True, sort=False)
    if {"asset", "prediction_time"}.issubset(frame.columns):
        frame = frame.sort_values("prediction_time").drop_duplicates(
            ["asset", "prediction_time"], keep="last"
        )
    frame = _fill_causal_relative_return(frame)
    version = " + ".join(path.parent.name for path in selected)
    return frame.reset_index(drop=True), version


def read_research_summary(root: Path) -> dict[str, object] | None:
    pointer_path = root / "latest.json"
    if not pointer_path.exists():
        return None
    try:
        pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
        summary_path = Path(pointer["summary_path"])
        if not summary_path.is_absolute():
            summary_path = root.parents[1] / summary_path
        if not summary_path.exists():
            summary_path = pointer_path.parent / pointer["research_version"] / "summary.json"
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        freeze_path = summary_path.parent / "freeze_manifest.json"
        summary["_freeze_manifest"] = (
            json.loads(freeze_path.read_text(encoding="utf-8")) if freeze_path.exists() else {}
        )
        return summary
    except (OSError, KeyError, json.JSONDecodeError):
        return None


def read_macro_observations(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    store = NormalizedStore(path)
    blocks = [store.query(data_family=family) for family in ("MACRO", "FED", "RATES")]
    blocks = [block for block in blocks if not block.empty]
    return pd.concat(blocks, ignore_index=True) if blocks else pd.DataFrame()


def _fmt(value: object, suffix: str = "", digits: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    return f"{number:.{digits}f}{suffix}" if pd.notna(number) else "—"


def _thesis_confluence_label(value: object) -> str:
    """Translate the non-probabilistic confluence score into a classroom label."""

    try:
        conviction = float(value)
    except (TypeError, ValueError):
        return "EN CONSTRUCTION"
    if conviction >= 70:
        return "FORTE"
    if conviction >= 40:
        return "AFFIRMÉE"
    return "PRUDENTE"


def _macro_observation_label(value: object, *, stale_after_days: int) -> str:
    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        age_days = max(0, int((pd.Timestamp.now(tz="UTC") - timestamp).total_seconds() // 86_400))
        suffix = " · ANCIENNE" if age_days > stale_after_days else ""
        return f"{timestamp.date().isoformat()}{suffix}"
    except (TypeError, ValueError):
        return "DATE INDISPONIBLE"


def _next_macro_check_label() -> str:
    if _is_hosted_runtime(data_dir()):
        from crypto_quant_engine.dashboard.hosted_refresh import read_hosted_refresh_status

        last = read_hosted_refresh_status(data_dir()).get("macro_updated_at")
        if last:
            next_check = pd.Timestamp(last) + pd.Timedelta(hours=1)
            if next_check > pd.Timestamp.now(tz="UTC"):
                return _freshness_time_label(next_check)
        return "Au prochain passage · contrôle horaire"
    now = pd.Timestamp.now(tz="Europe/Paris")
    today_check = now.normalize() + pd.Timedelta(8, unit="h")
    next_check = today_check if now < today_check else today_check + pd.Timedelta(1, unit="D")
    return next_check.strftime("%d/%m/%Y après 08:00 Paris")


def _utc_label(value: object) -> str:
    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        return timestamp.tz_convert("UTC").strftime("%d/%m/%Y %H:%M UTC")
    except (TypeError, ValueError):
        return "—"


def _freshness_time_label(value: object) -> str:
    """Show the classroom's local clock while retaining the UTC audit time."""

    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        utc = timestamp.tz_convert("UTC")
        paris = utc.tz_convert("Europe/Paris")
        return f"{paris.strftime('%d/%m/%Y %H:%M')} Paris ({utc.strftime('%H:%M UTC')})"
    except (TypeError, ValueError):
        return "—"


def _is_hosted_runtime(root: Path) -> bool:
    configured = Path(os.getenv("CQE_HOSTED_RUNTIME_DIR", ".runtime_data"))
    return PUBLIC_STUDENT_MODE and root.name == configured.name


@st.fragment(run_every="30s")
def hosted_data_watchdog() -> None:
    """Refresh the hosted cache and rerun the full page when a new feature set lands."""

    root = data_dir()
    if not _is_hosted_runtime(root):
        return
    try:
        from crypto_quant_engine.dashboard.hosted_refresh import (
            read_hosted_refresh_status,
            schedule_hosted_refresh,
        )

        schedule_hosted_refresh(root)
        revision = read_hosted_refresh_status(root).get("feature_revision")
    except Exception:
        return
    if not revision:
        return
    state_key = "_cqe_hosted_feature_revision"
    previous = st.session_state.get(state_key)
    st.session_state[state_key] = revision
    # The first hosted refresh may create ``live/features.csv.gz`` from a
    # snapshot-only seed.  In that case there is no previous revision to
    # compare with, but the full page still needs one rerun to load it.
    if previous is None or previous != revision:
        st.rerun()


def show_data_freshness(features: pd.DataFrame) -> None:
    """Expose whether the classroom view is live, catching up, or on its fallback snapshot."""

    if features.empty or "prediction_time" not in features:
        state_class, state_label, timestamp_label = "stale", "SNAPSHOT DE SECOURS", "aucun relevé récent"
    else:
        latest = pd.to_datetime(features["prediction_time"], utc=True, errors="coerce").max()
        if pd.isna(latest):
            state_class, state_label, timestamp_label = "stale", "SNAPSHOT DE SECOURS", "horodatage indisponible"
        else:
            age_minutes = max(0.0, (pd.Timestamp.now(tz="UTC") - latest).total_seconds() / 60.0)
            if age_minutes <= 30:
                state_class, state_label = "fresh", "FLUX ACTIF"
            elif age_minutes <= 120:
                state_class, state_label = "catchup", "RATTRAPAGE EN COURS"
            else:
                state_class, state_label = "stale", "SNAPSHOT DE SECOURS"
            timestamp_label = _freshness_time_label(latest)
    source_label = "FLUX HÉBERGÉ" if _is_hosted_runtime(data_dir()) else "FLUX LOCAL"
    st.markdown(
        f"""
        <div class="bc-livebar {state_class}">
          <strong><span class="bc-live-dot"></span>{source_label} · {state_label}</strong>
          <span>Cadence 15 min · dernier relevé {timestamp_label}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def show_macro_context(context: dict[str, object]) -> None:
    st.subheader("Économie mondiale et taux : Fed, BCE et Banque du Japon")
    if not context.get("available"):
        st.warning("Les sources économiques officielles n'ont pas encore livré un relevé exploitable.")
        return
    current = context.get("current", {})
    combined = context.get("combined_signal")
    macro_direction = (
        "Plutôt favorable" if combined is not None and float(combined) >= 0.20
        else "Plutôt défavorable" if combined is not None and float(combined) <= -0.20
        else "Partagé / neutre"
    )
    left, middle, right = st.columns(3)
    left.metric(
        "Contexte macro actuel",
        str(context.get("combined_label", "—")),
        macro_direction,
        delta_color="off",
    )
    cme = context.get("cme") or {}
    middle.metric(
        "Fed · prochaine réunion selon CME FedWatch",
        str(cme.get("meeting_date") or "INDISPONIBLE"),
        f"données CME au {_utc_label(cme.get('event_time'))}" if cme else "source non disponible",
        delta_color="off",
    )
    fed = context.get("fed") or {}
    target_low, target_high = fed.get("target_lower_pct"), fed.get("target_upper_pct")
    right.metric(
        "Cible Fed constatée",
        f"{target_low:.2f}–{target_high:.2f}%" if target_low is not None and target_high is not None else "—",
        f"réunion {fed.get('meeting_date', '—')}",
        delta_color="off",
    )

    regions = context.get("regions") or {}
    dimension_freshness = {"growth": 160, "inflation": 70, "liquidity": 70, "policy": 70}

    def macro_cell(state: dict[str, object], dimension: str) -> str:
        label = state.get(f"{dimension}_label", "—")
        value = _fmt(state.get(f"{dimension}_value_pct"), "%")
        observed = _macro_observation_label(
            state.get(f"{dimension}_observation_time"),
            stale_after_days=dimension_freshness[dimension],
        )
        return f"{label} · {value} · obs. {observed}"

    macro_rows = pd.DataFrame(
        [
            {
                "Zone": state.get("region_label", region),
                "Banque centrale": state.get("central_bank", "—"),
                "Croissance": macro_cell(state, "growth"),
                "Inflation": macro_cell(state, "inflation"),
                "Monnaie / liquidité": macro_cell(state, "liquidity"),
                "Politique de taux": macro_cell(state, "policy"),
            }
            for region, state in regions.items()
        ]
    )
    if macro_rows.empty:
        macro_rows = pd.DataFrame(
            [
                {"Zone": "États-Unis", "Banque centrale": "Réserve fédérale (Fed)", "Croissance": current.get("growth_label"), "Inflation": current.get("inflation_label"), "Monnaie / liquidité": current.get("liquidity_label"), "Politique de taux": current.get("policy_label")}
            ]
        )
    st.dataframe(macro_rows, hide_index=True, width="stretch")
    show_inflation_freshness(context)
    st.caption(
        "Chaque pourcentage est rattaché à une mesure et à une période précises. "
        "ANCIENNE signifie que la source n'a pas publié de point assez récent pour la cadence normale de cette série."
    )

    evidence_rows: list[dict[str, object]] = []
    dimension_names = {
        "growth": "Croissance",
        "inflation": "Inflation",
        "liquidity": "Monnaie / liquidité",
        "policy": "Politique de taux",
    }
    for region, state in regions.items():
        for dimension, dimension_name in dimension_names.items():
            evidence_rows.append(
                {
                    "Zone": state.get("region_label", region),
                    "Dimension": dimension_name,
                    "Indicateur exact": state.get(f"{dimension}_measure", "—"),
                    "Série": state.get(f"{dimension}_series_id", "—"),
                    "Valeur calculée": _fmt(state.get(f"{dimension}_value_pct"), "%"),
                    "Période observée": _macro_observation_label(
                        state.get(f"{dimension}_observation_time"),
                        stale_after_days=dimension_freshness[dimension],
                    ),
                    "Prochain contrôle": _next_macro_check_label(),
                    "Source officielle": state.get(f"{dimension}_source_url"),
                    "Dernière vérification": _utc_label(state.get("inflation_checked_time")) if dimension == "inflation" else "—",
                }
            )
    if evidence_rows:
        with st.expander("Vérifier chaque chiffre : indicateur, période et source officielle"):
            st.dataframe(
                pd.DataFrame(evidence_rows),
                hide_index=True,
                width="stretch",
                column_config={
                    "Source officielle": st.column_config.LinkColumn(
                        "Source officielle", display_text="Ouvrir la source"
                    )
                },
            )
            st.caption(
                "Les séries FRED affichées sont les révisions courantes reçues par l'application : elles sont adaptées "
                "au contexte présent, mais exclues des backtests historiques. Les statistiques macro peuvent être révisées."
                " Le prochain contrôle est une relance de collecte, pas une promesse de nouvelle publication par l'autorité."
            )

    if cme:
        c1, c2, c3 = st.columns(3)
        c1.metric("Fed via CME · baisse", _fmt(100 * cme.get("ease_probability"), "%", 1) if cme.get("ease_probability") is not None else "—")
        c2.metric("Fed via CME · statu quo", _fmt(100 * cme.get("unchanged_probability"), "%", 1) if cme.get("unchanged_probability") is not None else "—")
        c3.metric("Fed via CME · hausse", _fmt(100 * cme.get("hike_probability"), "%", 1) if cme.get("hike_probability") is not None else "—")
        targets = cme.get("target_probabilities")
        if isinstance(targets, list):
            target_table = pd.DataFrame(targets)
            if not target_table.empty:
                target_table = target_table[target_table["probability"] > 0].copy()
                target_table["Fourchette cible"] = target_table.apply(lambda row: f"{int(row['lower_bps'])}–{int(row['upper_bps'])} pb", axis=1)
                target_table["Probabilité CME"] = target_table["probability"].map(lambda value: f"{100 * value:.1f}%")
                st.dataframe(target_table[["Fourchette cible", "Probabilité CME"]], hide_index=True, width="stretch")
        st.caption("Ces probabilités concernent uniquement la prochaine décision de la Réserve fédérale américaine. Elles sont implicites dans les futures 30-Day Fed Funds · source : CME FedWatch.")

    history = context.get("history")
    if isinstance(history, pd.DataFrame) and not history.empty:
        with st.expander("Historique des régimes macro / Fed"):
            display = history.tail(36).copy()
            display["date"] = pd.to_datetime(display["date"], utc=True).dt.date
            st.dataframe(
                display[["date", "growth_label", "inflation_label", "liquidity_label", "policy_label"]].rename(
                    columns={"date": "Date", "growth_label": "Croissance", "inflation_label": "Inflation", "liquidity_label": "Liquidité", "policy_label": "Fed"}
                ),
                hide_index=True,
                width="stretch",
            )
    if fed:
        with st.expander("Réunions et comptes rendus de la Fed"):
            st.write(f"Dernière réunion observée : **{fed.get('meeting_date', '—')}** · minutes publiées : **{fed.get('minutes_release_date', '—')}**")
            if fed.get("statement_url"):
                st.markdown(f"[Communiqué officiel Fed]({fed['statement_url']})")
            if fed.get("minutes_url"):
                st.markdown(f"[Compte rendu officiel Fed]({fed['minutes_url']})")
            st.caption("Les comptages de langage sont exploratoires ; ils ne deviennent jamais une probabilité sans validation hors échantillon.")
    st.caption("Sources officielles Fed/BEA/BLS pour les États-Unis, BCE/Eurostat pour la zone euro, BoJ/Statistiques du Japon pour le Japon. Contrôle économique horaire sur le Cloud ; les révisions connues aujourd'hui restent séparées des tests historiques.")


def show_inflation_freshness(context: dict[str, object]) -> None:
    regions = context.get("regions") or {}
    rows, details = [], []
    for region, state in regions.items():
        period = state.get("inflation_observation_time")
        period_label = pd.Timestamp(period).strftime("%m/%Y") if period is not None and not pd.isna(period) else "Indisponible"
        status = state.get("inflation_status")
        status_label = "Estimation flash · provisoire" if status == "FLASH_ESTIMATE" else "Publication provisoire" if status == "PROVISIONAL" else "Publication observée"
        if pd.isna(state.get("inflation_value_pct")):
            status_label = "Indisponible"
        zone = state.get("region_label", region)
        rows.append({"Zone": zone, "Indicateur": state.get("inflation_measure"), "Inflation annuelle": _fmt(state.get("inflation_value_pct"), "%", 1), "Période": period_label, "Statut": status_label})
        publication = state.get("inflation_publication_date")
        if pd.isna(publication):
            publication = state.get("inflation_publication_time")
        source_updated = state.get("inflation_source_updated_time")
        details.append({
            "Zone": zone,
            "Indicateur exact": state.get("inflation_measure"),
            "Date de publication": str(publication) if pd.notna(publication) else "Non fournie par cette source",
            "Mise à jour de la source": str(source_updated) if pd.notna(source_updated) else "—",
            "Vérification par l’application": _utc_label(state.get("inflation_checked_time")),
            "Source": state.get("inflation_source_url"),
            "Calendrier": state.get("inflation_calendar_url"),
        })
    if not rows:
        return
    st.markdown("**Inflation · dernières périodes publiées**")
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    st.caption("Le mois observé n’est pas la date de téléchargement. Août remplace juillet dès publication pour l’indicateur suivi ; une estimation flash reste identifiée comme provisoire. Les indices PCE, IPCH et IPC ne sont pas interchangeables.")
    with st.expander("Inflation : sources, publications et renouvellement"):
        st.dataframe(pd.DataFrame(details), hide_index=True, width="stretch", column_config={
            "Source": st.column_config.LinkColumn("Source", display_text="Source officielle"),
            "Calendrier": st.column_config.LinkColumn("Calendrier", display_text="Calendrier officiel"),
        })
        st.caption("Prochain contrôle de collecte : " + _next_macro_check_label() + ". Ce contrôle n’est pas une promesse de nouvelle publication statistique.")


def show_macro_plain(context: dict[str, object]) -> None:
    st.subheader("Taux et économie, en clair")
    reading = simple_macro_reading(context)
    cme = context.get("cme") or {}
    left, right = st.columns(2)
    left.metric("Effet possible sur les actifs risqués", str(reading["label"]))
    right.metric("Prochaine décision de taux suivie", str(cme.get("meeting_date") or "Date indisponible"))
    st.write(str(reading["explanation"]))
    st.info(str(reading["rate_path"]))
    regions = context.get("regions") or {}
    available_dimensions = sum(
        state.get(name) not in (None, "INDISPONIBLE")
        for state in regions.values()
        for name in ("growth_label", "inflation_label", "liquidity_label", "policy_label")
    )
    st.caption(f"Couverture économique actuelle : {available_dimensions}/{max(4, 4 * len(regions))} dimensions nommées et sourcées.")
    show_inflation_freshness(context)


def _plain_family_table(features: dict[str, object]) -> pd.DataFrame:
    table = directional_evidence_table(features).copy()
    table["Couche"] = table["Couche"].replace(
        {
            "Spot": "Achats et ventes immédiats",
            "Perpétuels": "Contrats avec effet de levier",
            "Options": "Marché des options",
            "Macro / taux": "Économie et taux",
        }
    )
    table["Lecture"] = table["Lecture"].replace(
        {
            "↑ HAUSSIER": "Plutôt favorable à la hausse",
            "↓ BAISSIER": "Plutôt favorable à la baisse",
            "↔ NEUTRE": "Sans direction nette",
            "— INDISPONIBLE": "Données insuffisantes",
        }
    )
    return table.rename(
        columns={"Couche": "Type de données", "Lecture": "Ce qu’il indique", "Couverture": "Mesures présentes"}
    )[["Type de données", "Ce qu’il indique", "Mesures présentes"]]


def _decision_matrix_display(snapshot: dict[str, object]) -> pd.DataFrame:
    matrix = snapshot.get("multi_horizon")
    if not isinstance(matrix, pd.DataFrame) or matrix.empty:
        return pd.DataFrame()
    display = matrix.copy()
    for column in ("Zone dominante", "Invalidation"):
        display[column] = display[column].map(
            lambda value: "—" if pd.isna(value) else f"${float(value):,.0f}"
        )
    display["Amplitude implicite"] = display["Amplitude implicite"].map(
        lambda value: "—" if pd.isna(value) else f"{float(value):.2f} %"
    )
    display.loc[display["Biais"] == "CONSOLIDATION", "Invalidation"] = "Sortie du couloir"
    return display


def _decision_change_display(snapshot: dict[str, object]) -> pd.DataFrame:
    changes = snapshot.get("changes") or {}
    rows = changes.get("rows")
    if not isinstance(rows, pd.DataFrame) or rows.empty:
        return pd.DataFrame()
    display = rows.copy()

    def format_current(row: pd.Series) -> str:
        value, unit = row["Maintenant"], row["Unité"]
        if value is None or (not isinstance(value, str) and pd.isna(value)):
            return "—"
        if unit == "price_pct":
            return f"${float(value):,.2f}"
        if unit == "points":
            return f"{float(value):.1f} / 100"
        if unit == "percentage_points":
            return f"{float(value):.2f} %"
        return str(value)

    def format_delta(row: pd.Series) -> str:
        value, unit = row["Évolution"], row["Unité"]
        if value is None or (not isinstance(value, str) and pd.isna(value)):
            return "—"
        if unit == "price_pct":
            return f"{float(value):+.2f} %"
        if unit == "points":
            return f"{float(value):+.1f} point(s)"
        if unit == "percentage_points":
            return f"{float(value):+.2f} pt(s)"
        return str(value)

    display["Maintenant"] = display.apply(format_current, axis=1)
    display["Depuis le relevé précédent"] = display.apply(format_delta, axis=1)
    return display[["Mesure", "Maintenant", "Depuis le relevé précédent"]]


def show_decision_brief(
    snapshot: dict[str, object],
    research_summary: dict[str, object] | None,
    macro_context: dict[str, object],
) -> None:
    """Render the shared, non-probabilistic point-in-time decision summary."""

    if not snapshot.get("available"):
        st.info("La synthèse sera disponible après le prochain relevé exploitable.")
        return
    latest = snapshot["latest"]
    thesis = snapshot["thesis_7d"]
    votes = snapshot["votes"]
    quality = snapshot["quality"]
    price = float(latest["spot_price"])
    bias = str(thesis.get("bias", "INDISPONIBLE"))
    direction_class = "up" if "HAUSSI" in bias else "down" if "BAISSI" in bias else "flat"
    target = f"${float(thesis['dominant_target']):,.0f}" if thesis.get("available") else "EN CALCUL"
    invalidation = f"${float(thesis['invalidation_level']):,.0f}" if thesis.get("available") else "—"
    if thesis.get("available") and bias == "CONSOLIDATION":
        invalidation = f"hors ${float(thesis['support']):,.0f}–${float(thesis['resistance']):,.0f}"
    vote_text = f"{votes['bullish']} H · {votes['neutral']} N · {votes['bearish']} B"
    coverage_text = f"{votes['available']}/{votes['total']} familles"
    quality_text = f"{float(quality['score']):.0f}/100 · {quality['label']}"
    measure_text = f"{quality['present_measures']}/{quality['expected_measures']} mesures"
    st.markdown(
        f"""
        <div class="bc-desk-strip">
          <div><span class="bc-desk-label">PRIX OBSERVÉ</span><span class="bc-desk-value">${price:,.2f}</span></div>
          <div><span class="bc-desk-label">BIAIS ACTIF · 7 JOURS</span><span class="bc-desk-value {direction_class}">{escape(bias)}</span></div>
          <div><span class="bc-desk-label">VOTES PAR FAMILLE</span><span class="bc-desk-value">{escape(vote_text)}</span><span class="bc-desk-label">{escape(coverage_text)}</span></div>
          <div><span class="bc-desk-label">QUALITÉ OPÉRATIONNELLE</span><span class="bc-desk-value">{escape(quality_text)}</span><span class="bc-desk-label">{escape(measure_text)}</span></div>
          <div><span class="bc-desk-label">CIBLE / INVALIDATION</span><span class="bc-desk-value">{escape(target)} / {escape(invalidation)}</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.caption(
        "H = haussier, N = neutre, B = baissier. La qualité mesure la couverture et la fraîcheur des données ; "
        "ce n’est ni une probabilité de réussite ni une note de conviction."
    )
    if thesis.get("available"):
        st.success(f"**Lecture de travail :** {thesis['summary']}")
        if thesis.get("drivers"):
            st.write("**Moteurs dominants :** " + " · ".join(str(item) for item in thesis["drivers"]))

    st.markdown("**Cadre multi-horizons**")
    matrix = _decision_matrix_display(snapshot)
    if not matrix.empty:
        st.dataframe(matrix, hide_index=True, width="stretch")
    st.caption(
        "Un même moteur directionnel point-in-time est projeté sur quatre budgets de temps et de risque. "
        "Ces lignes ne sont pas quatre probabilités prédictives indépendantes."
    )

    with st.expander("Ce qui a changé depuis le relevé précédent"):
        changes = snapshot.get("changes") or {}
        display = _decision_change_display(snapshot)
        if display.empty:
            st.info("Deux relevés exploitables sont nécessaires pour mesurer une évolution.")
        else:
            st.caption(
                f"Comparaison causale : {_utc_label(changes.get('previous_time'))} → "
                f"{_utc_label(changes.get('current_time'))}."
            )
            st.dataframe(display, hide_index=True, width="stretch")
            st.caption("Comparaison du prix et de la volatilité effectivement archivés ; aucune macro actuelle n’est réinjectée dans le passé.")

    with st.expander("Risques et conditions d’invalidation"):
        evidence = snapshot.get("evidence")
        opposing: list[str] = []
        if isinstance(evidence, pd.DataFrame) and not evidence.empty:
            opposing_label = "↓ BAISSIER" if "HAUSSI" in bias else "↑ HAUSSIER" if "BAISSI" in bias else None
            if opposing_label:
                opposing = evidence.loc[evidence["Lecture"] == opposing_label, "Couche"].astype(str).tolist()
        if thesis.get("available"):
            st.write(
                f"**Condition d’invalidation à 7 jours :** {thesis['invalidation']}."
            )
        opposition_text = " · ".join(opposing) if opposing else "aucune parmi les familles renseignées"
        if bias == "CONSOLIDATION":
            opposition_text = "pas de direction dominante ; surveiller les deux bornes du couloir"
        st.write("**Familles actuellement opposées :** " + opposition_text)
        meeting_date = str((macro_context.get("cme") or {}).get("meeting_date") or "date non disponible")
        st.write(f"**Prochaine échéance Fed suivie :** {meeting_date}.")
        if not quality.get("fresh"):
            st.warning("Le dernier relevé dépasse 30 minutes : le biais reste visible, mais sa fraîcheur est explicitement dégradée.")

    with st.expander("Comment lire les chiffres sans les confondre"):
        reference = _validated_four_hour_reference(research_summary, str(latest.get("asset", "")))
        method_rows = [
            {
                "Mesure": "Fréquence historique validée",
                "Ce qu’elle mesure": f"Taux de base 4 h : {100 * float(reference['probability']):.1f} %" if reference else "Aucune fréquence publiable",
                "Ce qu’elle ne mesure pas": "La probabilité conditionnelle du scénario actuel",
            },
            {
                "Mesure": "Poids relatif de thèse",
                "Ce qu’elle mesure": "Le classement des scénarios par confluence actuelle",
                "Ce qu’elle ne mesure pas": "Une probabilité calibrée de réussite",
            },
            {
                "Mesure": "Amplitude implicite",
                "Ce qu’elle mesure": "La largeur de mouvement intégrée dans les options",
                "Ce qu’elle ne mesure pas": "La direction future du prix",
            },
        ]
        st.dataframe(pd.DataFrame(method_rows), hide_index=True, width="stretch")
        st.caption("Qualité opérationnelle = 80 % couverture des mesures attendues + 20 % fraîcheur du relevé.")


def show_beginner_overview(
    rows: pd.DataFrame,
    research_summary: dict[str, object] | None,
    macro_context: dict[str, object],
    decision_snapshot: dict[str, object],
) -> None:
    latest = rows.sort_values("prediction_time").iloc[-1]
    latest_dict = decision_snapshot.get("latest", {**latest.to_dict(), **macro_feature_overlay(macro_context)})
    ranges = simple_market_ranges(latest_dict)
    gamma = gamma_exposure_summary(latest_dict)
    thesis = decision_snapshot.get("thesis_7d") or directional_thesis(latest_dict, rows, horizon=7)
    thesis_scenarios = directional_scenario_table(latest_dict, rows, horizon=7)
    four_hour_thesis = directional_thesis(latest_dict, rows, horizon=4 / 24)
    four_hour_reference = _validated_four_hour_reference(
        research_summary, str(latest.get("asset", ""))
    )

    st.subheader("L’essentiel maintenant")
    show_decision_brief(decision_snapshot, research_summary, macro_context)
    if not thesis_scenarios.empty:
        scenario_display = thesis_scenarios.copy()
        scenario_display = scenario_display.rename(columns={"Poids de thèse": "Poids relatif (non probabiliste)"})
        scenario_display["Poids relatif (non probabiliste)"] = scenario_display["Poids relatif (non probabiliste)"].map(lambda value: f"{value:.1f} %")
        st.dataframe(scenario_display, hide_index=True, width="stretch")
        st.caption("Les poids classent les scénarios de travail selon la confluence actuelle ; ils ne sont pas des probabilités calibrées.")

    st.subheader("Lecture courte · horizon 4 heures")
    short_bias, short_target, short_history = st.columns(3)
    short_bias.metric("Biais tactique 4 h", str(four_hour_thesis.get("bias", "EN CALCUL")))
    short_target.metric(
        "Zone dominante 4 h",
        f"${float(four_hour_thesis['dominant_target']):,.0f}"
        if four_hour_thesis.get("available")
        else "EN CALCUL",
        (
            f"bascule ${float(four_hour_thesis['invalidation_level']):,.0f}"
            if four_hour_thesis.get("available")
            else "surface d’options attendue"
        ),
        delta_color="off",
    )
    if four_hour_reference:
        short_history.metric(
            "Fréquence historique de hausse · 4 h",
            f"{100 * float(four_hour_reference['probability']):.1f} %",
            f"N effectif {float(four_hour_reference['effective_sample']):,.0f}",
            delta_color="off",
        )
    else:
        short_history.metric("Fréquence historique · 4 h", "EN CONSTRUCTION")
    st.caption(
        "Le pourcentage 4 h est le taux historique inconditionnel validé sur le holdout ; "
        "le biais et les niveaux 4 h viennent de la confluence de marché actuelle."
    )

    show_scenario_trajectory(
        rows,
        key_suffix=f"beginner_{str(latest.get('asset', '')).lower()}",
        current_features=latest_dict,
    )

    st.subheader("Amplitude de marché intégrée dans les options")
    if ranges.empty:
        st.warning("Le marché des options ne fournit pas encore une fourchette assez fiable.")
    else:
        st.dataframe(ranges, hide_index=True, width="stretch")
        st.caption(
            "La zone habituelle couvre environ 68 % d’une distribution théorique issue des options. "
            "Elle mesure l’amplitude attendue, pas la direction."
        )

    st.subheader("Pourquoi cette direction ?")
    st.dataframe(_plain_family_table(latest_dict), hide_index=True, width="stretch")
    show_liquidations(latest_dict)

    st.subheader("Options : le mouvement peut-il être freiné ou amplifié ?")
    if gamma.get("available"):
        strike = gamma.get("dominant_strike")
        strike_text = f"${float(strike):,.0f}" if strike is not None else "non identifié"
        st.write(
            f"La sensibilité des options est **{str(gamma['regime']).lower()}**. Le prix d’exercice le plus concentré "
            f"se situe autour de **{strike_text}**. Près de cette zone, le marché peut se stabiliser ou accélérer selon les flux."
        )
        st.caption(
            "La position réelle des intermédiaires n’est pas publique : le tableau de bord ne prétend donc pas savoir "
            "s’ils sont acheteurs ou vendeurs de gamma."
        )
    else:
        st.info("Pas assez de données d’options pour décrire la forme probable du mouvement.")

    history = data_history_table(rows, research_summary, str(latest["asset"]), macro_context)
    if PUBLIC_STUDENT_MODE:
        with st.expander("Fraîcheur et profondeur des sources"):
            st.dataframe(history, hide_index=True, width="stretch")
    else:
        st.subheader("Historique réellement disponible")
        st.dataframe(history, hide_index=True, width="stretch")
        st.subheader("Preuves de confiance : état précis et prochain seuil")
        st.dataframe(
            confidence_proof_table(rows, research_summary, str(latest["asset"]), macro_context),
            hide_index=True,
            width="stretch",
        )

    with st.expander("Petit dictionnaire sans acronymes"):
        for term, explanation in BEGINNER_GLOSSARY.items():
            st.markdown(f"**{term}** — {explanation}")
    st.caption(f"Dernière mise à jour utilisée : {_utc_label(latest.get('prediction_time'))}")


def show_simple_validation(summary: dict[str, object] | None, asset: str) -> None:
    st.subheader("Ce que l’historique permet vraiment d’affirmer")
    reference = _validated_four_hour_reference(summary, asset)
    left, middle, right = st.columns(3)
    if reference:
        left.metric("Socle prix/volume", "Validé")
        middle.metric("Fréquence moyenne de hausse · 4 h", f"{100 * float(reference['probability']):.1f}%")
        right.metric("Signal conditionnel supérieur", "Non démontré")
        st.info(
            "Le recul historique est suffisant pour mesurer une fréquence moyenne. En revanche, aucun modèle plus complexe "
            "n’a encore prouvé qu’il prédit mieux que cette moyenne sur des données jamais vues."
        )
    else:
        left.metric("Socle historique", "En attente")
        middle.metric("Probabilité publiable", "Aucune")
        right.metric("Protection statistique", "Active")
        st.warning("Le tableau de bord conserve les scénarios descriptifs, mais ne publie pas de probabilité de modèle.")


def _readable_feature_value(key: str, value: object) -> str:
    if value is None or (not isinstance(value, (list, dict)) and pd.isna(value)):
        return "NON REÇU"
    if isinstance(value, bool):
        return "OUI" if value else "NON"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if "information_age_seconds" in key:
        return f"{number / 60:.1f} min" if number < 7_200 else f"{number / 3_600:.1f} h"
    if key.endswith("_usd") or "notional_usd" in key:
        return _money_compact(number)
    if key in {"cme_basis_fraction", "cme_basis_annualized", "oi_weighted_basis", "oi_weighted_funding", "cex_oi_weighted_basis", "cex_oi_weighted_funding", "dex_oi_weighted_basis", "dex_oi_weighted_funding"}:
        return f"{100 * number:.3f} %"
    if key in {"btc_dominance", "eth_dominance"}:
        return f"{100 * number:.2f} %"
    return f"{number:,.4f}"


def show_feature_sections(features: dict[str, object]) -> None:
    sections: list[tuple[str, str, dict[str, str]]] = [
        (
            "Marché au comptant",
            "Achats/ventes immédiats et carnet d’ordres.",
            {
                "spot_cvd_aggregate": "Pression acheteuse nette",
                "spot_volume": "Volume observé",
                "absorption_score": "Absorption des ordres",
                "spot_order_book_imbalance": "Déséquilibre du carnet",
            },
        ),
        (
            "Contrats perpétuels",
            "Positionnement à effet de levier, séparé des liquidations forcées. La pression acheteuse nette "
            "n'est publiée que lorsque l'intervalle de transactions est complet et dédupliqué.",
            {
                "open_interest_notional_usd": "Positions ouvertes",
                "delta_open_interest_notional_usd": "Variation des positions ouvertes",
                "oi_weighted_funding": "Coût du financement",
                "oi_weighted_basis": "Écart perpétuel / spot",
                "perp_cvd_aggregate": "Pression acheteuse nette",
                "perp_exchange_coverage": "Marchés perpétuels observés",
                "perp_flow_exchange_coverage": "Marchés avec flux agressif complet",
            },
        ),
        (
            "Options et sensibilité gamma",
            "Amplitude et forme possibles du mouvement ; le signe réel des intermédiaires demeure inconnu.",
            {
                "pcr_oi_global": "Ratio puts / calls en positions",
                "pcr_volume_global": "Ratio puts / calls en volume",
                "atm_iv_30d": "Volatilité anticipée à 30 jours",
                "skew_30d": "Protection baisse contre hausse",
                "estimated_gamma_gross_usd_per_1pct_global": "Sensibilité gamma brute par mouvement de 1 %",
                "estimated_gamma_front_7d_near_spot_share": "Part proche du prix et de l’échéance",
                "estimated_gamma_reliable": "Estimation jugée assez complète",
            },
        ),
        (
            "Flux quotidiens des ETF BTC / ETH",
            "Entrées ou sorties nettes publiées chaque jour ; usage descriptif jusqu’à validation prospective.",
            {
                "etf_trading_date": "Journée de marché concernée",
                "etf_daily_net_flow_usd": "Flux net du jour",
                "etf_flow_3d_usd": "Cumul sur 3 jours publiés",
                "etf_flow_5d_usd": "Cumul sur 5 jours publiés",
                "etf_flow_10d_usd": "Cumul sur 10 jours publiés",
                "etf_history_day_count": "Journées historiques consolidées",
                "etf_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Offre de stablecoins",
            "Proxy de liquidité globale ; ce n’est pas une mesure des dépôts sur les plateformes.",
            {
                "stablecoin_supply_usd": "Offre totale indexée sur le dollar",
                "stablecoin_supply_change_1d_usd": "Variation sur 1 jour",
                "stablecoin_supply_change_7d_usd": "Variation sur 7 jours",
                "stablecoin_supply_change_30d_usd": "Variation sur 30 jours",
                "stablecoin_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Liquidations forcées longues / courtes",
            "Flux publics multi-plateformes. Valorisation indicative aux prix diffusés, jamais un total exhaustif du marché.",
            {
                "observed_long_liquidation_notional_usd": "Positions longues liquidées",
                "observed_short_liquidation_notional_usd": "Positions courtes liquidées",
                "observed_liquidation_order_count": "Ordres capturés",
                "observed_liquidation_imbalance": "Déséquilibre courtes moins longues",
                "liquidation_stream_live": "Flux d’écoute actif",
                "liquidation_snapshot_is_lower_bound": "Montants signalés comme borne basse",
            },
        ),
        (
            "Dérivés décentralisés · Hyperliquid",
            "Positions ouvertes, prime et financement des contrats perpétuels d'un DEX. Relevé toutes les 15 minutes.",
            {
                "dex_open_interest_notional_usd": "Positions ouvertes sur le DEX",
                "dex_oi_weighted_basis": "Écart du perpétuel DEX / prix oracle",
                "dex_oi_weighted_funding": "Coût du financement DEX",
                "dex_volume_24h_usd": "Volume DEX sur 24 heures",
                "perp_dex_exchange_coverage": "DEX observés",
                "dex_perp_information_age_seconds": "Âge de l’information reçue",
            },
        ),
        (
            "Comparaison ETH / BTC",
            "Force relative calculée uniquement avec des valeurs déjà disponibles.",
            {
                "eth_btc": "Ratio ETH / BTC",
                "eth_btc_return_24h": "Variation relative sur 24 h",
                "btc_dominance": "Dominance BTC",
                "total3_btc": "Altcoins hors BTC/ETH contre BTC",
            },
        ),
    ]
    for title, explanation, fields in sections:
        st.markdown(f"#### {title}")
        st.caption(explanation)
        table = pd.DataFrame(
            [
                {
                    "Mesure": label,
                    "Valeur": _readable_feature_value(key, features.get(key)),
                    "Champ technique": key,
                }
                for key, label in fields.items()
            ]
        )
        st.dataframe(table, hide_index=True, width="stretch")


def scenario_history(rows: pd.DataFrame, horizon: float) -> pd.DataFrame:
    history: list[dict[str, object]] = []
    ordered = rows.sort_values("prediction_time").reset_index(drop=True)
    times = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce")
    ordered = ordered[times.notna()].reset_index(drop=True)
    times = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce")
    if ordered.empty:
        return pd.DataFrame()
    cutoff = times.max() - scenario_lookback(horizon)
    positions = ordered.index[times >= cutoff].tolist()
    max_points = 240
    stride = max(1, (len(positions) + max_points - 1) // max_points)
    sampled_positions = positions[::stride]
    if positions and sampled_positions[-1] != positions[-1]:
        sampled_positions.append(positions[-1])
    for index in sampled_positions:
        row = ordered.iloc[index]
        thesis = directional_thesis(
            row.to_dict(),
            ordered.iloc[max(0, index - 96): index + 1],
            horizon=horizon,
        )
        if not thesis.get("available"):
            continue
        display_direction = str(thesis["bias"])
        display_target = float(thesis["dominant_target"])
        display_invalidation = float(thesis["invalidation_level"])
        if display_direction == "CONSOLIDATION":
            score = float(thesis["score"])
            if score > 50:
                display_direction = "PRESSION HAUSSIÈRE"
                display_target = float(thesis["resistance"])
                display_invalidation = float(thesis["support"])
            elif score < 50:
                display_direction = "PRESSION BAISSIÈRE"
                display_target = float(thesis["support"])
                display_invalidation = float(thesis["resistance"])
        history.append(
            {
                "Date": row["prediction_time"],
                "Support de thèse": thesis["support"],
                "Prix observé": row["spot_price"],
                "Cible dominante": display_target,
                "Résistance de thèse": thesis["resistance"],
                "Invalidation": display_invalidation,
                "Direction": display_direction,
                "Confluence (0–100, non probabiliste)": thesis["conviction"],
            }
        )
    return pd.DataFrame(history)


SCENARIO_HORIZONS = DECISION_HORIZONS


def show_scenario_trajectory(
    rows: pd.DataFrame,
    *,
    key_suffix: str,
    default: str = "7 jours",
    current_features: dict[str, object] | None = None,
) -> None:
    """Render prospective conditional paths from the latest observation."""

    st.subheader("Trajectoires prospectives des scénarios")
    label = st.segmented_control(
        "Horizon de la fourchette",
        list(SCENARIO_HORIZONS),
        default=default,
        key=f"scenario_trajectory_horizon_{key_suffix}",
    )
    horizon = SCENARIO_HORIZONS.get(str(label), SCENARIO_HORIZONS[default])
    ordered = rows.copy()
    ordered["prediction_time"] = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce")
    ordered = ordered.dropna(subset=["prediction_time"]).sort_values("prediction_time")
    if ordered.empty:
        st.info("Le premier scénario sera disponible après le prochain relevé exploitable.")
        return
    latest_row = ordered.iloc[-1]
    latest_dict = {**latest_row.to_dict(), **dict(current_features or {})}
    thesis = directional_thesis(latest_dict, ordered, horizon=horizon)
    if not thesis.get("available"):
        st.info("La volatilité implicite nécessaire à la fourchette prospective est indisponible.")
        return
    origin = latest_row["prediction_time"]
    history = prepare_forward_scenario_chart(
        origin=origin,
        spot_price=float(latest_row["spot_price"]),
        support=float(thesis["support"]),
        resistance=float(thesis["resistance"]),
        sigma_percent=float(thesis["sigma_percent"]),
        directional_score=float(thesis["score"]),
        horizon_days=horizon,
    )
    if history.empty:
        st.info("La trajectoire prospective ne peut pas être calculée avec le relevé courant.")
        return
    axis_config = scenario_axis_config(origin, horizon)
    bias = str(thesis.get("bias", "CONSOLIDATION"))
    chart_invalidation = (
        f"hors ${float(thesis['support']):,.0f}–${float(thesis['resistance']):,.0f}"
        if bias == "CONSOLIDATION"
        else f"${float(thesis['invalidation_level']):,.0f}"
    )
    if "HAUSSI" in bias:
        direction_class, direction_arrow = "up", "↗"
        direction_color, fill_color = "#2dcc75", "rgba(45,204,117,.13)"
    elif "BAISSI" in bias:
        direction_class, direction_arrow = "down", "↘"
        direction_color, fill_color = "#ef5964", "rgba(239,89,100,.13)"
    else:
        direction_class, direction_arrow = "flat", "→"
        direction_color, fill_color = "#d8a63a", "rgba(216,166,58,.12)"
    st.markdown(
        f"""
        <div class="bc-scenario-card">
          <div><span class="bc-scenario-label">DIRECTION ACTIVE</span><span class="bc-scenario-value {direction_class}">{direction_arrow} {bias}</span></div>
          <div><span class="bc-scenario-label">PRIX DE DÉPART</span><span class="bc-scenario-value">${float(latest_row['spot_price']):,.0f}</span></div>
          <div><span class="bc-scenario-label">CIBLE DOMINANTE À L’ÉCHÉANCE</span><span class="bc-scenario-value {direction_class}">${float(thesis['dominant_target']):,.0f}</span></div>
          <div><span class="bc-scenario-label">INVALIDATION</span><span class="bc-scenario-value">{chart_invalidation}</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    chart_dates = [pd.Timestamp(value).isoformat() for value in history["Date"]]
    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=chart_dates,
            y=history["Fourchette basse"],
            name="Limite basse",
            line={"width": 0},
            hoverinfo="skip",
            showlegend=False,
        )
    )
    figure.add_trace(
        go.Scatter(
            x=chart_dates,
            y=history["Fourchette haute"],
            name="Fourchette conditionnelle",
            fill="tonexty",
            fillcolor=fill_color,
            line={"width": 0},
            hovertemplate="Borne haute $%{y:,.0f}<extra></extra>",
        )
    )
    figure.add_trace(
        go.Scatter(
            x=chart_dates,
            y=history["Scénario haussier"],
            name="Scénario haussier",
            line={"color": "#2dcc75", "width": 3.0 if "HAUSSI" in bias else 1.8},
            hovertemplate="Haussier $%{y:,.0f}<extra></extra>",
        )
    )
    figure.add_trace(
        go.Scatter(
            x=chart_dates,
            y=history["Scénario central"],
            name="Scénario central",
            line={"color": "#d8a63a", "width": 3.0 if bias == "CONSOLIDATION" else 1.8, "dash": "dash"},
            hovertemplate="Central $%{y:,.0f}<extra></extra>",
        )
    )
    figure.add_trace(
        go.Scatter(
            x=chart_dates,
            y=history["Scénario baissier"],
            name="Scénario baissier",
            line={"color": "#ef5964", "width": 3.0 if "BAISSI" in bias else 1.8},
            hovertemplate="Baissier $%{y:,.0f}<extra></extra>",
        )
    )
    figure.add_trace(
        go.Scatter(
            x=[pd.Timestamp(origin).isoformat()],
            y=[float(latest_row["spot_price"])],
            name="Dernier prix observé",
            mode="markers",
            marker={"color": "#f4efe3", "size": 9, "line": {"color": "#101216", "width": 1}},
            hovertemplate="Départ $%{y:,.0f}<extra></extra>",
        )
    )
    invalidation_levels = (
        [float(thesis["support"]), float(thesis["resistance"])]
        if bias == "CONSOLIDATION"
        else [float(thesis["invalidation_level"])]
    )
    for level in invalidation_levels:
        figure.add_hline(
            y=level,
            line={"color": "#ef5964", "width": 1.2, "dash": "dot"},
            annotation_text="INVALIDATION",
            annotation_position="bottom right",
            annotation_font={"color": "#ef5964", "size": 10},
        )
    figure.update_layout(
        height=440,
        margin={"l": 12, "r": 12, "t": 42, "b": 12},
        hovermode="x unified",
        yaxis_title="Prix USD",
        legend={
            "orientation": "h",
            "yanchor": "bottom",
            "y": 1.02,
            "xanchor": "left",
            "x": 0,
            "bgcolor": "rgba(9,10,13,.66)",
        },
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#101216",
        font={"color": "#f4efe3"},
        xaxis={
            **axis_config,
            "gridcolor": "rgba(216,166,58,.08)",
            "zerolinecolor": "rgba(216,166,58,.16)",
            "showspikes": True,
            "spikemode": "across",
            "spikecolor": "rgba(240,202,115,.35)",
        },
        yaxis={
            "title": "Prix USD",
            "gridcolor": "rgba(216,166,58,.08)",
            "zerolinecolor": "rgba(216,166,58,.16)",
            "tickprefix": "$",
            "separatethousands": True,
        },
        uirevision=f"scenario-{key_suffix}-{label}",
    )
    end = history["Date"].iloc[-1]
    st.caption(
        f"Projection conditionnelle du {origin.strftime('%d/%m/%Y %H:%M UTC')} au "
        f"{end.strftime('%d/%m/%Y %H:%M UTC')}. Les courbes illustrent la thèse courante et "
        "sa fourchette implicite ; elles ne sont ni des prix réalisés ni des probabilités validées."
    )
    st.plotly_chart(
        figure,
        width="stretch",
        key=f"scenario_trajectory_chart_{key_suffix}",
    )


def _validated_four_hour_reference(
    summary: dict[str, object] | None, asset: str
) -> dict[str, object] | None:
    if not summary:
        return None
    evaluation = next(
        (
            item
            for item in summary.get("evaluations", [])
            if item.get("asset") == asset and item.get("target") == "up_4h"
        ),
        None,
    )
    if not evaluation:
        return None
    effective = float(evaluation["holdout"]["effective_sample_count"])
    if evaluation.get("selected_model") != "M0_UNCONDITIONAL" or effective < 500:
        return None
    return {
        "probability": float(evaluation["latest_research_probability"]),
        "holdout_rate": float(evaluation["holdout"]["base_rate"]),
        "effective_sample": effective,
    }


def _money_compact(value: float) -> str:
    magnitude = abs(value)
    if magnitude >= 1_000_000_000:
        return f"${value / 1_000_000_000:,.2f} Md"
    if magnitude >= 1_000_000:
        return f"${value / 1_000_000:,.1f} M"
    if magnitude >= 1_000:
        return f"${value / 1_000:,.1f} k"
    return f"${value:,.0f}"


def _summary_table(
    latest: dict[str, object],
    research_summary: dict[str, object] | None,
) -> pd.DataFrame:
    gate = tactical_exploitability(latest)
    asset = str(latest.get("asset", ""))
    reference = _validated_four_hour_reference(research_summary, asset)
    gamma = gamma_exposure_summary(latest)
    rows: list[dict[str, str]] = []
    if reference:
        probability = float(reference["probability"])
        statistical_reading = "↑ HAUSSIER LÉGER" if probability >= 0.525 else "↓ BAISSIER LÉGER" if probability <= 0.475 else "↔ NEUTRE"
        rows.append(
            {
                "Couche": "Statistique validée · 4 h",
                "Lecture directe": statistical_reading,
                "Chiffre": f"Fréquence historique de hausse {100 * probability:.1f}%",
                "Solidité": f"BASE RATE · N eff. {reference['effective_sample']:,.0f}",
            }
        )
    else:
        rows.append(
            {
                "Couche": "Repère historique · 4 h",
                "Lecture directe": "HISTORIQUE EN CONSTRUCTION",
                "Chiffre": "Échantillon en cours",
                "Solidité": "COLLECTE ACTIVE",
            }
        )
    thesis = directional_thesis(latest, horizon=7)
    rows.append(
        {
            "Couche": "Thèse de marché · 7 jours",
            "Lecture directe": str(thesis.get("bias", gate["direction"])),
            "Chiffre": f"Confluence {float(thesis.get('conviction', 0)):.0f}/100 · non probabiliste",
            "Solidité": f"{gate['family_count']}/{gate['family_total']} familles",
        }
    )
    macro_values = [
        latest.get(name)
        for name in (
            "macro_growth_signal",
            "macro_inflation_signal",
            "macro_liquidity_signal",
            "macro_policy_signal",
            "cme_policy_expectation_signal",
        )
        if latest.get(name) is not None and pd.notna(latest.get(name))
    ]
    if macro_values:
        macro_index = 50.0 + 40.0 * float(pd.Series(macro_values, dtype=float).mean())
        rows.append(
            {
                "Couche": "Macro / Fed / CME · contexte",
                "Lecture directe": direction_label(macro_index).replace(" · exploratoire", ""),
                "Chiffre": "Régime courant descriptif",
                "Solidité": "ACTUEL · NON VINTAGE-SAFE",
            }
        )
    if gamma.get("available"):
        gross = float(gamma["gross_usd_per_1pct"])
        rows.append(
            {
                "Couche": "Gamma · forme du mouvement",
                "Lecture directe": str(gamma["regime"]),
                "Chiffre": f"Brut {_money_compact(gross)} / mouvement de 1%",
                "Solidité": str(gamma["reliability"]),
            }
        )
    else:
        rows.append(
            {
                "Couche": "Gamma · forme du mouvement",
                "Lecture directe": "— INDISPONIBLE",
                "Chiffre": "Aucune estimation",
                "Solidité": "INDISPONIBLE",
            }
        )
    return pd.DataFrame(rows)


def show_scenario_explorer(
    rows: pd.DataFrame,
    feature_version: str | None,
    research_summary: dict[str, object] | None,
    macro_context: dict[str, object],
    decision_snapshot: dict[str, object],
    *,
    include_brief: bool = True,
) -> None:
    latest = rows.sort_values("prediction_time").iloc[-1]
    latest_dict = decision_snapshot.get("latest", {**latest.to_dict(), **macro_feature_overlay(macro_context)})
    score, factors = exploratory_direction_index(latest_dict)
    scenario_table = implied_scenario_table(latest_dict)
    if include_brief:
        st.subheader("Synthèse institutionnelle")
        show_decision_brief(decision_snapshot, research_summary, macro_context)
    thesis_horizon_label = st.segmented_control(
        "Horizon de la thèse directionnelle",
        list(SCENARIO_HORIZONS),
        default="7 jours",
        key=f"directional_thesis_horizon_{str(latest.get('asset', '')).lower()}",
    )
    thesis_horizon = SCENARIO_HORIZONS.get(str(thesis_horizon_label), 7.0)
    thesis = directional_thesis(latest_dict, rows, horizon=thesis_horizon)
    thesis_scenarios = directional_scenario_table(latest_dict, rows, horizon=thesis_horizon)

    if thesis.get("available"):
        st.success(f"**Thèse active :** {thesis['summary']}")
        if thesis.get("drivers"):
            st.write("**Confluences dominantes :** " + " · ".join(str(item) for item in thesis["drivers"]))
    st.subheader(f"Scénarios directionnels · horizon {thesis_horizon_label}")
    if thesis_scenarios.empty:
        st.warning("La surface d’options ne permet pas encore de chiffrer les zones de scénario.")
    else:
        directional_display = thesis_scenarios.copy()
        directional_display = directional_display.rename(columns={"Poids de thèse": "Poids relatif (non probabiliste)"})
        directional_display["Poids relatif (non probabiliste)"] = directional_display["Poids relatif (non probabiliste)"].map(
            lambda value: f"{value:.1f} %"
        )
        st.dataframe(directional_display, hide_index=True, width="stretch")
        st.caption("Ces poids ordonnent la thèse, la consolidation et son invalidation ; ils ne sont pas des probabilités calibrées.")

    st.subheader("Tableau de confluence")
    st.dataframe(_summary_table(latest_dict, research_summary), hide_index=True, width="stretch")

    if not PUBLIC_STUDENT_MODE:
        st.subheader("Preuves de confiance et seuils restants")
        st.dataframe(
            confidence_proof_table(rows, research_summary, str(latest["asset"]), macro_context),
            hide_index=True,
            width="stretch",
        )

    st.subheader("Votes directionnels par marché")
    show_liquidations(latest_dict)
    family_display = directional_evidence_table(latest_dict).drop(columns=["Interprétation"])
    st.dataframe(family_display, hide_index=True, width="stretch")
    st.caption(
        "Les votes séparent comptant, dérivés, options, macro/taux, ETF/liquidité, liquidations, force relative et CME futures."
    )

    st.subheader("Amplitude statistique issue des options")
    if scenario_table.empty:
        st.warning("Surface de volatilité implicite indisponible pour construire les fourchettes.")
    else:
        display = scenario_table.drop(columns=["Jours", "Source IV"]).copy()
        for column in ("Scénario bas", "Point central", "Scénario haut", "Zone 68% basse", "Zone 68% haute"):
            display[column] = display[column].map(lambda value: f"${value:,.2f}")
        for column in ("Amplitude implicite 1σ", "IV annualisée"):
            display[column] = display[column].map(lambda value: f"{value:.2f}%")
        for column in ("Probabilité zone centrale", "Probabilité chaque queue"):
            display[column] = display[column].map(lambda value: f"≈ {value:.0f}%")
        for column in ("P(|mouvement| ≥ 1%)", "P(|mouvement| ≥ 3%)", "P(|mouvement| ≥ 5%)"):
            display[column] = display[column].map(lambda value: f"≈ {value:.1f}%")
        st.dataframe(display, hide_index=True, width="stretch")
        calibration = forward_band_calibration(rows)
        st.markdown("**Calibration forward de la zone 68 %**")
        if not calibration.empty:
            calibration_display = calibration.copy()
            calibration_display["Couverture observée zone 68%"] = calibration_display["Couverture observée zone 68%"].map(
                lambda value: "—" if pd.isna(value) else f"{value:.1f}%"
            )
            calibration_display["Cible théorique"] = calibration_display["Cible théorique"].map(lambda value: f"{value:.2f}%")
            st.dataframe(calibration_display, hide_index=True, width="stretch")

    gamma = gamma_exposure_summary(latest_dict)
    st.subheader("Carte gamma · scénarios conditionnés par le marché")
    if not gamma.get("available"):
        st.warning("Gamma non calculable sur la surface disponible ; aucune position dealer n’est supposée.")
    else:
        gross = float(gamma["gross_usd_per_1pct"])
        gamma_left, gamma_middle, gamma_right = st.columns(3)
        gamma_left.metric("Gamma brut estimé / 1%", _money_compact(gross))
        gamma_middle.metric("Régime", str(gamma["regime"]))
        dominant = gamma.get("dominant_strike")
        gamma_right.metric("Strike gamma dominant", f"${float(dominant):,.0f}" if dominant else "—", str(gamma["reliability"]), delta_color="off")
        gamma_scenarios = gamma_path_scenarios(latest_dict)
        st.dataframe(gamma_scenarios, hide_index=True, width="stretch")
        st.caption(
            "ESTIMATED_DEALER_GAMMA : Black–Scholes sur mark IV/OI point-in-time. "
            "Le signe dealer reste inconnu : les scénarios sont donc activés par proximité des strikes, flux et volatilité réalisée, pas par une position inventée."
        )

    show_scenario_trajectory(
        rows,
        key_suffix=f"detailed_{str(latest.get('asset', '')).lower()}",
        current_features=latest_dict,
    )

    first_time = rows["prediction_time"].min()
    last_time = rows["prediction_time"].max()
    history_days = max(0.0, (last_time - first_time).total_seconds() / 86_400)
    historical_rows = len(rows)
    if research_summary:
        boundary = research_summary.get("_freeze_manifest", {}).get("boundaries", {}).get(str(latest["asset"]), {})
        if boundary:
            history_days = max(
                0.0,
                (pd.Timestamp(boundary["history_end"]) - pd.Timestamp(boundary["history_start"])).total_seconds()
                / 86_400,
            )
            historical_rows = int(boundary.get("row_count", historical_rows))
    day_ratio = min(history_days / MINIMUM_HISTORY_DAYS, 1.0)
    bucket_ratio = min(historical_rows / MINIMUM_CANONICAL_BUCKETS, 1.0)
    st.subheader("Progression du backtest")
    maturity_left, maturity_right = st.columns(2)
    with maturity_left:
        st.progress(day_ratio, text=f"Historique : {history_days:.2f} / {MINIMUM_HISTORY_DAYS} jours")
    with maturity_right:
        st.progress(bucket_ratio, text=f"Intervalles : {historical_rows:,} / {MINIMUM_CANONICAL_BUCKETS:,}")

    with st.expander("Méthode et preuves de la lecture tactique"):
        st.write(
            "Les huit familles votent séparément afin de ne pas multiplier artificiellement des indicateurs corrélés. "
            "La confluence combine leur couverture, leur accord et leur intensité. Ce score n'est ni une probabilité "
            "de réussite ni une confiance statistique ; la thèse donne toujours son niveau "
            "de bascule pour pouvoir être réfutée par le marché."
        )
        if factors:
            factor_frame = pd.DataFrame(
                {
                    "Facteur": list(factors.keys()),
                    "Sens": [
                        "Favorable à la hausse" if value > 0.05 else "Favorable à la baisse" if value < -0.05 else "Neutre"
                        for value in factors.values()
                    ],
                    "Intensité": [
                        "Marquée" if abs(value) >= 0.55 else "Modérée" if abs(value) >= 0.20 else "Faible"
                        for value in factors.values()
                    ],
                }
            )
            st.dataframe(factor_frame, hide_index=True, width="stretch")

    st.subheader("Données de marché détaillées")
    st.caption(
        "La vue élève reprend ici les mêmes familles et les mêmes valeurs point-in-time que la vue locale."
    )
    show_feature_sections(latest_dict)
    if PUBLIC_STUDENT_MODE:
        st.caption(f"Données observées au {_utc_label(latest.get('prediction_time'))}.")
    else:
        st.caption(f"Snapshot {latest.get('prediction_time')} · version {feature_version}")


TARGET_LABELS = {
    "up_4h": "Hausse à 4 h",
    "up_24h": "Hausse à 24 h",
    "up_72h": "Hausse à 72 h",
    "up_7d": "Hausse à 7 j",
    "first_touch_plus_3_before_minus_3_72h": "+3 % avant −3 % (72 h)",
}


def show_historical_validation(summary: dict[str, object] | None, asset: str) -> None:
    st.subheader("Backtest historique gelé")
    if not summary:
        st.info("Aucun rapport historique versionné n’est encore disponible.")
        return
    evaluations = [item for item in summary.get("evaluations", []) if item.get("asset") == asset]
    if not evaluations:
        st.info(f"Aucun résultat historique disponible pour {asset}.")
        return
    four_hour = next((item for item in evaluations if item["target"] == "up_4h"), None)
    if four_hour and float(four_hour["holdout"]["effective_sample_count"]) >= 500:
        left, middle, right = st.columns(3)
        left.metric(
            "Taux de base historique 4 h",
            f"{100 * float(four_hour['latest_research_probability']):.1f}%",
        )
        middle.metric(
            "Brier holdout 4 h",
            f"{float(four_hour['holdout']['brier']):.4f}",
        )
        right.metric(
            "Échantillon effectif 4 h",
            f"{float(four_hour['holdout']['effective_sample_count']):,.0f}",
        )
        st.info(
            "Ce chiffre est un taux de référence non conditionnel, pas un signal de marché actuel. "
            "Les modèles régime/logistique n’ont pas démontré d’amélioration robuste après correction multiple."
        )

    rows = []
    for item in evaluations:
        holdout = item["holdout"]
        effective = float(holdout["effective_sample_count"])
        status = item["status"]
        if item["selected_model"] == "M0_UNCONDITIONAL" and effective < 500:
            status = "ÉCHANTILLON EFFECTIF INSUFFISANT"
        elif item["selected_model"] == "M0_UNCONDITIONAL":
            status = "TAUX DE BASE VALIDÉ · PAS D’EDGE CONDITIONNEL"
        rows.append(
            {
                "Horizon / cible": TARGET_LABELS.get(item["target"], item["target"]),
                "Statut": status,
                "Modèle retenu": "M0 taux de base" if item["selected_model"] == "M0_UNCONDITIONAL" else item["selected_model"],
                "Taux observé holdout": f"{100 * float(holdout['base_rate']):.2f}%",
                "Brier": f"{float(holdout['brier']):.4f}",
                "ECE": f"{float(holdout['expected_calibration_error']):.4f}",
                "N brut": f"{int(holdout['sample_count']):,}",
                "N effectif": f"{effective:,.1f}",
            }
        )
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    if PUBLIC_STUDENT_MODE:
        st.caption(
            "Contrôle honnête : test final gardé à part, validation dans l’ordre du temps, "
            "période de sécurité entre apprentissage et test, et correction des essais multiples."
        )
    else:
        st.caption(
            f"Dataset {summary.get('dataset_version')} · recherche {summary.get('research_version')} · "
            "holdout final 20 % gelé, walk-forward purgé, embargo 7 jours, correction Benjamini–Hochberg."
        )
    with st.expander("Pourquoi aucun modèle plus complexe n’est publié"):
        st.write(
            "À 4 h, la logistique a légèrement réduit le Brier pendant le développement, mais l’effet "
            "n’était ni significatif après correction multiple ni stable entre régimes. Aux horizons plus "
            "longs, les modèles conditionnels ont généralement fait moins bien que le taux de base. "
            "Le boosting reste donc exclu de la production, conformément au protocole anti-surapprentissage."
        )


def show_prediction_journal(predictions: pd.DataFrame, asset: str) -> None:
    # This is an internal statistical audit surface. Even if a future layout
    # calls it accidentally, never expose its technical statuses to students.
    if PUBLIC_STUDENT_MODE:
        return
    asset_predictions = predictions[predictions["asset"] == asset] if not predictions.empty else pd.DataFrame()
    if asset_predictions.empty:
        st.warning(
            "Le modèle statistique n’est pas encore validé. L’explorateur continue néanmoins "
            "d’afficher et d’archiver l’évolution des scénarios observables."
        )
        with st.expander("Statut technique de validation"):
            st.code(INSUFFICIENT_CONFIDENCE)
            st.write("Aucune probabilité calibrée ni performance hors échantillon n’est encore revendiquée.")
        return

    asset_predictions = asset_predictions.sort_values("prediction_timestamp", ascending=False)
    latest_prediction = asset_predictions.iloc[0]
    confidence = json.loads(latest_prediction["confidence_json"])
    quality = json.loads(latest_prediction["data_quality_json"])
    regimes = json.loads(latest_prediction["market_regime_json"])
    left, middle, right = st.columns(3)
    left.metric("Prix journalisé", f"${latest_prediction['price']:,.2f}")
    quality_score = float(quality.get("score", 0))
    quality_label = "SUFFISANTE" if quality_score >= 80 else "PARTIELLE" if quality_score >= 50 else "INSUFFISANTE"
    middle.metric("Qualité des données", quality_label, "voir les preuves famille par famille", delta_color="off")
    status_label = (
        "TAUX DE BASE SEULEMENT"
        if latest_prediction["status"] == "VALIDATED_BASE_RATE_ONLY"
        else "NON EXPLOITABLE POUR PRÉDICTION"
    )
    right.metric("Usage statistique", status_label)
    st.json({"macro": latest_prediction["macro_regime"], **regimes})
    if latest_prediction["status"] == "VALIDATED_BASE_RATE_ONLY" and pd.notna(latest_prediction["calibrated_probability"]):
        st.metric("Taux de base journalisé", f"{100 * latest_prediction['calibrated_probability']:.1f}%")
        st.info("Référence non conditionnelle journalisée pour le suivi prospectif ; ce n’est pas un signal.")
    elif (
        latest_prediction["status"] in {"STATISTICALLY_USABLE", "BACKTEST_VALIDATED_FORWARD_PENDING"}
        and pd.notna(latest_prediction["calibrated_probability"])
    ):
        st.metric("Probabilité calibrée", f"{100 * latest_prediction['calibrated_probability']:.1f}%")
    else:
        st.warning("Probabilité du modèle non validée ; utilisez uniquement l’explorateur descriptif.")
    st.caption(f"Modèle {latest_prediction['model_version']} · snapshot {latest_prediction['prediction_timestamp']}")
    with st.expander("Diagnostic technique brut (pour audit)"):
        st.json({"data_quality": quality, "confidence": confidence})


hosted_data_watchdog()
journal_path = Path(os.getenv("CQE_JOURNAL_DB", data_dir() / "predictions" / "journal.db"))
predictions = read_latest_predictions(journal_path)
feature_snapshots, feature_version = read_latest_features(data_dir() / "features")
research_summary = read_research_summary(data_dir() / "research" / "runs")
macro_observations = read_macro_observations(data_dir() / "normalized" / "market.db")
macro_context = build_macro_context(macro_observations)
show_data_freshness(feature_snapshots)
if reading_mode == "Essentiel":
    show_macro_plain(macro_context)
else:
    show_macro_context(macro_context)
st.divider()
asset = st.segmented_control("Actif", ["BTC", "ETH"], default="BTC")

asset_features = (
    feature_snapshots[feature_snapshots["asset"] == asset].copy()
    if not feature_snapshots.empty
    else pd.DataFrame()
)
if not asset_features.empty:
    asset_features = attach_current_relative_context(asset_features, feature_snapshots)
decision_snapshot = build_decision_snapshot(
    asset_features,
    macro_feature_overlay(macro_context),
)
if asset_features.empty:
    st.info("Aucun snapshot de marché. Lancez ACTUALISER_DONNEES.bat.")
elif reading_mode == "Essentiel":
    show_beginner_overview(asset_features, research_summary, macro_context, decision_snapshot)
else:
    show_scenario_explorer(
        asset_features, feature_version, research_summary, macro_context, decision_snapshot
    )

st.divider()
if reading_mode == "Essentiel":
    if not PUBLIC_STUDENT_MODE:
        show_simple_validation(research_summary, asset)
    with st.expander("Voir toute l’analyse technique, les graphiques et les tests"):
        show_macro_context(macro_context)
        if not asset_features.empty:
            show_scenario_explorer(
                asset_features,
                feature_version,
                research_summary,
                macro_context,
                decision_snapshot,
                include_brief=False,
            )
        if not PUBLIC_STUDENT_MODE:
            st.subheader("Couche statistique complète")
            show_historical_validation(research_summary, asset)
            show_prediction_journal(predictions, asset)
else:
    if not PUBLIC_STUDENT_MODE:
        st.subheader("Couche statistique validée")
        show_historical_validation(research_summary, asset)
        show_prediction_journal(predictions, asset)
