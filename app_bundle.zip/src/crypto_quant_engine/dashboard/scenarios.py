from __future__ import annotations

import math
from statistics import NormalDist
from typing import Mapping

import numpy as np
import pandas as pd


HORIZON_IV_COLUMNS = {
    4 / 24: "atm_iv_7d",
    1: "atm_iv_7d",
    7: "atm_iv_7d",
    30: "atm_iv_30d",
}

FAMILY_WEIGHTS = {
    "Spot": 0.20,
    "Perpétuels": 0.17,
    "Options": 0.13,
    "Macro / taux": 0.14,
    "ETF / liquidité": 0.15,
    "Liquidations": 0.10,
    "Force relative": 0.06,
    "Dérivés DEX": 0.05,
}

FAMILY_EXPECTED_COUNTS = {
    "Spot": 3,
    # Basis and funding are the two independently directional CEX measures.
    # Aggressor flow remains visible in the technical audit, but it is not a
    # required coverage item unless its complete interval is proven.
    "Perpétuels": 2,
    "Options": 3,
    "Macro / taux": 5,
    "ETF / liquidité": 4,
    "Liquidations": 1,
    "Force relative": 1,
    "Dérivés DEX": 2,
}

FAMILY_EXPLANATIONS = {
    "Spot": "Carnet et flux agressifs du marché au comptant",
    "Perpétuels": "Basis et funding contrarien des plateformes centralisées ; flux agressif audité séparément",
    "Options": "Put/call et skew, sans hypothèse sur le signe dealer",
    "Macro / taux": "Croissance, inflation, monnaie et taux Fed/BCE/BoJ ; CME FedWatch concerne seulement la Fed",
    "ETF / liquidité": "Flux nets ETF et évolution de l’offre de stablecoins",
    "Liquidations": "Déséquilibre observé entre liquidations courtes et longues",
    "Force relative": "Force d’ETH contre BTC, utilisée pour ETH seulement",
    "Dérivés DEX": "Prime et financement des contrats perpétuels décentralisés Hyperliquid",
}


def _finite(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _iv_decimal(value: object) -> float | None:
    number = _finite(value)
    if number is None or number <= 0:
        return None
    return number / 100.0 if number > 3 else number


def implied_scenario_table(
    features: Mapping[str, object],
    horizons: tuple[float, ...] = (1, 7, 30),
    tail_probability: float = 0.10,
) -> pd.DataFrame:
    """Return descriptive option-implied bands, not validated directional forecasts."""
    price = _finite(features.get("spot_price"))
    if price is None or price <= 0 or not 0 < tail_probability < 0.5:
        return pd.DataFrame()
    z_score = NormalDist().inv_cdf(1 - tail_probability)
    rows: list[dict[str, object]] = []
    for horizon in horizons:
        horizon = _finite(horizon)
        # Conserver les fractions de jour, notamment l'horizon de quatre heures.
        if horizon is None or horizon <= 0:
            continue
        iv_column = HORIZON_IV_COLUMNS.get(horizon, "atm_iv_30d")
        iv = _iv_decimal(features.get(iv_column))
        if iv is None:
            continue
        sigma = iv * math.sqrt(horizon / 365.25)
        central_68 = NormalDist().inv_cdf(0.841344746)

        def abs_move_probability(threshold: float) -> float:
            upper = math.log1p(threshold) / sigma
            lower = math.log1p(-threshold) / sigma
            normal = NormalDist()
            return 100.0 * ((1.0 - normal.cdf(upper)) + normal.cdf(lower))

        rows.append(
            {
                "Horizon": f"{horizon * 24:g}h" if horizon < 1 else f"{horizon:g}j",
                "Jours": horizon,
                "Scénario bas": price * math.exp(-z_score * sigma),
                "Point central": price,
                "Scénario haut": price * math.exp(z_score * sigma),
                "Amplitude implicite 1σ": 100 * sigma,
                "Zone 68% basse": price * math.exp(-central_68 * sigma),
                "Zone 68% haute": price * math.exp(central_68 * sigma),
                "P(|mouvement| ≥ 1%)": abs_move_probability(0.01),
                "P(|mouvement| ≥ 3%)": abs_move_probability(0.03),
                "P(|mouvement| ≥ 5%)": abs_move_probability(0.05),
                "IV annualisée": 100 * iv,
                "Probabilité zone centrale": 100 * (1 - 2 * tail_probability),
                "Probabilité chaque queue": 100 * tail_probability,
                "Statut probabilité": "DISTRIBUTION IMPLICITE · CALIBRATION FORWARD EN COURS",
                "Source IV": iv_column,
            }
        )
    return pd.DataFrame(rows)


def _directional_signals(features: Mapping[str, object]) -> tuple[dict[str, float], dict[str, list[float]]]:
    signals: dict[str, float] = {}
    families: dict[str, list[float]] = {name: [] for name in FAMILY_WEIGHTS}

    def add(family: str, name: str, value: object, transform) -> None:
        number = _finite(value)
        if number is not None:
            signal = float(np.clip(transform(number), -1.0, 1.0))
            signals[name] = signal
            families[family].append(signal)

    add("Spot", "Carnet spot", features.get("spot_order_book_imbalance"), lambda value: value)
    add("Spot", "Flux spot", features.get("spot_buy_sell_imbalance"), lambda value: value)
    add("Spot", "Flux spot normalisé", features.get("spot_flow_z"), lambda value: np.tanh(value / 2.0))
    add(
        "Perpétuels",
        "Basis perp CEX",
        features.get("cex_oi_weighted_basis", features.get("oi_weighted_basis")),
        lambda value: np.tanh(value / 0.002),
    )
    add(
        "Perpétuels",
        "Funding contrarien",
        features.get("cex_oi_weighted_funding", features.get("oi_weighted_funding")),
        lambda value: -np.tanh(value / 0.0005),
    )
    add("Options", "Put/call OI", features.get("pcr_oi_global"), lambda value: np.tanh((1.0 - value) / 0.5))
    add(
        "Options",
        "Put/call volume",
        features.get("pcr_volume_global"),
        lambda value: np.tanh((1.0 - value) / 0.5),
    )
    add("Options", "Skew options", features.get("skew_30d"), lambda value: -np.tanh(value / 5.0))
    add("Macro / taux", "Croissance macro", features.get("macro_growth_signal"), lambda value: value)
    add("Macro / taux", "Inflation macro", features.get("macro_inflation_signal"), lambda value: value)
    add("Macro / taux", "Liquidité macro", features.get("macro_liquidity_signal"), lambda value: value)
    add("Macro / taux", "Politique Fed", features.get("macro_policy_signal"), lambda value: value)
    add(
        "Macro / taux",
        "Anticipations CME",
        features.get("cme_policy_expectation_signal"),
        lambda value: value,
    )
    asset = str(features.get("asset", "")).upper()
    etf_scale = 250_000_000.0 if asset == "BTC" else 100_000_000.0
    add(
        "ETF / liquidité",
        "Flux ETF du jour",
        features.get("etf_daily_net_flow_usd"),
        lambda value: np.tanh(value / etf_scale),
    )
    add(
        "ETF / liquidité",
        "Flux ETF 5 jours",
        features.get("etf_flow_5d_usd"),
        lambda value: np.tanh(value / (3.0 * etf_scale)),
    )
    add(
        "ETF / liquidité",
        "Variation stablecoins 7 jours",
        features.get("stablecoin_supply_change_7d_usd"),
        lambda value: np.tanh(value / 2_000_000_000.0),
    )
    add(
        "ETF / liquidité",
        "Variation stablecoins 30 jours",
        features.get("stablecoin_supply_change_30d_usd"),
        lambda value: np.tanh(value / 6_000_000_000.0),
    )
    add(
        "Liquidations",
        "Liquidations courtes moins longues",
        features.get("observed_liquidation_imbalance"),
        lambda value: value,
    )
    if asset == "ETH":
        add(
            "Force relative",
            "ETH contre BTC sur 24 h",
            features.get("eth_btc_return_24h"),
            lambda value: np.tanh(value / 0.02),
        )
    elif asset == "BTC":
        add(
            "Force relative",
            "BTC contre ETH sur 24 h",
            features.get("eth_btc_return_24h"),
            lambda value: -np.tanh(value / 0.02),
        )
    add(
        "Dérivés DEX",
        "Prime perp DEX",
        features.get("dex_oi_weighted_basis"),
        lambda value: np.tanh(value / 0.002),
    )
    add(
        "Dérivés DEX",
        "Funding DEX contrarien",
        features.get("dex_oi_weighted_funding"),
        lambda value: -np.tanh(value / 0.0005),
    )
    return signals, families


def directional_family_scores(features: Mapping[str, object]) -> dict[str, float]:
    """Return one independent score per data family to limit correlated-factor overcounting."""
    _, families = _directional_signals(features)
    return {name: float(np.mean(values)) for name, values in families.items() if values}


def exploratory_direction_index(features: Mapping[str, object]) -> tuple[float, dict[str, float]]:
    """Build a transparent 10–90 tactical confluence index; it is not a probability."""
    signals, families = _directional_signals(features)

    if not signals:
        return 50.0, {}
    family_scores = {name: float(np.mean(values)) for name, values in families.items() if values}
    effective_weights = {
        name: FAMILY_WEIGHTS[name] * min(len(families[name]) / FAMILY_EXPECTED_COUNTS[name], 1.0)
        for name in family_scores
    }
    available_weight = sum(effective_weights.values())
    composite = sum(effective_weights[name] * value for name, value in family_scores.items()) / available_weight
    # Families, rather than raw indicators, are weighted. The broader scale makes
    # a real confluence readable without pretending that 90 means 90%.
    score = float(np.clip(50.0 + 40.0 * composite, 10.0, 90.0))
    return score, signals


def direction_label(score: float) -> str:
    if score >= 65:
        return "↑ HAUSSIER FORT · exploratoire"
    if score >= 53:
        return "↑ HAUSSIER · exploratoire"
    if score > 50:
        return "↑ HAUSSIER FAIBLE · exploratoire"
    if score <= 35:
        return "↓ BAISSIER FORT · exploratoire"
    if score <= 47:
        return "↓ BAISSIER · exploratoire"
    if score < 50:
        return "↓ BAISSIER FAIBLE · exploratoire"
    return "↔ NEUTRE EXACT · exploratoire"


def directional_conviction(features: Mapping[str, object]) -> tuple[float, str]:
    """Quantify evidence coverage/agreement, explicitly separate from probability."""
    _, raw_families = _directional_signals(features)
    family_scores = {name: float(np.mean(values)) for name, values in raw_families.items() if values}
    if not family_scores:
        return 0.0, "AUCUNE DONNÉE"
    effective_weights = {
        name: FAMILY_WEIGHTS[name]
        * min(len(raw_families[name]) / FAMILY_EXPECTED_COUNTS[name], 1.0)
        for name in family_scores
    }
    available_weight = sum(effective_weights.values())
    composite = sum(effective_weights[name] * value for name, value in family_scores.items()) / available_weight
    if abs(composite) < 1e-12:
        return 0.0, "FAIBLE"
    sign = 1 if composite > 0 else -1
    agreeing_weight = sum(
        effective_weights[name]
        for name, value in family_scores.items()
        if (value > 0 and sign > 0) or (value < 0 and sign < 0)
    )
    coverage = available_weight / sum(FAMILY_WEIGHTS.values())
    agreement = agreeing_weight / available_weight
    intensity = min(abs(composite) / 0.50, 1.0)
    conviction = float(np.clip(100 * coverage * agreement * intensity, 0.0, 100.0))
    label = "ÉLEVÉE" if conviction >= 70 else "MODÉRÉE" if conviction >= 40 else "FAIBLE"
    return conviction, label


def tactical_exploitability(
    features: Mapping[str, object], *, conditional_model_validated: bool = False
) -> dict[str, object]:
    """Turn the hidden confluence math into a decision gate, never a fake probability."""
    score, _ = exploratory_direction_index(features)
    conviction, _ = directional_conviction(features)
    family_scores = directional_family_scores(features)
    family_count = len(family_scores)
    direction_separation = abs(score - 50.0)
    if family_count >= 4 and conviction >= 35 and direction_separation >= 3:
        context_status = "EXPLOITABLE POUR LECTURE TACTIQUE"
        agreement = "CONVERGENCE SUFFISANTE"
    elif family_count >= 3 and direction_separation >= 1:
        context_status = "À SURVEILLER"
        agreement = "CONFIRMATION INCOMPLÈTE"
    else:
        context_status = "NON EXPLOITABLE"
        agreement = "PREUVES INSUFFISANTES"
    prediction_status = (
        "EXPLOITABLE POUR PRÉDICTION" if conditional_model_validated else "NON EXPLOITABLE POUR PRÉDICTION"
    )
    reasons: list[str] = []
    if family_count < 4:
        reasons.append(f"seulement {family_count}/{len(FAMILY_WEIGHTS)} familles directionnelles disponibles")
    if conviction < 35:
        reasons.append("accord ou intensité insuffisants")
    if direction_separation < 3:
        reasons.append("biais trop proche de l’équilibre")
    if not conditional_model_validated:
        reasons.append("aucun modèle conditionnel n’a encore battu le taux de base hors échantillon")
    return {
        "context_status": context_status,
        "prediction_status": prediction_status,
        "agreement": agreement,
        "family_count": family_count,
        "family_total": len(FAMILY_WEIGHTS),
        "direction": direction_label(score).replace(" · exploratoire", ""),
        "reasons": reasons,
    }


def directional_evidence_table(features: Mapping[str, object]) -> pd.DataFrame:
    """Simple directional table with one vote per independent market family."""
    _, raw_families = _directional_signals(features)
    rows: list[dict[str, object]] = []
    for family, weight in FAMILY_WEIGHTS.items():
        values = raw_families[family]
        if not values:
            rows.append(
                {
                    "Couche": family,
                    "Lecture": "— INDISPONIBLE",
                    "Indice": "—",
                    "Couverture": f"0/{FAMILY_EXPECTED_COUNTS[family]}",
                    "Interprétation": FAMILY_EXPLANATIONS[family],
                }
            )
            continue
        family_signal = float(np.mean(values))
        family_index = 50.0 + 50.0 * family_signal
        if family_index >= 60:
            reading = "↑ HAUSSIER"
        elif family_index <= 40:
            reading = "↓ BAISSIER"
        else:
            reading = "↔ NEUTRE"
        magnitude = abs(family_signal)
        intensity = "MARQUÉE" if magnitude >= 0.55 else "MODÉRÉE" if magnitude >= 0.20 else "FAIBLE"
        rows.append(
            {
                "Couche": family,
                "Lecture": reading,
                "Indice": intensity,
                "Couverture": f"{len(values)}/{FAMILY_EXPECTED_COUNTS[family]}",
                "Interprétation": FAMILY_EXPLANATIONS[family],
            }
        )
    return pd.DataFrame(rows)


def _technical_price_nodes(
    history: pd.DataFrame | None,
    price: float,
    sigma: float,
    horizon: float,
) -> tuple[float, float]:
    """Locate high-activity price zones, with volatility-based fallbacks."""

    fallback_support = price * math.exp(-0.80 * sigma)
    fallback_resistance = price * math.exp(0.80 * sigma)
    if history is None or history.empty or "spot_price" not in history:
        return fallback_support, fallback_resistance
    frame = history.copy()
    frame["spot_price"] = pd.to_numeric(frame["spot_price"], errors="coerce")
    frame = frame.dropna(subset=["spot_price"])
    if frame.empty:
        return fallback_support, fallback_resistance
    if "prediction_time" in frame:
        frame["prediction_time"] = pd.to_datetime(frame["prediction_time"], utc=True, errors="coerce")
        frame = frame.sort_values("prediction_time")
        latest_time = frame["prediction_time"].max()
        frame = frame[
            frame["prediction_time"] >= latest_time - pd.Timedelta(max(2.0, float(horizon)), unit="D")
        ]
    if len(frame) < 8:
        return fallback_support, fallback_resistance

    low, high = frame["spot_price"].quantile([0.02, 0.98])
    if not math.isfinite(low) or not math.isfinite(high) or high <= low:
        return fallback_support, fallback_resistance
    bin_count = int(np.clip(round(math.sqrt(len(frame))), 8, 28))
    edges = np.linspace(low, high, bin_count + 1)
    frame["_bin"] = np.clip(np.digitize(frame["spot_price"], edges) - 1, 0, bin_count - 1)
    if "spot_volume" in frame:
        volume = pd.to_numeric(frame["spot_volume"], errors="coerce").fillna(0.0).clip(lower=0.0)
        frame["_activity"] = volume.where(volume > 0, 1.0)
    else:
        frame["_activity"] = 1.0
    activity = frame.groupby("_bin")["_activity"].sum().sort_values(ascending=False)
    centers = {index: (edges[int(index)] + edges[int(index) + 1]) / 2.0 for index in activity.index}
    minimum_distance = max(0.003, 0.30 * sigma)
    supports = [centers[index] for index in activity.index if centers[index] <= price * (1 - minimum_distance)]
    resistances = [centers[index] for index in activity.index if centers[index] >= price * (1 + minimum_distance)]
    node_support = supports[0] if supports else fallback_support
    node_resistance = resistances[0] if resistances else fallback_resistance
    # A target that is closer than the volatility budget is only a first pivot,
    # not a differentiated scenario destination.
    return min(node_support, fallback_support), max(node_resistance, fallback_resistance)


def directional_thesis(
    features: Mapping[str, object],
    history: pd.DataFrame | None = None,
    *,
    horizon: float = 7,
) -> dict[str, object]:
    """Turn the current confluence into an explicit, falsifiable market thesis."""

    price = _finite(features.get("spot_price"))
    if price is None or price <= 0:
        return {"available": False}
    duration_days = float(horizon)
    if duration_days <= 0:
        return {"available": False}
    horizon_key = min(HORIZON_IV_COLUMNS, key=lambda value: abs(float(value) - duration_days))
    iv = _iv_decimal(features.get(HORIZON_IV_COLUMNS.get(horizon_key, "atm_iv_30d")))
    if iv is None:
        return {"available": False}
    sigma = iv * math.sqrt(duration_days / 365.25)
    from .horizon import horizon_evidence
    evidence = horizon_evidence(features, history, duration_days)
    score = evidence["score"]
    conviction = evidence["conviction"]
    # Confluence is not a calibrated forecast probability. Weak or incomplete
    # evidence must not turn a directional illustration into an active call.
    evidence_sufficient = bool(evidence["historical_window_complete"] and conviction >= 35.0)
    observation_time = pd.to_datetime(features.get("prediction_time"), utc=True, errors="coerce")
    if not pd.isna(observation_time):
        age_minutes = max(0.0, (pd.Timestamp.now(tz="UTC") - observation_time).total_seconds() / 60.0)
        if age_minutes > 120:
            evidence_sufficient = False
        elif age_minutes > 30:
            evidence_sufficient = False
    conviction_label = "ÉLEVÉE" if conviction >= 70 else "MODÉRÉE" if conviction >= 40 else "FAIBLE"
    family_scores = evidence["families"]
    support, resistance = _technical_price_nodes(evidence["history"], price, sigma, duration_days)
    confirmation = evidence["confirmation"]
    tilt = float(np.clip((score - 50.0) / 40.0, -1.0, 1.0))
    bias = "HAUSSIER" if tilt > 0.025 else "BAISSIER" if tilt < -0.025 else "CONSOLIDATION"
    if bias == "HAUSSIER":
        dominant_target = resistance
        invalidation_level = price * math.exp(-0.35 * sigma)
        invalidation_target = support
        trigger = f"maintien au-dessus de ${invalidation_level:,.0f} puis franchissement de ${resistance:,.0f}"
        invalidation = f"clôture {confirmation} sous ${invalidation_level:,.0f} ; réévaluer les familles actives de cet horizon"
        summary = (
            f"Hausse privilégiée vers ${dominant_target:,.0f} tant que ${invalidation_level:,.0f} tient. "
            f"Sous ce niveau, la thèse bascule vers ${invalidation_target:,.0f}."
        )
    elif bias == "BAISSIER":
        dominant_target = support
        invalidation_level = price * math.exp(0.35 * sigma)
        invalidation_target = resistance
        trigger = f"rejet sous ${invalidation_level:,.0f} puis rupture de ${support:,.0f}"
        invalidation = f"clôture {confirmation} au-dessus de ${invalidation_level:,.0f} ; réévaluer les familles actives de cet horizon"
        summary = (
            f"Baisse privilégiée vers ${dominant_target:,.0f} tant que ${invalidation_level:,.0f} bloque. "
            f"Au-dessus, la thèse bascule vers ${invalidation_target:,.0f}."
        )
    else:
        dominant_target = price
        invalidation_level = price
        invalidation_target = price
        trigger = f"rotation entre ${support:,.0f} et ${resistance:,.0f}"
        invalidation = f"clôture {confirmation} sous ${support:,.0f} ou au-dessus de ${resistance:,.0f}"
        summary = f"Consolidation privilégiée entre ${support:,.0f} et ${resistance:,.0f} jusqu’à cassure confirmée."
    ranked = sorted(family_scores.items(), key=lambda item: abs(item[1]), reverse=True)
    drivers = [
        f"{name} {'haussier' if value >= 0.20 else 'baissier' if value <= -0.20 else 'neutre'}"
        for name, value in ranked[:3]
    ]
    return {
        "available": True,
        "horizon_days": duration_days,
        "horizon_hours": int(round(24 * duration_days)),
        "bias": bias,
        "score": score,
        "conviction": conviction,
        "evidence_sufficient": evidence_sufficient,
        "forecast_probability_percent": None,
        "confidence_explanation": (
            "Aucun taux de réussite honnête ne peut être déduit de la confluence actuelle. "
            "Un pourcentage prédictif requiert des prévisions enregistrées à l’avance, "
            "une validation walk-forward avec embargo, une correction des essais multiples "
            "et un holdout final gelé. En attendant, la force de preuve est descriptive."
        ),
        "conviction_label": conviction_label,
        "support": support,
        "resistance": resistance,
        "dominant_target": dominant_target,
        "invalidation_level": invalidation_level,
        "invalidation_target": invalidation_target,
        "sigma_percent": 100.0 * sigma,
        "trigger": trigger,
        "invalidation": invalidation,
        "summary": summary,
        "drivers": drivers,
        "family_evidence": family_scores,
        "horizon_method": evidence["method"],
        "horizon_notes": evidence["notes"],
        "historical_window_complete": evidence["historical_window_complete"],
        "transformation_version": evidence["version"],
    }


def directional_scenario_table(
    features: Mapping[str, object],
    history: pd.DataFrame | None = None,
    *,
    horizon: float = 7,
) -> pd.DataFrame:
    """Return three differentiated thesis paths whose weights sum to 100."""

    thesis = directional_thesis(features, history, horizon=horizon)
    if not thesis.get("available"):
        return pd.DataFrame()
    price = float(features["spot_price"])
    sigma = float(thesis["sigma_percent"]) / 100.0
    conviction = float(thesis["conviction"]) / 100.0
    bias = str(thesis["bias"])
    dominant_weight = 42.0 + 23.0 * conviction
    range_weight = 33.0 - 8.0 * conviction
    counter_weight = 100.0 - dominant_weight - range_weight
    zone_width = max(0.0025, 0.10 * sigma)

    def zone(target: float) -> str:
        return f"${target * (1 - zone_width):,.0f} – ${target * (1 + zone_width):,.0f}"

    if bias == "CONSOLIDATION":
        dominant_weight, range_weight, counter_weight = 30.0, 45.0, 25.0
    dominant_name = f"Thèse dominante · {bias.lower()}" if bias != "CONSOLIDATION" else "Cassure haussière"
    counter_name = (
        "Invalidation · baisse" if bias == "HAUSSIER" else
        "Invalidation · hausse" if bias == "BAISSIER" else
        "Cassure baissière"
    )
    range_target = price * math.exp(float(np.clip((float(thesis["score"]) - 50.0) / 40.0, -1, 1)) * 0.12 * sigma)
    dominant_target = float(thesis["dominant_target"])
    counter_target = float(thesis["invalidation_target"])
    dominant_trigger = str(thesis["trigger"])
    dominant_invalidation = str(thesis["invalidation"])
    counter_trigger = str(thesis["invalidation"])
    if bias == "CONSOLIDATION":
        range_target = price
        dominant_target = float(thesis["resistance"])
        counter_target = float(thesis["support"])
        dominant_trigger = f"cassure confirmée au-dessus de ${dominant_target:,.0f}"
        dominant_invalidation = f"réintégration sous ${dominant_target:,.0f}"
        counter_trigger = f"cassure confirmée sous ${counter_target:,.0f}"
    return pd.DataFrame(
        [
            {
                "Scénario": dominant_name,
                "Poids de thèse": round(dominant_weight, 1),
                "Zone cible": zone(dominant_target),
                "Déclencheur": dominant_trigger,
                "Invalidation": dominant_invalidation,
            },
            {
                "Scénario": "Consolidation / prise de liquidité",
                "Poids de thèse": round(range_weight, 1),
                "Zone cible": zone(range_target),
                "Déclencheur": f"échecs répétés entre ${float(thesis['support']):,.0f} et ${float(thesis['resistance']):,.0f}",
                "Invalidation": "cassure accompagnée par les flux spot et la volatilité réalisée",
            },
            {
                "Scénario": counter_name,
                "Poids de thèse": round(counter_weight, 1),
                "Zone cible": zone(counter_target),
                "Déclencheur": counter_trigger,
                "Invalidation": "réintégration rapide du niveau de bascule avec flux opposés",
            },
        ]
    )


def gamma_exposure_summary(features: Mapping[str, object]) -> dict[str, object]:
    """Describe unsigned gamma and explicit dealer-sign bounds without inventing positioning."""
    gross = _finite(features.get("estimated_gamma_gross_usd_per_1pct_global"))
    if gross is None or gross <= 0:
        return {
            "available": False,
            "regime": "GAMMA INDISPONIBLE",
            "reliability": "INDISPONIBLE",
        }
    concentration = _finite(features.get("estimated_gamma_front_7d_near_spot_share"))
    reliable = bool(features.get("estimated_gamma_reliable", False))
    if concentration is None:
        regime = "SENSIBILITÉ NON CLASSÉE"
    elif concentration >= 0.30:
        regime = "SENSIBILITÉ GAMMA ÉLEVÉE"
    elif concentration >= 0.10:
        regime = "SENSIBILITÉ GAMMA MODÉRÉE"
    else:
        regime = "GAMMA DIFFUS"
    return {
        "available": True,
        "regime": regime,
        "gross_usd_per_1pct": gross,
        "dealer_lower_bound_usd_per_1pct": -gross,
        "dealer_upper_bound_usd_per_1pct": gross,
        "front_near_share": concentration,
        "reliability": "ESTIMATION EXPLOITABLE" if reliable else "ESTIMATION FRAGILE",
        "dealer_sign": "INCONNU",
        "dominant_strike": _finite(features.get("estimated_gamma_top_strike_1")),
        "dominant_strike_distance_pct": _finite(
            features.get("estimated_gamma_top_strike_1_distance_pct")
        ),
        "dominant_strike_share": _finite(features.get("estimated_gamma_top_strike_1_share")),
        "long_gamma_scenario": "stabilisation / rappel vers les strikes concentrés",
        "short_gamma_scenario": "accélération / mouvements plus convexes",
    }


def gamma_path_scenarios(features: Mapping[str, object]) -> pd.DataFrame:
    """Condition gamma scenarios on observable price/volatility evidence, never dealer sign."""
    summary = gamma_exposure_summary(features)
    if not summary.get("available"):
        return pd.DataFrame()
    score, _ = exploratory_direction_index(features)
    distance = _finite(summary.get("dominant_strike_distance_pct"))
    share = _finite(summary.get("dominant_strike_share"))
    front_near = _finite(summary.get("front_near_share"))
    volatility_z = _finite(features.get("realized_volatility_96_z"))
    near_peak = distance is not None and abs(distance) <= 1.5
    quiet_volatility = volatility_z is not None and volatility_z <= 0.0
    directional_pressure = abs(score - 50.0) >= 8.0
    rising_volatility = volatility_z is not None and volatility_z >= 0.5
    concentrated = (front_near or 0.0) >= 0.20 or (share or 0.0) >= 0.12
    pinning_active = near_peak and quiet_volatility and not directional_pressure
    acceleration_active = concentrated and (directional_pressure or rising_volatility)
    direction = "hausse" if score > 50 else "baisse" if score < 50 else "non définie"
    strike_text = f"{summary['dominant_strike']:,.0f}" if summary.get("dominant_strike") else "—"
    return pd.DataFrame(
        [
            {
                "Scénario observable": "Rappel / consolidation autour du strike dominant",
                "État maintenant": "COMPATIBLE" if pinning_active else "NON CONFIRMÉ",
                "Déclencheurs": f"spot à ≤1,5% du strike {strike_text}, vol réalisée non croissante, faible pression directionnelle",
                "Invalidation": "éloignement du strike + reprise de volatilité/flux",
                "Probabilité": "NON ESTIMÉE · scénario conditionnel",
            },
            {
                "Scénario observable": f"Accélération directionnelle ({direction})",
                "État maintenant": "COMPATIBLE" if acceleration_active else "NON CONFIRMÉ",
                "Déclencheurs": "gamma concentré + flux directionnels ou vol réalisée en hausse",
                "Invalidation": "retour des flux au neutre et compression de volatilité",
                "Probabilité": "NON ESTIMÉE · scénario conditionnel",
            },
        ]
    )


def forward_band_calibration(rows: pd.DataFrame, horizons: tuple[float, ...] = (1, 7, 30)) -> pd.DataFrame:
    """Track non-overlapping forward coverage of the 68% option-implied band."""
    if rows.empty or "prediction_time" not in rows or "spot_price" not in rows:
        return pd.DataFrame()
    ordered = rows.copy()
    ordered["prediction_time"] = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce", format="mixed")
    ordered["spot_price"] = pd.to_numeric(ordered["spot_price"], errors="coerce")
    if "available_time" in ordered:
        ordered["available_time"] = pd.to_datetime(ordered["available_time"], utc=True, errors="coerce", format="mixed")
    ordered = ordered.dropna(subset=["prediction_time", "spot_price"])
    if "asset" in ordered and ordered["asset"].nunique() > 1:
        raise ValueError("La calibration doit porter sur un seul actif à la fois.")
    ordered = ordered[np.isfinite(ordered["spot_price"]) & (ordered["spot_price"] > 0)].sort_values("prediction_time").drop_duplicates("prediction_time", keep="first")
    if ordered.empty:
        return pd.DataFrame()
    output: list[dict[str, object]] = []
    for horizon in horizons:
        horizon = _finite(horizon)
        if horizon is None or horizon <= 0:
            continue
        # Éviter l'arrondi en nanosecondes de 1/6 jour, qui décale une échéance exacte de 4 h.
        duration = pd.Timedelta(seconds=round(horizon * 86400, 6))
        resolved: list[bool] = []
        last_resolution: pd.Timestamp | None = None
        next_due = None
        missing_outcome = 0
        for _, origin in ordered.iterrows():
            origin_time = origin["prediction_time"]
            if pd.isna(origin_time) or (last_resolution is not None and origin_time < last_resolution):
                continue
            # Une donnée récupérée après l'origine ne peut pas créer une prévision passée.
            if "available_time" in ordered and (
                pd.isna(origin["available_time"]) or origin["available_time"] > origin_time
            ):
                continue
            scenario = implied_scenario_table(origin.to_dict(), horizons=(horizon,))
            if scenario.empty:
                continue
            target_time = origin_time + duration
            future = ordered[ordered["prediction_time"] >= target_time]
            if future.empty:
                if next_due is None or target_time < next_due:
                    next_due = target_time
                continue
            realized = future.iloc[0]
            # Do not resolve against a very distant point after a collection gap.
            if realized["prediction_time"] > target_time + min(pd.Timedelta(6, unit="h"), duration):
                missing_outcome += 1
                continue
            price = _finite(realized["spot_price"])
            if price is None:
                continue
            band = scenario.iloc[0]
            resolved.append(float(band["Zone 68% basse"]) <= price <= float(band["Zone 68% haute"]))
            # L'intervalle se termine au relevé réellement utilisé, pas à l'échéance théorique.
            last_resolution = realized["prediction_time"]
        n = len(resolved)
        if n >= 200:
            status = "CALIBRATION FORWARD MATURE"
        elif n >= 30:
            status = "CALIBRATION EXPLORATOIRE"
        else:
            status = f"COLLECTE {n}/30"
        output.append(
            {
                "Horizon": f"{horizon * 24:g}h" if horizon < 1 else f"{horizon:g}j",
                "N effectif non chevauchant": n,
                "Couverture observée zone 68%": 100.0 * float(np.mean(resolved)) if resolved else np.nan,
                "Cible théorique": 68.27,
                "Statut": status,
                "Prochaine échéance UTC": next_due.strftime("%d/%m/%Y %H:%M") if next_due is not None else "Aucune en attente",
                "Origines sans prix d’échéance proche": missing_outcome,
            }
        )
    return pd.DataFrame(output)
