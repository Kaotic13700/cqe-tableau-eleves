from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sqlite3
import uuid
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from ..storage.normalized import DDL


PUBLIC_DATA_FAMILIES = (
    "MACRO", "FED", "RATES", "ETF", "STABLECOINS", "MARKET_BREADTH",
    "SPOT", "PERPS", "OPTIONS", "LIQUIDATIONS",
)
PUBLIC_FAMILY_LOOKBACKS = {
    "SPOT": timedelta(days=2),
    "PERPS": timedelta(days=2),
    "OPTIONS": timedelta(hours=2),
    "LIQUIDATIONS": timedelta(days=1),
    "MARKET_BREADTH": timedelta(days=2),
}
_TRUE_VALUES = {"1", "true", "yes", "on"}
_VERSION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def is_public_student_mode() -> bool:
    """Return whether the dashboard must hide internal research details."""

    return os.getenv("CQE_PUBLIC_STUDENT_MODE", "").strip().lower() in _TRUE_VALUES


def resolve_latest_public_snapshot(root: str | Path) -> Path | None:
    """Resolve the immutable snapshot selected by the small mutable pointer."""

    root = Path(root)
    pointer_path = root / "latest.json"
    if not pointer_path.exists():
        return None
    try:
        pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
        version = str(pointer["version"])
    except (OSError, KeyError, json.JSONDecodeError):
        return None
    if not _VERSION_PATTERN.fullmatch(version):
        return None
    candidate = root / version / "data"
    return candidate if candidate.is_dir() else None


def _utc_timestamp(value: datetime | None) -> datetime:
    timestamp = value or datetime.now(timezone.utc)
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    return timestamp.astimezone(timezone.utc)


def _iso_z(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _copy_feature_snapshot(source: Path, target: Path, cutoff: datetime) -> tuple[str, int]:
    # Prefer the immutable 35-day snapshot.  The live cache is intentionally
    # small and cannot seed rolling features or scenario trajectories by itself.
    candidates = list((source / "features").glob("*/features.csv.gz"))
    if not candidates:
        candidates = list((source / "live").glob("*/features.csv.gz"))
    if not candidates:
        raise FileNotFoundError("Aucun snapshot de features disponible pour la publication élève.")
    latest = max(candidates, key=lambda path: path.stat().st_mtime)
    frame = pd.read_csv(latest)
    for column in ("prediction_time", "feature_available_time"):
        if column in frame:
            values = pd.to_datetime(frame[column], utc=True, format="mixed", errors="coerce")
            if values.isna().any():
                raise ValueError(f"Horodatage invalide dans {column}.")
            frame = frame.loc[values <= pd.Timestamp(cutoff)].copy()
    if frame.empty:
        raise ValueError("Le snapshot public serait vide après le contrôle point-in-time.")
    if "feature_available_time" in frame:
        available = pd.to_datetime(frame["feature_available_time"], utc=True, format="mixed")
        prediction = pd.to_datetime(frame["prediction_time"], utc=True, format="mixed")
        if (available > prediction).any():
            raise ValueError("Fuite temporelle détectée : feature_available_time > prediction_time.")

    feature_version = latest.parent.name
    target_dir = target / "features" / feature_version
    target_dir.mkdir(parents=True, exist_ok=False)
    frame.to_csv(target_dir / "features.csv.gz", index=False, compression="gzip")
    metadata_path = latest.parent / "metadata.json"
    if metadata_path.exists():
        shutil.copy2(metadata_path, target_dir / "metadata.json")
    return feature_version, len(frame)


def _copy_research_summary(source: Path, target: Path) -> str:
    pointer_path = source / "research" / "runs" / "latest.json"
    pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
    research_version = str(pointer["research_version"])
    summary_path = Path(str(pointer.get("summary_path", "")))
    if not summary_path.exists():
        summary_path = pointer_path.parent / research_version / "summary.json"
    if not summary_path.exists():
        raise FileNotFoundError("Résumé de recherche introuvable.")

    public_run = target / "research" / "runs" / research_version
    public_run.mkdir(parents=True, exist_ok=False)
    shutil.copy2(summary_path, public_run / "summary.json")
    freeze_path = summary_path.parent / "freeze_manifest.json"
    if freeze_path.exists():
        shutil.copy2(freeze_path, public_run / "freeze_manifest.json")
    _write_json(
        target / "research" / "runs" / "latest.json",
        {
            "research_version": research_version,
            "summary_path": f"research/runs/{research_version}/summary.json",
        },
    )
    return research_version


def _copy_prediction_journal(source: Path, target: Path, cutoff: datetime) -> int:
    source_path = source / "predictions" / "journal.db"
    if not source_path.exists():
        return 0
    target_path = target / "predictions" / "journal.db"
    target_path.parent.mkdir(parents=True, exist_ok=False)
    with closing(sqlite3.connect(source_path)) as source_connection, closing(
        sqlite3.connect(target_path)
    ) as target_connection:
        with target_connection:
            source_connection.backup(target_connection)
    with closing(sqlite3.connect(target_path)) as connection:
        future_count = connection.execute(
            "SELECT COUNT(*) FROM predictions WHERE julianday(prediction_timestamp) > julianday(?)",
            (_iso_z(cutoff),),
        ).fetchone()[0]
        total = connection.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
    if future_count:
        raise ValueError("Le journal contient une prédiction postérieure à la date de publication.")
    return int(total)


def _copy_public_observations(source: Path, target: Path, cutoff: datetime) -> int:
    source_path = source / "normalized" / "market.db"
    if not source_path.exists():
        return 0
    target_path = target / "normalized" / "market.db"
    target_path.parent.mkdir(parents=True, exist_ok=False)
    with closing(sqlite3.connect(source_path)) as source_connection, closing(
        sqlite3.connect(target_path)
    ) as target_connection:
        with target_connection:
            target_connection.executescript(DDL)
            row_count = 0
            for family in PUBLIC_DATA_FAMILIES:
                query = (
                    "SELECT * FROM observations WHERE data_family = ? "
                    "AND julianday(available_time) <= julianday(?)"
                )
                parameters: list[str] = [family, _iso_z(cutoff)]
                lookback = PUBLIC_FAMILY_LOOKBACKS.get(family)
                if lookback is not None:
                    query += " AND julianday(available_time) >= julianday(?)"
                    parameters.append(_iso_z(cutoff - lookback))
                query += " ORDER BY julianday(available_time)"
                rows = source_connection.execute(query, parameters).fetchall()
                if rows:
                    target_connection.executemany(
                        "INSERT INTO observations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        rows,
                    )
                    row_count += len(rows)
    return row_count


def export_public_snapshot(
    source_data_dir: str | Path,
    snapshots_root: str | Path,
    *,
    version: str | None = None,
    generated_at: datetime | None = None,
) -> Path:
    """Create one immutable, curated, point-in-time snapshot for the student app."""

    source = Path(source_data_dir).resolve()
    root = Path(snapshots_root).resolve()
    cutoff = _utc_timestamp(generated_at)
    version = version or cutoff.strftime("%Y%m%dT%H%M%SZ")
    if not _VERSION_PATTERN.fullmatch(version):
        raise ValueError("Version de snapshot invalide.")
    destination = root / version
    if destination.exists():
        raise FileExistsError(f"Le snapshot public existe déjà : {version}")

    staging = root / f".{version}.{uuid.uuid4().hex}.tmp"
    data_target = staging / "data"
    root.mkdir(parents=True, exist_ok=True)
    try:
        feature_version, feature_rows = _copy_feature_snapshot(source, data_target, cutoff)
        research_version = _copy_research_summary(source, data_target)
        prediction_rows = _copy_prediction_journal(source, data_target, cutoff)
        observation_rows = _copy_public_observations(source, data_target, cutoff)
        files = sorted(path for path in staging.rglob("*") if path.is_file())
        manifest = {
            "generated_at": _iso_z(cutoff),
            "version": version,
            "point_in_time_rule": "available_time <= generated_at",
            "included_data_families": list(PUBLIC_DATA_FAMILIES),
            "recent_family_lookback_seconds": {
                name: int(window.total_seconds()) for name, window in PUBLIC_FAMILY_LOOKBACKS.items()
            },
            "excluded": ["raw_data", "model_binaries", "experiment_registry", "internal_logs"],
            "feature_version": feature_version,
            "research_version": research_version,
            "feature_rows": feature_rows,
            "prediction_rows": prediction_rows,
            "normalized_observation_rows": observation_rows,
            "files": {
                str(path.relative_to(staging)).replace("\\", "/"): _sha256(path)
                for path in files
            },
        }
        _write_json(staging / "manifest.json", manifest)
        staging.replace(destination)
        pointer_tmp = root / ".latest.json.tmp"
        _write_json(pointer_tmp, {"version": version, "generated_at": _iso_z(cutoff)})
        pointer_tmp.replace(root / "latest.json")
        return destination
    except Exception:
        if staging.exists():
            shutil.rmtree(staging)
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Exporte un snapshot compact pour le tableau de bord élève.")
    parser.add_argument("--source", default="data", help="Répertoire de données interne.")
    parser.add_argument("--output", default="data/public_snapshots", help="Répertoire des snapshots publics.")
    parser.add_argument("--version", default=None, help="Version immuable optionnelle.")
    args = parser.parse_args(argv)
    destination = export_public_snapshot(args.source, args.output, version=args.version)
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
