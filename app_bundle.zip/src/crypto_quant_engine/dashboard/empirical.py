"""Causal empirical price envelopes for descriptive scenario stress tests."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd

from crypto_quant_engine.simulation import ConditionalBlockBootstrap


def empirical_scenario_fan(
    history: pd.DataFrame,
    *,
    asset: str,
    origin: object,
    spot_price: float,
    horizon_days: float,
    path_count: int = 600,
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Bootstrap completed 15-minute returns only, or explain why unavailable.

    Four historical horizons are required for a projected horizon. This is an
    illustrative distribution, not a trained or calibrated direction model.
    """
    unavailable: tuple[pd.DataFrame, dict[str, object]] = (pd.DataFrame(), {"available": False})
    if history.empty or not {"prediction_time", "spot_price"}.issubset(history):
        return unavailable
    start = pd.to_datetime(origin, utc=True, errors="coerce")
    if pd.isna(start) or not math.isfinite(spot_price) or spot_price <= 0 or horizon_days <= 0:
        return unavailable
    frame = history.copy()
    frame["prediction_time"] = pd.to_datetime(frame["prediction_time"], utc=True, errors="coerce", format="mixed")
    frame = frame[frame["prediction_time"].notna() & (frame["prediction_time"] <= start)]
    if "asset" in frame:
        frame = frame[frame["asset"] == asset]
    for column in ("available_time", "feature_available_time"):
        if column in frame:
            available = pd.to_datetime(frame[column], utc=True, errors="coerce", format="mixed")
            frame = frame[available.notna() & (available <= frame["prediction_time"])]
    frame["spot_price"] = pd.to_numeric(frame["spot_price"], errors="coerce")
    frame = frame[np.isfinite(frame["spot_price"]) & (frame["spot_price"] > 0)]
    frame = frame.sort_values("prediction_time").drop_duplicates("prediction_time", keep="last")
    if len(frame) < 201:
        return unavailable
    span = frame["prediction_time"].iloc[-1] - frame["prediction_time"].iloc[0]
    minimum_span = pd.Timedelta(days=max(4.0 * float(horizon_days), 3.0))
    if span < minimum_span:
        return pd.DataFrame(), {"available": False, "reason": "historique inférieur à quatre horizons"}
    seconds = frame["prediction_time"].diff().dt.total_seconds()
    cadence = seconds[seconds > 0].median()
    if pd.isna(cadence) or not 60 <= cadence <= 1800:
        return unavailable
    valid = seconds.between(0.5 * cadence, 1.5 * cadence)
    returns = frame["spot_price"].pct_change()[valid].dropna()
    expected = span.total_seconds() / cadence
    if len(returns) / expected < 0.85:
        return pd.DataFrame(), {"available": False, "reason": "trous dans les observations de prix"}
    steps = int(math.ceil(horizon_days * 86400 / cadence))
    if len(returns) < max(200, 2 * steps):
        return unavailable
    simulator = ConditionalBlockBootstrap(block_size=min(8, len(returns)), random_seed=20260919)
    paths, _ = simulator.simulate(
        returns, steps=steps, path_count=path_count,
        minimum_samples=max(200, 2 * steps),
    )
    quantiles = np.quantile(paths, [0.1, 0.16, 0.5, 0.84, 0.9], axis=0)
    dates = pd.date_range(start=start, end=start + pd.Timedelta(days=horizon_days), periods=steps + 1)
    result = pd.DataFrame({
        "Date": dates,
        "P10": np.r_[spot_price, spot_price * (1 + quantiles[0])],
        "P16": np.r_[spot_price, spot_price * (1 + quantiles[1])],
        "Médiane": np.r_[spot_price, spot_price * (1 + quantiles[2])],
        "P84": np.r_[spot_price, spot_price * (1 + quantiles[3])],
        "P90": np.r_[spot_price, spot_price * (1 + quantiles[4])],
    })
    return result, {
        "available": True,
        "path_count": path_count,
        "sample_count": len(returns),
        "history_days": round(span.total_seconds() / 86400, 1),
        "cadence_minutes": round(cadence / 60, 1),
    }
