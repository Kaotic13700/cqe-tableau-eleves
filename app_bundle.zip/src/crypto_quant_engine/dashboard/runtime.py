"""Render a page per session without mutating Python's shared import cache."""
from pathlib import Path


def execute_dashboard_page(page: Path | None = None) -> dict[str, object]:
    path = page or Path(__file__).with_name("app.py")
    namespace = {
        "__name__": "crypto_quant_engine.dashboard.app",
        "__package__": "crypto_quant_engine.dashboard",
        "__file__": str(path),
    }
    # Every Streamlit session needs its own top-level execution. Removing an
    # imported module while another session imports it raises importlib KeyError
    # and can mix session globals. A fresh namespace avoids both races.
    exec(compile(path.read_bytes(), str(path), "exec"), namespace)
    return namespace
