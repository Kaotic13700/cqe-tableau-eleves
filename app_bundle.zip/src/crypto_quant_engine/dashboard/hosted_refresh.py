from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd


MARKET_INTERVAL = timedelta(minutes=15)
MACRO_INTERVAL = timedelta(hours=1)
LOCK_MAX_AGE = timedelta(minutes=20)
_liquidation_thread: threading.Thread | None = None
_refresh_thread: threading.Thread | None = None
_refresh_guard = threading.Lock()
_poll_thread: threading.Thread | None = None
_poll_guard = threading.Lock()


def _poll_refresh(root: Path, stop: threading.Event) -> None:
    while not stop.is_set():
        try:
            schedule_hosted_refresh(root)
        except Exception:
            # A transient scheduling failure must not kill future attempts.
            pass
        if stop.wait(30):
            break


def start_hosted_polling(runtime: str | Path) -> None:
    """Keep cadence while this host is awake, independently of browser reruns."""
    global _poll_thread
    with _poll_guard:
        if _poll_thread is not None and _poll_thread.is_alive():
            return
        _poll_thread = threading.Thread(target=_poll_refresh, args=(Path(runtime), threading.Event()),
                                        name="hosted-refresh-clock", daemon=True)
        _poll_thread.start()


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _read_stamp(path: Path) -> datetime | None:
    try:
        value = datetime.fromisoformat(path.read_text(encoding="utf-8").strip().replace("Z", "+00:00"))
    except (OSError, ValueError):
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _write_stamp(path: Path, value: datetime) -> None:
    path.write_text(value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"), encoding="utf-8")


def _acquire_lock(path: Path, now: datetime) -> int | None:
    try:
        return os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        try:
            modified = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
            if now - modified > LOCK_MAX_AGE:
                path.unlink(missing_ok=True)
                return os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except OSError:
            pass
        return None


def _ensure_liquidation_listener(root: Path) -> None:
    global _liquidation_thread
    if _liquidation_thread is not None and _liquidation_thread.is_alive():
        return

    def listen() -> None:
        from crypto_quant_engine.collectors.liquidations import listen_binance_liquidations
        from crypto_quant_engine.storage import NormalizedStore, RawStore

        listen_binance_liquidations(
            RawStore(root / "raw"),
            NormalizedStore(root / "normalized" / "market.db"),
            duration_seconds=0,
        )

    _liquidation_thread = threading.Thread(
        target=listen,
        name="hosted-binance-liquidations",
        daemon=True,
    )
    _liquidation_thread.start()


def _refresh_is_due(root: Path, now: datetime) -> tuple[bool, bool, datetime | None, datetime | None]:
    last_market = _read_stamp(root / ".market_refresh_utc")
    last_daily = _read_stamp(root / ".daily_refresh_utc")
    market_due = last_market is None or now - last_market >= MARKET_INTERVAL
    daily_due = last_daily is None or last_daily.date() != now.date()
    return market_due, daily_due, last_market, last_daily


def _macro_refresh_due(root: Path, now: datetime) -> bool:
    last = _read_stamp(root / ".macro_refresh_utc")
    return last is None or now - last >= MACRO_INTERVAL


def read_hosted_refresh_status(runtime: str | Path) -> dict[str, object]:
    """Return a small, public-safe state summary for the Streamlit watchdog."""

    root = Path(runtime)
    status_path = root / "hosted_refresh_status.json"
    payload: dict[str, object] = {}
    try:
        payload = json.loads(status_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        pass
    live_files = list((root / "live").glob("*/features.csv.gz"))
    if live_files:
        latest = max(live_files, key=lambda path: path.stat().st_mtime_ns)
        payload["feature_revision"] = f"{latest.parent.name}:{latest.stat().st_mtime_ns}"
    payload["market_updated_at"] = _read_stamp(root / ".market_refresh_utc")
    payload["daily_updated_at"] = _read_stamp(root / ".daily_refresh_utc")
    payload["macro_updated_at"] = _read_stamp(root / ".macro_refresh_utc")
    return payload


def schedule_hosted_refresh(runtime: str | Path) -> dict[str, object]:
    """Start a due hosted refresh without blocking Streamlit's health checks."""

    global _refresh_thread
    root = Path(runtime)
    root.mkdir(parents=True, exist_ok=True)
    now = _utc_now()
    market_due, daily_due, last_market, last_daily = _refresh_is_due(root, now)
    if not market_due and not daily_due and not _macro_refresh_due(root, now):
        return {
            "status": "fresh",
            "market_updated_at": last_market,
            "daily_updated_at": last_daily,
        }

    with _refresh_guard:
        if _refresh_thread is not None and _refresh_thread.is_alive():
            return {"status": "refresh_in_progress"}

        def run() -> None:
            try:
                refresh_hosted_data(root)
            except Exception as exc:  # keep the curated snapshot available
                payload = {
                    "status": "degraded",
                    "checked_at": _utc_now().isoformat().replace("+00:00", "Z"),
                    "errors": [f"refresh_worker: {exc}"],
                }
                try:
                    (root / "hosted_refresh_status.json").write_text(
                        json.dumps(payload, indent=2), encoding="utf-8"
                    )
                except OSError:
                    pass

        _refresh_thread = threading.Thread(
            target=run,
            name="hosted-market-refresh",
            daemon=True,
        )
        _refresh_thread.start()
    return {"status": "scheduled"}


def _recover_hosted_spot_gap(root: Path, now: datetime) -> list[dict[str, object]]:
    """Backfill completed 15-minute spot candles and safe aggressor flow."""

    from crypto_quant_engine.collectors.historical import (
        BinanceHistoricalBackfill,
        backfill_coinbase_spot_gap,
    )
    from crypto_quant_engine.collectors.spot import CoinbaseSpotCollector
    from crypto_quant_engine.config import load_yaml
    from crypto_quant_engine.storage import NormalizedStore, RawStore

    raw = RawStore(root / "raw")
    normalized = NormalizedStore(root / "normalized" / "market.db")
    recent = normalized.query(data_family="SPOT", available_after=now - timedelta(days=35))
    exchanges = load_yaml("exchanges.yaml")["exchanges"]
    collector = CoinbaseSpotCollector(
        exchanges["coinbase"]["base_url"],
        raw,
    )
    binance_history = BinanceHistoricalBackfill(
        # Official unauthenticated market-data endpoint, not the trading API.
        spot_base_url=exchanges["binance"].get("public_spot_base_url", exchanges["binance"]["spot_base_url"]),
        futures_base_url=exchanges["binance"]["futures_base_url"],
        raw_store=raw,
        normalized_store=normalized,
        max_attempts=3,
        request_pause_seconds=0,
    )
    reports: list[dict[str, object]] = []
    for asset in ("BTC", "ETH"):
        asset_rows = recent[recent["asset"] == asset] if not recent.empty else recent
        if asset_rows.empty:
            start = now - timedelta(days=2)
        else:
            latest = pd.to_datetime(asset_rows["event_time"], utc=True, errors="coerce").max()
            if pd.isna(latest):
                start = now - timedelta(days=2)
            else:
                start = pd.Timestamp(latest).to_pydatetime()
        if now - start > timedelta(minutes=30):
            try:
                report = backfill_coinbase_spot_gap(
                    collector.get_json,
                    normalized,
                    asset=asset,
                    start=start,
                    end=now,
                )
                reports.append({"source": "coinbase", **report.__dict__})
            except Exception as exc:
                reports.append(
                    {
                        "source": "coinbase",
                        "asset": asset,
                        "status": "ERROR",
                        "inserted": 0,
                        "error": str(exc),
                    }
                )
        try:
            # The backfill object resumes from its own append-only revision.
            # Requesting 35 days restores every gap relevant to the live cache,
            # while completed-bar availability prevents look-ahead leakage.
            report = binance_history.backfill(
                asset=asset,
                data_family="SPOT",
                start=now - timedelta(days=35),
                end=now,
            )
            reports.append({"source": "binance", **report.to_dict()})
        except Exception as exc:
            reports.append(
                {
                    "source": "binance",
                    "asset": asset,
                    "status": "ERROR",
                    "inserted": 0,
                    "error": str(exc),
                }
            )
    return reports


def refresh_hosted_data(runtime: str | Path) -> dict[str, object]:
    """Refresh a hosted student cache without requiring the teacher's PC.

    Market sources are refreshed at most every 15 minutes; official economics
    hourly, and daily fund flows once per UTC day. A stale published snapshot is
    always preferred to a fabricated replacement when a source is unavailable.
    """

    root = Path(runtime)
    root.mkdir(parents=True, exist_ok=True)
    _ensure_liquidation_listener(root)
    now = _utc_now()
    market_stamp = root / ".market_refresh_utc"
    daily_stamp = root / ".daily_refresh_utc"
    macro_stamp = root / ".macro_refresh_utc"
    lock_path = root / ".refresh.lock"
    status_path = root / "hosted_refresh_status.json"
    market_due, daily_due, last_market, last_daily = _refresh_is_due(root, now)
    macro_due = _macro_refresh_due(root, now)
    if not market_due and not daily_due and not macro_due:
        return {"status": "fresh", "market_updated_at": last_market, "daily_updated_at": last_daily}

    lock_fd = _acquire_lock(lock_path, now)
    if lock_fd is None:
        return {"status": "refresh_in_progress"}
    os.close(lock_fd)
    updated = False
    errors: list[str] = []
    gap_reports: list[dict[str, object]] = []
    try:
        # Import only after CQE_DATA_DIR points to the writable runtime cache.
        from crypto_quant_engine.cli import collect_command, features_live_command

        if market_due:
            try:
                gap_reports = _recover_hosted_spot_gap(root, now)
                updated = updated or any(int(report.get("inserted", 0)) > 0 for report in gap_reports)
                errors.extend(
                    f"gap_backfill[{report.get('source')}/{report.get('asset')}]: {report.get('error')}"
                    for report in gap_reports
                    if report.get("status") == "ERROR"
                )
            except Exception as exc:
                errors.append(f"gap_backfill: {exc}")

        if macro_due:
            try:
                code = collect_command(["macro", "fed"])
                if code != 0:
                    raise RuntimeError(f"economic collectors returned {code}")
                _write_stamp(macro_stamp, _utc_now())
                updated = True
            except Exception as exc:
                errors.append(f"economics: {exc}")
        if daily_due:
            try:
                code = collect_command(["etf", "stablecoins", "breadth"])
                if code != 0:
                    raise RuntimeError(f"daily collectors returned {code}")
                _write_stamp(daily_stamp, now)
                updated = True
            except Exception as exc:  # stale snapshot remains usable
                errors.append(f"daily: {exc}")
        if market_due:
            try:
                code = collect_command(["spot", "perps", "options", "cme"])
                if code != 0:
                    raise RuntimeError(f"market collectors returned {code}")
                _write_stamp(market_stamp, now)
                updated = True
            except Exception as exc:  # stale snapshot remains usable
                errors.append(f"market: {exc}")
        if updated:
            try:
                features_live_command()
            except Exception as exc:
                errors.append(f"features: {exc}")
        payload = {
            "status": "degraded" if errors else "updated" if updated else "stale",
            "checked_at": now.isoformat().replace("+00:00", "Z"),
            "market_refresh_interval_minutes": 15,
            "macro_refresh_interval_minutes": 60,
            "daily_refresh_utc_date": now.date().isoformat(),
            "gap_backfill": gap_reports,
            "errors": errors,
        }
        status_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return payload
    finally:
        lock_path.unlink(missing_ok=True)
