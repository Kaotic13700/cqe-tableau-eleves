from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd


OFFICIAL_SERIES_URLS = {
    "GDPC1": "https://fred.stlouisfed.org/series/GDPC1",
    "PCEPILFE": "https://fred.stlouisfed.org/series/PCEPILFE",
    "PCEPI": "https://fred.stlouisfed.org/series/PCEPI",
    "CPIAUCSL": "https://fred.stlouisfed.org/series/CPIAUCSL",
    "CPILFESL": "https://fred.stlouisfed.org/series/CPILFESL",
    "PPIFID": "https://fred.stlouisfed.org/series/PPIFID",
    "UNRATE": "https://fred.stlouisfed.org/series/UNRATE",
    "PAYEMS": "https://fred.stlouisfed.org/series/PAYEMS",
    "ICSA": "https://fred.stlouisfed.org/series/ICSA",
    "WALCL/WTREGEN/RRPONTSYD": "https://fred.stlouisfed.org/series/WALCL",
    "DFF": "https://fred.stlouisfed.org/series/DFF",
    "CLVMNACSCAB1GQEA": "https://fred.stlouisfed.org/series/CLVMNACSCAB1GQEA",
    "CP0000EZ19M086NEST": "https://fred.stlouisfed.org/series/CP0000EZ19M086NEST",
    "EURO_AREA_HICP_YOY": "https://ec.europa.eu/eurostat/databrowser/view/prc_hicp_minr/default/table?lang=en",
    "EA19MABMM301GYSAM": "https://fred.stlouisfed.org/series/EA19MABMM301GYSAM",
    "ECBDFR": "https://fred.stlouisfed.org/series/ECBDFR",
    "JPNRGDPEXP": "https://fred.stlouisfed.org/series/JPNRGDPEXP",
    "JAPAN_CPI_HEADLINE_YOY": "https://www.stat.go.jp/english/data/cpi/",
    "JPNMABMM301GYSAM": "https://www.boj.or.jp/en/statistics/money/ms/index.htm",
    "IRSTCI01JPM156N": "https://fred.stlouisfed.org/series/IRSTCI01JPM156N",
    "ECB_M3_YOY": "https://data.ecb.europa.eu/data/datasets/BSI",
    "BOJ_M3_YOY": "https://www.boj.or.jp/en/statistics/money/ms/index.htm",
    "BOJ_CALL_RATE": "https://www.boj.or.jp/en/statistics/market/short/mutan/index.htm",
}

MACRO_FRESHNESS_DAYS = {"growth": 160, "inflation": 70, "liquidity": 70, "policy": 70}
CME_FRESHNESS_DAYS = 7  # Garde opérationnelle, non seuil prédictif calibré.


def _finite(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _history_series(row: pd.Series) -> pd.Series:
    history = row.get("value.history_tail")
    if not isinstance(history, list) or not history:
        return pd.Series(dtype=float)
    frame = pd.DataFrame(history)
    if not {"event_time", "value"}.issubset(frame.columns):
        return pd.Series(dtype=float)
    frame["event_time"] = pd.to_datetime(frame["event_time"], utc=True, errors="coerce")
    frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    return frame.dropna().drop_duplicates("event_time", keep="last").set_index("event_time")["value"].sort_index()


def _asof(series: pd.Series, when: pd.Timestamp) -> float | None:
    if series.empty:
        return None
    eligible = series[series.index <= when]
    return _finite(eligible.iloc[-1]) if not eligible.empty else None


def _observation_time(series: pd.Series, when: pd.Timestamp) -> pd.Timestamp | None:
    if series.empty:
        return None
    eligible = series[series.index <= when]
    return pd.Timestamp(eligible.index[-1]) if not eligible.empty else None


def _newest_series(series: dict[str, pd.Series], primary: str, fallback: str) -> tuple[str, pd.Series]:
    """Privilégie l'autorité officielle si sa période est au moins aussi récente."""
    current = series.get(primary, pd.Series(dtype=float))
    legacy = series.get(fallback, pd.Series(dtype=float))
    if not current.empty and (legacy.empty or current.index.max() >= legacy.index.max()):
        return primary, current
    return fallback, legacy


def _period_end(observed: pd.Timestamp, *, dimension: str, series_id: str) -> pd.Timestamp:
    """Les dates mensuelles/trimestrielles désignent le début de période, pas sa fin."""
    monthly = {"PCEPILFE", "PCEPI", "CPIAUCSL", "CPILFESL", "PPIFID", "UNRATE", "PAYEMS",
               "EURO_AREA_HICP_YOY", "CP0000EZ19M086NEST",
               "JAPAN_CPI_HEADLINE_YOY", "ECB_M3_YOY", "EA19MABMM301GYSAM",
               "BOJ_M3_YOY", "JPNMABMM301GYSAM", "IRSTCI01JPM156N"}
    quarterly = {"GDPC1", "CLVMNACSCAB1GQEA", "JPNRGDPEXP"}
    if series_id in quarterly and dimension == "growth":
        return observed + pd.offsets.QuarterEnd(startingMonth=3)
    if series_id in monthly:
        return observed + pd.offsets.MonthEnd()
    return observed


def _pct_change(series: pd.Series, when: pd.Timestamp, days: int) -> float | None:
    current = _asof(series, when)
    observed = _observation_time(series, when)
    if observed is None:
        return None
    offset = pd.DateOffset(years=1) if days == 365 else pd.DateOffset(months=3) if days == 92 else pd.Timedelta(int(days), unit="D")
    previous = _asof(series, observed - offset)
    if current is None or previous is None or previous == 0:
        return None
    return 100.0 * (current / previous - 1.0)


def _delta(series: pd.Series, when: pd.Timestamp, days: int) -> float | None:
    current = _asof(series, when)
    observed = _observation_time(series, when)
    if observed is None:
        return None
    offset = pd.DateOffset(months=3) if days == 92 else pd.Timedelta(int(days), unit="D")
    previous = _asof(series, observed - offset)
    return current - previous if current is not None and previous is not None else None


def _yoy(series: pd.Series, when: pd.Timestamp) -> float | None:
    observed = _observation_time(series, when)
    if observed is None:
        return None
    # An annual inflation rate requires the matching period, not an arbitrarily
    # older available observation if the comparison month is missing.
    previous = _finite(series.get(observed - pd.DateOffset(years=1)))
    current = _asof(series, observed)
    return 100.0 * (current / previous - 1.0) if current is not None and previous not in (None, 0) else None


def _clip_signal(value: float | None, scale: float, invert: bool = False) -> float | None:
    if value is None:
        return None
    sign = -1.0 if invert else 1.0
    return float(np.clip(sign * value / scale, -1.0, 1.0))


def _state_at(series: dict[str, pd.Series], when: pd.Timestamp) -> dict[str, Any]:
    unemployment_change = _delta(series.get("UNRATE", pd.Series(dtype=float)), when, 92)
    core_pce_yoy = _yoy(series.get("PCEPILFE", pd.Series(dtype=float)), when)
    pce_series = series.get("PCEPILFE", pd.Series(dtype=float))
    pce_observed = _observation_time(pce_series, when)
    core_pce_yoy_prior = _yoy(pce_series, pce_observed - pd.DateOffset(months=3)) if pce_observed is not None else None
    inflation_impulse = (
        core_pce_yoy - core_pce_yoy_prior
        if core_pce_yoy is not None and core_pce_yoy_prior is not None
        else None
    )
    dff_change = _delta(series.get("DFF", pd.Series(dtype=float)), when, 92)
    two_year = _asof(series.get("DGS2", pd.Series(dtype=float)), when)
    ten_year = _asof(series.get("DGS10", pd.Series(dtype=float)), when)
    curve = ten_year - two_year if two_year is not None and ten_year is not None else None

    walcl = series.get("WALCL", pd.Series(dtype=float))
    tga = series.get("WTREGEN", pd.Series(dtype=float))
    rrp = series.get("RRPONTSYD", pd.Series(dtype=float))

    def net_liquidity(date: pd.Timestamp) -> float | None:
        balance_sheet = _asof(walcl, date)
        treasury = _asof(tga, date)
        reverse_repo = _asof(rrp, date)
        if None in {balance_sheet, treasury, reverse_repo}:
            return None
        # WALCL and WTREGEN are USD millions; RRPONTSYD is USD billions.
        return float(balance_sheet - treasury - 1000.0 * reverse_repo)

    net_now = net_liquidity(when)
    net_prior = net_liquidity(when - pd.Timedelta(92, unit="D"))
    liquidity_change = (
        100.0 * (net_now / net_prior - 1.0)
        if net_now is not None and net_prior not in {None, 0.0}
        else None
    )

    growth_signal = _clip_signal(unemployment_change, 0.40, invert=True)
    inflation_signal = _clip_signal(inflation_impulse, 0.50, invert=True)
    liquidity_signal = _clip_signal(liquidity_change, 2.0)
    policy_signal = _clip_signal(dff_change, 0.50, invert=True)
    signals = [value for value in (growth_signal, inflation_signal, liquidity_signal, policy_signal) if value is not None]
    macro_signal = float(np.mean(signals)) if signals else None

    def growth_label() -> str:
        if unemployment_change is None:
            return "INDISPONIBLE"
        if unemployment_change >= 0.20:
            return "RALENTISSEMENT"
        if unemployment_change <= -0.20:
            return "AMÉLIORATION"
        return "STABLE"

    def inflation_label() -> str:
        if core_pce_yoy is None:
            return "INDISPONIBLE"
        if inflation_impulse is not None and inflation_impulse <= -0.20:
            return "REFROIDISSEMENT"
        if core_pce_yoy >= 3.0:
            return "ÉLEVÉE / PERSISTANTE"
        return "STABLE / MODÉRÉE"

    def liquidity_label() -> str:
        if liquidity_change is None:
            return "INDISPONIBLE"
        if liquidity_change >= 1.0:
            return "EXPANSION"
        if liquidity_change <= -1.0:
            return "CONTRACTION"
        return "STABLE"

    def policy_label() -> str:
        if dff_change is None:
            return "INDISPONIBLE"
        if dff_change <= -0.25:
            return "ASSOUPLISSEMENT"
        if dff_change >= 0.25:
            return "RESSERREMENT"
        return "PAUSE"

    return {
        "region": "US",
        "region_label": "États-Unis",
        "central_bank": "Réserve fédérale (Fed)",
        "date": when,
        "growth_label": growth_label(),
        "growth_signal": growth_signal,
        "unemployment_3m_change_pp": unemployment_change,
        "inflation_label": inflation_label(),
        "inflation_signal": inflation_signal,
        "core_pce_yoy_pct": core_pce_yoy,
        "core_pce_yoy_3m_impulse_pp": inflation_impulse,
        "liquidity_label": liquidity_label(),
        "liquidity_signal": liquidity_signal,
        "net_liquidity_3m_change_pct": liquidity_change,
        "policy_label": policy_label(),
        "policy_signal": policy_signal,
        "fed_funds_3m_change_pp": dff_change,
        "yield_curve_10y_2y_pp": curve,
        "macro_signal": macro_signal,
    }


def _regional_state(series: dict[str, pd.Series], region: str, when: pd.Timestamp) -> dict[str, Any]:
    if region == "US":
        state = _state_at(series, when)
        gdp_yoy = _pct_change(series.get("GDPC1", pd.Series(dtype=float)), when, 365)
        m2_3m = _pct_change(series.get("M2SL", pd.Series(dtype=float)), when, 92)
        state.update(
            {
                "growth_value_pct": gdp_yoy,
                "growth_measure": "PIB réel américain · variation annuelle",
                "growth_series_id": "GDPC1",
                "growth_observation_time": _observation_time(series.get("GDPC1", pd.Series(dtype=float)), when),
                "growth_source_url": OFFICIAL_SERIES_URLS["GDPC1"],
                "inflation_value_pct": state.get("core_pce_yoy_pct"),
                "inflation_measure": "PCE sous-jacente américaine · variation annuelle",
                "inflation_series_id": "PCEPILFE",
                "inflation_observation_time": _observation_time(series.get("PCEPILFE", pd.Series(dtype=float)), when),
                "inflation_source_url": OFFICIAL_SERIES_URLS["PCEPILFE"],
                "liquidity_value_pct": state.get("net_liquidity_3m_change_pct"),
                "liquidity_secondary_pct": m2_3m,
                "liquidity_measure": "Liquidité nette Fed/Trésor · variation 3 mois",
                "liquidity_series_id": "WALCL − WTREGEN − RRPONTSYD",
                "liquidity_observation_time": min(
                    (
                        value
                        for value in (
                            _observation_time(series.get("WALCL", pd.Series(dtype=float)), when),
                            _observation_time(series.get("WTREGEN", pd.Series(dtype=float)), when),
                            _observation_time(series.get("RRPONTSYD", pd.Series(dtype=float)), when),
                        )
                        if value is not None
                    ),
                    default=None,
                ),
                "liquidity_source_url": OFFICIAL_SERIES_URLS["WALCL/WTREGEN/RRPONTSYD"],
                "policy_value_pct": _asof(series.get("DFF", pd.Series(dtype=float)), when),
                "policy_measure": "Taux effectif des fonds fédéraux",
                "policy_series_id": "DFF",
                "policy_observation_time": _observation_time(series.get("DFF", pd.Series(dtype=float)), when),
                "policy_source_url": OFFICIAL_SERIES_URLS["DFF"],
            }
        )
        if gdp_yoy is not None:
            state["growth_signal"] = _clip_signal(gdp_yoy, 3.0)
            state["growth_label"] = "EXPANSION" if gdp_yoy >= 1.0 else "RALENTISSEMENT" if gdp_yoy < 0 else "FAIBLE"
        signals = [
            state.get(name)
            for name in ("growth_signal", "inflation_signal", "liquidity_signal", "policy_signal")
            if state.get(name) is not None
        ]
        state["macro_signal"] = float(np.mean(signals)) if signals else None
        return state

    if region == "EURO_AREA":
        region_label = "Zone euro"
        central_bank = "Banque centrale européenne (BCE)"
        growth_series = series.get("CLVMNACSCAB1GQEA", pd.Series(dtype=float))
        inflation_series_id = "EURO_AREA_HICP_YOY" if "EURO_AREA_HICP_YOY" in series else "CP0000EZ19M086NEST"
        inflation_series = series.get(inflation_series_id, pd.Series(dtype=float))
        liquidity_series_id, money_series = _newest_series(series, "ECB_M3_YOY", "EA19MABMM301GYSAM")
        policy_series = series.get("ECBDFR", pd.Series(dtype=float))
        inflation_measure = "Inflation harmonisée de la zone euro · variation annuelle"
        liquidity_measure = "M3 zone euro · croissance annuelle"
        policy_measure = "Taux de dépôt de la BCE"
        growth_measure = "PIB réel de la zone euro · variation annuelle"
        growth_series_id = "CLVMNACSCAB1GQEA"
        policy_series_id = "ECBDFR"
    elif region == "JAPAN":
        region_label = "Japon"
        central_bank = "Banque du Japon (BoJ)"
        growth_series = series.get("JPNRGDPEXP", pd.Series(dtype=float))
        inflation_series = series.get("JAPAN_CPI_HEADLINE_YOY", pd.Series(dtype=float))
        liquidity_series_id, money_series = _newest_series(series, "BOJ_M3_YOY", "JPNMABMM301GYSAM")
        policy_series_id, policy_series = _newest_series(series, "BOJ_CALL_RATE", "IRSTCI01JPM156N")
        inflation_measure = "Inflation générale du Japon · variation annuelle"
        liquidity_measure = "M3 Japon · croissance annuelle"
        policy_measure = "Taux au jour le jour japonais · BoJ" if policy_series_id == "BOJ_CALL_RATE" else "Taux au jour le jour japonais · proxy BoJ"
        growth_measure = "PIB réel du Japon · variation annuelle"
        growth_series_id = "JPNRGDPEXP"
        inflation_series_id = "JAPAN_CPI_HEADLINE_YOY"
    else:
        raise ValueError(f"unsupported macro region: {region}")

    growth_yoy = _pct_change(growth_series, when, 365)
    rate_series = inflation_series_id in {"JAPAN_CPI_HEADLINE_YOY", "EURO_AREA_HICP_YOY"}
    inflation_yoy = _asof(inflation_series, when) if rate_series else _yoy(inflation_series, when)
    inflation_yoy_prior = (
        None
        if region == "JAPAN"
        else _asof(inflation_series, _observation_time(inflation_series, when) - pd.DateOffset(months=3))
        if rate_series and _observation_time(inflation_series, when) is not None
        else _yoy(inflation_series, when - pd.Timedelta(92, unit="D"))
    )
    inflation_impulse = (
        inflation_yoy - inflation_yoy_prior
        if inflation_yoy is not None and inflation_yoy_prior is not None
        else None
    )
    broad_money_yoy = _asof(money_series, when)
    policy_value = _asof(policy_series, when)
    policy_change = _delta(policy_series, when, 92)
    growth_signal = _clip_signal(growth_yoy, 3.0)
    inflation_signal = (
        _clip_signal(inflation_impulse, 0.50, invert=True)
        if inflation_impulse is not None
        else float(np.clip((2.0 - inflation_yoy) / 2.0, -1.0, 1.0)) if inflation_yoy is not None else None
    )
    liquidity_signal = _clip_signal(broad_money_yoy, 5.0)
    policy_signal = _clip_signal(policy_change, 0.50, invert=True)
    signals = [value for value in (growth_signal, inflation_signal, liquidity_signal, policy_signal) if value is not None]

    def growth_label() -> str:
        if growth_yoy is None:
            return "INDISPONIBLE"
        if growth_yoy >= 1.0:
            return "EXPANSION"
        if growth_yoy < 0:
            return "CONTRACTION"
        return "CROISSANCE FAIBLE"

    def inflation_label() -> str:
        if inflation_yoy is None:
            return "INDISPONIBLE"
        if inflation_yoy >= 3.0:
            return "ÉLEVÉE"
        if inflation_yoy < 1.0:
            return "FAIBLE"
        return "PROCHE DE LA CIBLE"

    def liquidity_label() -> str:
        if broad_money_yoy is None:
            return "INDISPONIBLE"
        if broad_money_yoy >= 3.0:
            return "EXPANSION"
        if broad_money_yoy < 0:
            return "CONTRACTION"
        return "EXPANSION MODESTE"

    def policy_label() -> str:
        if policy_value is None:
            return "INDISPONIBLE"
        if policy_change is not None and policy_change <= -0.10:
            return "ASSOUPLISSEMENT"
        if policy_change is not None and policy_change >= 0.10:
            return "RESSERREMENT"
        return "STABLE"

    return {
        "region": region,
        "region_label": region_label,
        "central_bank": central_bank,
        "date": when,
        "growth_label": growth_label(),
        "growth_signal": growth_signal,
        "growth_value_pct": growth_yoy,
        "growth_measure": growth_measure,
        "growth_series_id": growth_series_id,
        "growth_observation_time": _observation_time(growth_series, when),
        "growth_source_url": OFFICIAL_SERIES_URLS[growth_series_id],
        "inflation_label": inflation_label(),
        "inflation_signal": inflation_signal,
        "inflation_value_pct": inflation_yoy,
        "inflation_impulse_pp": inflation_impulse,
        "inflation_measure": inflation_measure,
        "inflation_series_id": inflation_series_id,
        "inflation_observation_time": _observation_time(inflation_series, when),
        "inflation_source_url": OFFICIAL_SERIES_URLS[inflation_series_id],
        "liquidity_label": liquidity_label(),
        "liquidity_signal": liquidity_signal,
        "liquidity_value_pct": broad_money_yoy,
        "liquidity_measure": liquidity_measure,
        "liquidity_series_id": liquidity_series_id,
        "liquidity_observation_time": _observation_time(money_series, when),
        "liquidity_source_url": OFFICIAL_SERIES_URLS[liquidity_series_id],
        "policy_label": policy_label(),
        "policy_signal": policy_signal,
        "policy_value_pct": policy_value,
        "policy_change_3m_pp": policy_change,
        "policy_measure": policy_measure,
        "policy_series_id": policy_series_id,
        "policy_observation_time": _observation_time(policy_series, when),
        "policy_source_url": OFFICIAL_SERIES_URLS[policy_series_id],
        "macro_signal": float(np.mean(signals)) if signals else None,
    }


def _apply_current_freshness(state: dict[str, Any], now: pd.Timestamp) -> dict[str, Any]:
    """Keep published values visible, but exclude stale dimensions from live direction."""
    for dimension, maximum_days in MACRO_FRESHNESS_DAYS.items():
        observed = state.get(f"{dimension}_observation_time")
        timestamp = pd.Timestamp(observed) if observed is not None else None
        if timestamp is not None and timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        if timestamp is not None and not pd.isna(timestamp) and timestamp <= now:
            timestamp = _period_end(timestamp, dimension=dimension,
                                    series_id=str(state.get(f"{dimension}_series_id", "")))
        # Une date invalide ou future ne constitue pas une observation fraîche.
        stale = pd.isna(timestamp) or timestamp > now or (now - timestamp) > pd.Timedelta(maximum_days, unit="D")
        state[f"{dimension}_stale"] = stale
        if stale:
            state[f"{dimension}_signal"] = None
    live_signals = [
        state.get(f"{dimension}_signal")
        for dimension in MACRO_FRESHNESS_DAYS
        if state.get(f"{dimension}_signal") is not None
    ]
    state["macro_signal"] = float(np.mean(live_signals)) if live_signals else None
    return state


def _apply_us_release_bias(state: dict[str, Any], series: dict[str, pd.Series], now: pd.Timestamp) -> None:
    """Ajoute les dernières publications US au biais courant, sans modifier l'historique.

    Les coefficients ci-dessous sont des repères descriptifs bornés, non des
    paramètres entraînés ni des probabilités. Chaque famille est agrégée une
    seule fois afin de limiter le double comptage CPI/PCE et emploi.
    """
    releases: list[dict[str, Any]] = []
    by_family: dict[str, list[float]] = {"emploi": [], "cpi": [], "pce": [], "ppi": []}
    specifications = (
        ("UNRATE", "emploi", 45, "Taux de chômage", "pct"),
        ("PAYEMS", "emploi", 45, "Emplois non agricoles · variation mensuelle", "thousands"),
        ("ICSA", "emploi", 14, "Demandes initiales chômage", "persons"),
        ("CPIAUCSL", "cpi", 45, "IPC général · variation annuelle", "yoy"),
        ("CPILFESL", "cpi", 45, "IPC sous-jacent · variation annuelle", "yoy"),
        ("PCEPI", "pce", 70, "PCE général · variation annuelle", "yoy"),
        ("PCEPILFE", "pce", 70, "PCE sous-jacent · variation annuelle", "yoy"),
        ("PPIFID", "ppi", 45, "Prix producteurs finaux · variation annuelle", "yoy"),
    )
    for identifier, family, max_age, label, unit in specifications:
        values = series.get(identifier, pd.Series(dtype=float))
        observed = _observation_time(values, now)
        period_end = _period_end(observed, dimension="inflation", series_id=identifier) if observed is not None else None
        fresh = bool(period_end is not None and period_end <= now and
                     now - period_end <= pd.Timedelta(max_age, unit="D"))
        latest = _asof(values, now)
        metric = _yoy(values, now) if unit == "yoy" else latest
        if identifier == "PAYEMS":
            previous = _asof(values, observed - pd.DateOffset(months=1)) if observed is not None else None
            metric = latest - previous if latest is not None and previous is not None else None
        contribution: float | None = None
        if fresh:
            if identifier == "UNRATE":
                contribution = _clip_signal(_delta(values, now, 92), 0.40, invert=True)
            elif identifier == "PAYEMS":
                contribution = _clip_signal(_delta(values, now, 92), 450.0)
            elif identifier == "ICSA":
                contribution = _clip_signal(_delta(values, now, 28), 40000.0, invert=True)
            elif family in {"cpi", "pce", "ppi"} and observed is not None:
                prior_yoy = _yoy(values, observed - pd.DateOffset(months=3))
                impulse = metric - prior_yoy if metric is not None and prior_yoy is not None else None
                contribution = _clip_signal(impulse, 1.0 if family == "ppi" else 0.50, invert=True)
        if contribution is not None:
            by_family[family].append(contribution)
        releases.append({
            "series_id": identifier, "family": family, "label": label,
            "period": observed, "value": metric, "unit": unit,
            "fresh": fresh, "contribution": contribution,
            "source_url": OFFICIAL_SERIES_URLS[identifier],
        })

    # L'emploi constitue un seul pilier ; CPI, PCE et PPI ne sont pas
    # comptés comme trois dimensions indépendantes dans l'inflation.
    if by_family["emploi"]:
        state["growth_signal"] = float(np.mean(by_family["emploi"]))
        state["growth_label"] = "MARCHÉ DE L'EMPLOI · SIGNAL MIXTE" if abs(state["growth_signal"]) < 0.20 else (
            "MARCHÉ DE L'EMPLOI · SOUTIEN" if state["growth_signal"] > 0 else "MARCHÉ DE L'EMPLOI · FRAGILITÉ"
        )
        payroll = next((item for item in releases if item["series_id"] == "PAYEMS" and item["fresh"]), None)
        unemployment = next((item for item in releases if item["series_id"] == "UNRATE" and item["fresh"]), None)
        if payroll is not None:
            state["growth_value_pct"] = _pct_change(series["PAYEMS"], now, 365)
            state["growth_measure"] = "Emploi non agricole · variation annuelle (biais composite emploi)"
            state["growth_series_id"] = "PAYEMS"
            state["growth_observation_time"] = payroll["period"]
            state["growth_source_url"] = payroll["source_url"]
        elif unemployment is not None:
            state["growth_value_pct"] = unemployment["value"]
            state["growth_measure"] = "Taux de chômage (biais composite emploi)"
            state["growth_series_id"] = "UNRATE"
            state["growth_observation_time"] = unemployment["period"]
            state["growth_source_url"] = unemployment["source_url"]
        else:
            claims = next(item for item in releases if item["series_id"] == "ICSA" and item["fresh"])
            state["growth_value_pct"] = _pct_change(series["ICSA"], now, 28)
            state["growth_measure"] = "Demandes initiales chômage · variation 4 semaines"
            state["growth_series_id"] = "ICSA"
            state["growth_observation_time"] = claims["period"]
            state["growth_source_url"] = claims["source_url"]
        state["growth_stale"] = False
    inflation_families = [float(np.mean(by_family[name])) for name in ("cpi", "pce", "ppi") if by_family[name]]
    if inflation_families:
        state["inflation_signal"] = float(np.mean(inflation_families))
        state["inflation_label"] = "PRESSIONS DE PRIX · MIXTES" if abs(state["inflation_signal"]) < 0.20 else (
            "PRESSIONS DE PRIX · DÉTENTE" if state["inflation_signal"] > 0 else "PRESSIONS DE PRIX · ACCÉLÉRATION"
        )
    state["us_releases"] = releases
    live = [state.get(f"{dimension}_signal") for dimension in MACRO_FRESHNESS_DAYS]
    live = [value for value in live if value is not None]
    state["macro_signal"] = float(np.mean(live)) if live else None


def build_macro_context(observations: pd.DataFrame, now: pd.Timestamp | None = None) -> dict[str, Any]:
    now = pd.Timestamp.now(tz="UTC") if now is None else pd.Timestamp(now)
    if now.tzinfo is None:
        now = now.tz_localize("UTC")
    if observations.empty:
        return {"available": False, "history": pd.DataFrame()}
    if "available_time" not in observations:
        return {"available": False, "history": pd.DataFrame()}
    availability = pd.to_datetime(observations["available_time"], utc=True, errors="coerce", format="mixed")
    frame = observations.loc[availability <= now].copy()
    # Tri chronologique réel, y compris avec des précisions/fuseaux différents.
    frame["available_time"] = availability.loc[frame.index]
    frame = frame.sort_values("available_time")
    if frame.empty:
        return {"available": False, "history": pd.DataFrame()}
    macro = frame[frame["data_family"] == "MACRO"].drop_duplicates("instrument", keep="last")
    series = {str(row["instrument"]): _history_series(row) for _, row in macro.iterrows()}
    series = {name: values for name, values in series.items() if not values.empty}
    regions: dict[str, dict[str, Any]] = {}
    if series:
        latest_event = max(values.index.max() for values in series.values())
        state_time = min(now, latest_event)
        regions = {
            region: _apply_current_freshness(_regional_state(series, region, state_time), now)
            for region in ("US", "EURO_AREA", "JAPAN")
        }
        _apply_us_release_bias(regions["US"], series, now)
        for region, state in regions.items():
            instrument = state.get("inflation_series_id")
            matching = macro[macro["instrument"] == instrument]
            if not matching.empty:
                row = matching.iloc[-1]
                state["inflation_checked_time"] = row.get("received_time", row.get("available_time"))
                state["inflation_publication_time"] = row.get("value.publication_time")
                state["inflation_publication_date"] = row.get("value.publication_date")
                state["inflation_source_updated_time"] = row.get("value.source_updated_time")
                status = row.get("value.release_status")
                state["inflation_status"] = status if isinstance(status, str) else "PUBLISHED"
            state["inflation_calendar_url"] = {
                "US": "https://www.bea.gov/news/schedule/full",
                "JAPAN": "https://www.stat.go.jp/english/data/cpi/1582.htm",
                "EURO_AREA": "https://ec.europa.eu/eurostat/news/release-calendar",
            }[region]
        current = dict(regions["US"])
        region_macro_signals = [item.get("macro_signal") for item in regions.values() if item.get("macro_signal") is not None]
        current["macro_signal"] = float(np.mean(region_macro_signals)) if region_macro_signals else None
        first = max(values.index.min() for values in series.values() if values.index.min() is not pd.NaT)
        month_ends = pd.date_range(first, min(now, latest_event), freq="ME", tz="UTC")
        history_rows = [_state_at(series, date) for date in month_ends]
        history = pd.DataFrame(history_rows)
    else:
        current = {
            "date": now,
            "growth_label": "INDISPONIBLE",
            "inflation_label": "INDISPONIBLE",
            "liquidity_label": "INDISPONIBLE",
            "policy_label": "INDISPONIBLE",
            "macro_signal": None,
        }
        history = pd.DataFrame()

    cme = frame[frame["data_family"] == "RATES"].tail(1)
    cme_values: dict[str, Any] | None = None
    cme_signal = None
    if not cme.empty:
        row = cme.iloc[-1]
        ease = _finite(row.get("value.ease_probability"))
        hike = _finite(row.get("value.hike_probability"))
        unchanged = _finite(row.get("value.unchanged_probability"))
        available_at = pd.to_datetime(row.get("available_time"), utc=True, errors="coerce")
        meeting_at = pd.to_datetime(row.get("value.meeting_date"), utc=True, errors="coerce")
        fresh = bool(
            pd.notna(available_at)
            and pd.notna(meeting_at)
            and pd.Timedelta(0) <= now - available_at <= pd.Timedelta(CME_FRESHNESS_DAYS, unit="D")
            and meeting_at.normalize() >= now.normalize()
        )
        # Un ancien prix de futures ou une réunion déjà passée ne contribue
        # pas au biais actuel. La dernière observation reste affichable.
        if fresh and ease is not None and hike is not None:
            cme_signal = float(np.clip(ease - hike, -1.0, 1.0))
        cme_values = {
            "meeting_date": row.get("value.meeting_date"),
            "event_time": row.get("event_time"),
            "available_time": row.get("available_time"),
            "fresh": fresh,
            "status": "ACTUEL" if fresh else "PÉRIMÉ OU RÉUNION PASSÉE · EXCLU DU BIAIS",
            "ease_probability": ease,
            "unchanged_probability": unchanged,
            "hike_probability": hike,
            "target_probabilities": row.get("value.target_probabilities"),
            "contract": row.get("value.contract"),
        }

    fed = frame[frame["data_family"] == "FED"].drop_duplicates("instrument", keep="last").copy()
    fed_values: dict[str, Any] | None = None
    fed_policy_signal = None
    if not fed.empty:
        released = fed[pd.to_datetime(fed["event_time"], utc=True) <= now]
        if not released.empty:
            released = released.sort_values("event_time")
            row = released.iloc[-1]
            fed_values = {
                "meeting_date": row.get("value.meeting_date"),
                "minutes_release_date": row.get("value.minutes_release_date"),
                "statement_url": row.get("value.statement_url"),
                "minutes_url": row.get("value.minutes_url"),
                "target_lower_pct": _finite(row.get("value.target_lower_pct")),
                "target_upper_pct": _finite(row.get("value.target_upper_pct")),
                "statement_hawkish_count": _finite(row.get("value.statement_hawkish_count")),
                "statement_dovish_count": _finite(row.get("value.statement_dovish_count")),
                "minutes_hawkish_count": _finite(row.get("value.minutes_hawkish_count")),
                "minutes_dovish_count": _finite(row.get("value.minutes_dovish_count")),
            }
            policy_path = released.dropna(subset=["value.target_lower_pct", "value.target_upper_pct"]).copy()
            if not policy_path.empty:
                policy_path["target_mid_pct"] = (
                    pd.to_numeric(policy_path["value.target_lower_pct"], errors="coerce")
                    + pd.to_numeric(policy_path["value.target_upper_pct"], errors="coerce")
                ) / 2.0
                policy_path["target_change_pp"] = policy_path["target_mid_pct"].diff()
                latest_change = _finite(policy_path.iloc[-1]["target_change_pp"])
                fed_policy_signal = _clip_signal(latest_change, 0.50, invert=True)
                if not series:
                    current.update(
                        {
                            "policy_label": (
                                "ASSOUPLISSEMENT"
                                if latest_change is not None and latest_change < 0
                                else "RESSERREMENT"
                                if latest_change is not None and latest_change > 0
                                else "PAUSE"
                            ),
                            "policy_signal": fed_policy_signal,
                            "fed_funds_3m_change_pp": latest_change,
                        }
                    )
                    history = pd.DataFrame(
                        {
                            "date": pd.to_datetime(policy_path["event_time"], utc=True),
                            "growth_label": "INDISPONIBLE",
                            "inflation_label": "INDISPONIBLE",
                            "liquidity_label": "INDISPONIBLE",
                            "policy_label": policy_path["target_change_pp"].map(
                                lambda value: "ASSOUPLISSEMENT" if pd.notna(value) and value < 0 else "RESSERREMENT" if pd.notna(value) and value > 0 else "PAUSE"
                            ),
                        }
                    )

    combined_signals = [
        value
        for value in (current.get("macro_signal"), cme_signal, fed_policy_signal if not series else None)
        if value is not None
    ]
    combined = float(np.mean(combined_signals)) if combined_signals else None
    if combined is None:
        label = "INDISPONIBLE"
    elif combined >= 0.20:
        label = "PORTEUR POUR LES ACTIFS RISQUÉS"
    elif combined <= -0.20:
        label = "VENT CONTRAIRE POUR LES ACTIFS RISQUÉS"
    else:
        label = "MIXTE / NEUTRE"
    return {
        "available": bool(series or cme_values or fed_values),
        "current": current,
        "regions": regions,
        "history": history,
        "cme": cme_values,
        "fed": fed_values,
        "cme_signal": cme_signal,
        "combined_signal": combined,
        "combined_label": label,
        "fred_current_revision_available": bool(series),
        "vintage_safe": False,
        "backtest_eligible": False,
    }


def macro_feature_overlay(context: dict[str, Any]) -> dict[str, object]:
    """Expose current descriptive macro evidence to the tactical dashboard only."""
    if not context.get("available"):
        return {}
    current = context.get("current", {})
    regions = context.get("regions", {})

    def regional_average(name: str) -> object:
        values = [item.get(name) for item in regions.values() if item.get(name) is not None]
        return float(np.mean(values)) if values else current.get(name)

    return {
        "macro_growth_signal": regional_average("growth_signal"),
        "macro_inflation_signal": regional_average("inflation_signal"),
        "macro_liquidity_signal": regional_average("liquidity_signal"),
        "macro_policy_signal": regional_average("policy_signal"),
        "cme_policy_expectation_signal": context.get("cme_signal"),
    }
