from __future__ import annotations

import math

import numpy as np
import pandas as pd


def scenario_lookback(horizon_days: float) -> pd.Timedelta:
    """Choose enough context for the horizon without overcrowding the chart."""

    horizon = float(horizon_days)
    if horizon <= 0.25:
        return pd.to_timedelta(24, unit="h")
    if horizon <= 1.0:
        return pd.to_timedelta(72, unit="h")
    if horizon <= 7.0:
        return pd.to_timedelta(240, unit="h")
    return pd.to_timedelta(840, unit="h")


def scenario_display_window(horizon_days: float) -> pd.Timedelta:
    """Return the exact time span selected by the dashboard reader."""

    seconds = round(float(horizon_days) * 24 * 60 * 60)
    return pd.to_timedelta(seconds, unit="s")


def scenario_axis_config(latest: object, horizon_days: float) -> dict[str, object]:
    """Build a forward-looking Plotly time axis from the latest observation."""

    origin = pd.to_datetime(latest, utc=True, errors="coerce")
    if pd.isna(origin):
        return {}

    horizon = float(horizon_days)
    if horizon <= 0.25:
        dtick = 60 * 60 * 1000
        tickformat = "%H:%M"
    elif horizon <= 1.0:
        dtick = 4 * 60 * 60 * 1000
        tickformat = "%d/%m\n%H:%M"
    elif horizon <= 7.0:
        dtick = 24 * 60 * 60 * 1000
        tickformat = "%d/%m"
    else:
        dtick = 5 * 24 * 60 * 60 * 1000
        tickformat = "%d/%m"

    return {
        "range": [origin, origin + scenario_display_window(horizon)],
        "dtick": dtick,
        "tickformat": tickformat,
    }


def scenario_projection_points(horizon_days: float) -> int:
    """Return a legible number of points for each prospective horizon."""

    horizon = float(horizon_days)
    if horizon <= 0.25:
        return 17  # one point every 15 minutes over four hours
    if horizon <= 1.0:
        return 25  # hourly
    if horizon <= 7.0:
        return 29  # every six hours
    return 31  # daily


def prepare_forward_scenario_chart(
    *,
    origin: object,
    spot_price: float,
    support: float,
    resistance: float,
    sigma_percent: float,
    directional_score: float,
    horizon_days: float,
) -> pd.DataFrame:
    """Create three conditional paths strictly after the latest observation.

    These paths are a deterministic visualisation of the current thesis, not
    simulated prices or validated probabilities.  Their destinations are tied
    to the point-in-time technical levels and option-implied horizon amplitude.
    """

    start = pd.to_datetime(origin, utc=True, errors="coerce")
    price = float(spot_price)
    horizon = scenario_display_window(horizon_days)
    values = (price, float(support), float(resistance), float(sigma_percent), float(directional_score))
    if pd.isna(start) or horizon <= pd.Timedelta(0) or not all(math.isfinite(value) for value in values) or price <= 0:
        return pd.DataFrame()

    if not 0 < float(support) < price < float(resistance) or float(sigma_percent) <= 0:
        return pd.DataFrame()
    sigma = float(sigma_percent) / 100.0
    lower_level = float(support)
    upper_level = float(resistance)
    tilt = float(np.clip((float(directional_score) - 50.0) / 40.0, -1.0, 1.0))
    central_level = price if abs(tilt) <= 0.025 else price * math.exp(0.12 * tilt * sigma)

    points = scenario_projection_points(horizon_days)
    progress = np.linspace(0.0, 1.0, points)
    # Smoothstep starts at the observed price without implying an instantaneous jump.
    travel = progress * progress * (3.0 - 2.0 * progress)
    dates = pd.date_range(start=start, end=start + horizon, periods=points)

    def path_to(destination: float) -> np.ndarray:
        return price * np.exp(np.log(destination / price) * travel)

    bullish = path_to(upper_level)
    central = path_to(central_level)
    bearish = path_to(lower_level)
    return pd.DataFrame(
        {
            "Date": dates,
            "Scénario haussier": bullish,
            "Scénario central": central,
            "Scénario baissier": bearish,
            "Fourchette basse": np.minimum(bearish, bullish),
            "Fourchette haute": np.maximum(bearish, bullish),
            "Progression": progress,
        }
    )


def scenario_smoothing_points(horizon_days: float) -> int:
    """Return a trailing-only smoothing window for the rendered scenario path."""

    horizon = float(horizon_days)
    if horizon <= 0.25:
        return 3
    if horizon <= 1.0:
        return 4
    if horizon <= 7.0:
        return 6
    return 8


def prepare_scenario_chart(history: pd.DataFrame, horizon_days: float) -> pd.DataFrame:
    """Create a readable, causal scenario corridor from point-in-time rows.

    Only trailing rolling medians are used. A later observation therefore
    cannot alter any earlier value displayed on the chart.
    """

    required = {
        "Date",
        "Prix observé",
        "Cible dominante",
        "Support de thèse",
        "Résistance de thèse",
    }
    if history.empty or not required.issubset(history.columns):
        return pd.DataFrame()

    result = history.copy()
    result["Date"] = pd.to_datetime(result["Date"], utc=True, errors="coerce")
    numeric = [
        "Prix observé",
        "Cible dominante",
        "Support de thèse",
        "Résistance de thèse",
    ]
    if "Invalidation" in result:
        numeric.append("Invalidation")
    for column in numeric:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result = result.dropna(subset=["Date", *required.difference({"Date"})]).sort_values("Date")
    if result.empty:
        return result

    cutoff = result["Date"].max() - scenario_display_window(horizon_days)
    result = result[result["Date"] >= cutoff].copy()
    window = scenario_smoothing_points(horizon_days)
    for column in ("Cible dominante", "Support de thèse", "Résistance de thèse"):
        result[column] = result[column].rolling(window=window, min_periods=1).median()

    result["Zone basse"] = result[["Support de thèse", "Résistance de thèse"]].min(axis=1)
    result["Zone haute"] = result[["Support de thèse", "Résistance de thèse"]].max(axis=1)
    return result.reset_index(drop=True)
