from __future__ import annotations

import pandas as pd


def scenario_lookback(horizon_days: float) -> pd.Timedelta:
    """Choose enough context for the horizon without overcrowding the chart."""

    horizon = float(horizon_days)
    if horizon <= 0.25:
        return pd.to_timedelta(24, unit="h")
    if horizon <= 1.0:
        return pd.to_timedelta(72, unit="h")
    if horizon <= 7.0:
        return pd.to_timedelta(240, unit="h")
    return pd.to_timedelta(840, unit="h")


def scenario_smoothing_points(horizon_days: float) -> int:
    """Return a trailing-only smoothing window for the rendered scenario path."""

    horizon = float(horizon_days)
    if horizon <= 0.25:
        return 3
    if horizon <= 1.0:
        return 4
    if horizon <= 7.0:
        return 6
    return 8


def prepare_scenario_chart(history: pd.DataFrame, horizon_days: float) -> pd.DataFrame:
    """Create a readable, causal scenario corridor from point-in-time rows.

    Only trailing rolling medians are used. A later observation therefore
    cannot alter any earlier value displayed on the chart.
    """

    required = {
        "Date",
        "Prix observé",
        "Cible dominante",
        "Support de thèse",
        "Résistance de thèse",
    }
    if history.empty or not required.issubset(history.columns):
        return pd.DataFrame()

    result = history.copy()
    result["Date"] = pd.to_datetime(result["Date"], utc=True, errors="coerce")
    numeric = [
        "Prix observé",
        "Cible dominante",
        "Support de thèse",
        "Résistance de thèse",
    ]
    if "Invalidation" in result:
        numeric.append("Invalidation")
    for column in numeric:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result = result.dropna(subset=["Date", *required.difference({"Date"})]).sort_values("Date")
    if result.empty:
        return result

    cutoff = result["Date"].max() - scenario_lookback(horizon_days)
    result = result[result["Date"] >= cutoff].copy()
    window = scenario_smoothing_points(horizon_days)
    for column in ("Cible dominante", "Support de thèse", "Résistance de thèse"):
        result[column] = result[column].rolling(window=window, min_periods=1).median()

    result["Zone basse"] = result[["Support de thèse", "Résistance de thèse"]].min(axis=1)
    result["Zone haute"] = result[["Support de thèse", "Résistance de thèse"]].max(axis=1)
    return result.reset_index(drop=True)
