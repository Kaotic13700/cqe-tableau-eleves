from __future__ import annotations

import math
from typing import Mapping

import pandas as pd

from .scenarios import (
    directional_conviction,
    exploratory_direction_index,
    implied_scenario_table,
    tactical_exploitability,
)


BEGINNER_GLOSSARY = {
    "Marché au comptant": "Achats et ventes immédiats de BTC ou d’ETH.",
    "Contrats perpétuels": "Contrats dérivés sans date d’échéance, souvent utilisés avec effet de levier.",
    "Options": "Contrats qui donnent un droit d’achat ou de vente à un prix défini.",
    "Volatilité anticipée": "Amplitude de mouvement que le marché des options intègre dans ses prix.",
    "Gamma": "Sensibilité des options aux variations de prix. Ici, il décrit une possible amplification ou stabilisation, sans supposer la position des intermédiaires.",
    "Anticipations de taux": "Probabilités déduites des contrats de taux suivis par CME FedWatch ; ce ne sont pas des prévisions de la banque centrale.",
    "Vérification dans le temps": "On compare une estimation ancienne avec ce qui s’est réellement passé ensuite, sans réutiliser le futur.",
    "Échantillon effectif": "Nombre d’observations réellement indépendantes après correction du chevauchement temporel.",
    "Test final gelé": "Partie de l’historique gardée intacte jusqu’à l’évaluation finale.",
}


def _finite(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def attach_current_relative_context(
    asset_rows: pd.DataFrame,
    all_rows: pd.DataFrame,
    *,
    tolerance_minutes: int = 30,
) -> pd.DataFrame:
    """Complete only the current display row with a cross-asset value already received.

    BTC and ETH snapshots arrive a few milliseconds apart.  On a cold hosted
    start, the newest BTC row can therefore precede the newest ETH/BTC value.
    Advancing the display row to the later receipt time preserves point-in-time
    ordering while avoiding a false empty cell.  Stale cross-asset values are
    never carried across a collection gap.
    """

    if asset_rows.empty or all_rows.empty or "prediction_time" not in all_rows:
        return asset_rows.copy()
    result = asset_rows.copy()
    result["prediction_time"] = pd.to_datetime(result["prediction_time"], utc=True, format="mixed")
    universe = all_rows.copy()
    universe["prediction_time"] = pd.to_datetime(universe["prediction_time"], utc=True, format="mixed")
    display_time = universe["prediction_time"].max()
    if pd.isna(display_time):
        return result
    candidate_columns = [name for name in ("eth_btc", "eth_btc_return_24h") if name in universe]
    for name in candidate_columns:
        candidates = universe.loc[
            universe[name].notna() & (universe["prediction_time"] <= display_time),
            ["prediction_time", name],
        ].sort_values("prediction_time")
        if candidates.empty:
            continue
        candidate = candidates.iloc[-1]
        candidate_time = pd.Timestamp(candidate["prediction_time"])
        latest_index = result["prediction_time"].idxmax()
        asset_time = pd.Timestamp(result.at[latest_index, "prediction_time"])
        allowed_age = pd.to_timedelta(int(tolerance_minutes), unit="m")
        if display_time - candidate_time > allowed_age or candidate_time - asset_time > allowed_age:
            continue
        if name not in result or pd.isna(result.at[latest_index, name]):
            result.at[latest_index, name] = candidate[name]
            result.at[latest_index, "prediction_time"] = max(
                result.at[latest_index, "prediction_time"], candidate_time
            )
    return result.sort_values("prediction_time").reset_index(drop=True)


def simple_direction_reading(features: Mapping[str, object]) -> dict[str, object]:
    score, _ = exploratory_direction_index(features)
    conviction, conviction_label = directional_conviction(features)
    exploitability = tactical_exploitability(features)
    if score >= 65:
        direction, strength = "Hausse privilégiée", "marquée"
    elif score >= 53:
        direction, strength = "Hausse privilégiée", "modérée"
    elif score > 50:
        direction, strength = "Légère préférence haussière", "faible"
    elif score <= 35:
        direction, strength = "Baisse privilégiée", "marquée"
    elif score <= 47:
        direction, strength = "Baisse privilégiée", "modérée"
    elif score < 50:
        direction, strength = "Légère préférence baissière", "faible"
    else:
        direction, strength = "Équilibre", "neutre"
    if exploitability["context_status"] == "NON EXPLOITABLE":
        caution = "Les données présentes ne suffisent pas à tirer une direction défendable."
    elif exploitability["context_status"] == "À SURVEILLER":
        caution = (
            "Les familles de données sont présentes, mais elles ne s’accordent pas encore assez pour confirmer le biais."
            if exploitability["family_count"] >= 3
            else "Un biais apparaît, mais il manque encore une confirmation indépendante."
        )
    elif conviction < 70:
        caution = "Plusieurs familles convergent, mais la confirmation reste partielle."
    else:
        caution = "Convergence large des familles disponibles ; ce n’est toujours pas une probabilité."
    return {
        "direction": direction,
        "strength": strength,
        "score": score,
        "conviction": conviction,
        "conviction_label": conviction_label,
        "context_status": exploitability["context_status"],
        "prediction_status": exploitability["prediction_status"],
        "agreement": exploitability["agreement"],
        "family_count": exploitability["family_count"],
        "reasons": exploitability["reasons"],
        "caution": caution,
    }


def simple_market_ranges(features: Mapping[str, object]) -> pd.DataFrame:
    """Translate option-implied ranges into a compact, beginner-safe table."""
    table = implied_scenario_table(features)
    if table.empty:
        return pd.DataFrame()
    labels = {"1j": "Prochain jour", "7j": "Prochaine semaine", "30j": "Prochain mois"}
    rows: list[dict[str, object]] = []
    for _, row in table.iterrows():
        horizon = str(row["Horizon"])
        move_column = "P(|mouvement| ≥ 1%)" if horizon == "1j" else "P(|mouvement| ≥ 3%)" if horizon == "7j" else "P(|mouvement| ≥ 5%)"
        threshold = "1 %" if horizon == "1j" else "3 %" if horizon == "7j" else "5 %"
        rows.append(
            {
                "Période": labels.get(horizon, horizon),
                "Zone habituelle estimée": f"${float(row['Zone 68% basse']):,.0f} à ${float(row['Zone 68% haute']):,.0f}",
                "Chance d’un mouvement important": f"≈ {float(row[move_column]):.1f}% pour au moins {threshold}",
                "Lecture": "Fourchette issue des options, symétrique et non directionnelle",
            }
        )
    return pd.DataFrame(rows)


def simple_macro_reading(context: Mapping[str, object]) -> dict[str, object]:
    if not context.get("available"):
        return {
            "label": "Contexte incomplet",
            "explanation": "Les données économiques n’ont pas été reçues ; les décisions de taux restent visibles si disponibles.",
            "rate_path": "Indisponible",
        }
    combined = _finite(context.get("combined_signal"))
    if combined is None:
        label = "Contexte incomplet"
        explanation = "Les informations reçues ne suffisent pas à classer l’environnement économique."
    elif combined >= 0.20:
        label = "Plutôt favorable aux actifs risqués"
        explanation = "Les données disponibles indiquent un coût de l’argent ou une liquidité un peu plus favorables."
    elif combined <= -0.20:
        label = "Plutôt défavorable aux actifs risqués"
        explanation = "Les données disponibles indiquent un coût de l’argent ou une liquidité plus contraignants."
    else:
        label = "Partagé / sans direction nette"
        explanation = "Les forces économiques disponibles se compensent ; elles ne donnent pas de direction claire."
    cme = context.get("cme") or {}
    ease = _finite(cme.get("ease_probability"))
    unchanged = _finite(cme.get("unchanged_probability"))
    hike = _finite(cme.get("hike_probability"))
    if None not in (ease, unchanged, hike):
        options = [(ease, "baisse"), (unchanged, "taux inchangé"), (hike, "hausse")]
        probability, outcome = max(options)
        rate_path = f"Le marché privilégie {outcome} ({100 * probability:.1f} %) à la prochaine réunion suivie."
    else:
        rate_path = "Anticipation de la prochaine décision indisponible."
    return {"label": label, "explanation": explanation, "rate_path": rate_path}


def _valid_coverage(rows: pd.DataFrame, columns: tuple[str, ...]) -> tuple[float, pd.Timestamp | None]:
    present = [column for column in columns if column in rows]
    if rows.empty or not present:
        return 0.0, None
    mask = rows[present].notna().any(axis=1)
    if not mask.any():
        return 0.0, None
    first = pd.to_datetime(rows.loc[mask, "prediction_time"], utc=True, errors="coerce").min()
    return float(mask.mean()), first


def _coverage_label(coverage: float) -> str:
    if coverage >= 0.80:
        return "Solide sur la fenêtre récente"
    if coverage >= 0.20:
        return "En cours de consolidation"
    if coverage > 0:
        return "Historique encore court"
    return "Non disponible"


def data_history_table(
    rows: pd.DataFrame,
    research_summary: Mapping[str, object] | None,
    asset: str,
    macro_context: Mapping[str, object],
) -> pd.DataFrame:
    """Explain historical depth without turning unavailable fields into estimates."""
    rows = rows.sort_values("prediction_time").copy() if not rows.empty else rows.copy()
    core_start: pd.Timestamp | None = None
    core_days: float | None = None
    if research_summary:
        boundary = research_summary.get("_freeze_manifest", {}).get("boundaries", {}).get(asset, {})
        if boundary:
            core_start = pd.Timestamp(boundary.get("history_start"))
            core_end = pd.Timestamp(boundary.get("history_end"))
            core_days = max(0.0, (core_end - core_start).total_seconds() / 86_400)

    families = [
        ("Carnets et positionnement", ("spot_order_book_imbalance", "open_interest_notional_usd"), "Collecte récente ; suivi prospectif uniquement."),
        ("Options et sensibilité gamma", ("atm_iv_30d", "pcr_oi_global", "estimated_gamma_gross_usd_per_1pct_global"), "Collecte récente ; aucun signe d’intermédiaire supposé."),
        ("Comparaison ETH / BTC", ("eth_btc",), "Calculé avec la dernière information déjà connue."),
        ("Liquidations longues / courtes", ("observed_long_liquidation_notional_usd", "observed_short_liquidation_notional_usd"), "Flux continu Binance ; montants observés = borne basse, pas total exhaustif."),
        ("Flux ETF BTC / ETH", ("etf_daily_net_flow_usd",), "Relevé public quotidien, utilisable à partir de sa réception seulement."),
        ("Offre de stablecoins", ("stablecoin_supply_usd", "stablecoin_supply_change_1d_usd"), "Proxy de liquidité globale ; ce n’est pas un flux direct vers les plateformes."),
        ("Dérivés DEX · Hyperliquid", ("dex_oi_weighted_basis", "dex_oi_weighted_funding", "dex_open_interest_notional_usd"), "Collecte publique toutes les 15 minutes ; historique prospectif uniquement."),
    ]
    output: list[dict[str, str]] = [
        {
            "Bloc de données": "Prix, volumes et financement",
            "Historique disponible": f"Depuis {core_start:%d/%m/%Y}" if core_start is not None else "Indisponible",
            "État": f"Socle mature · {core_days:,.0f} jours" if core_days is not None else "Rapport historique absent",
            "Usage actuel": "Backtest validé du socle prix/volume" if core_days is not None else "Non utilisé",
        }
    ]
    for label, columns, usage in families:
        coverage, first = _valid_coverage(rows, columns)
        output.append(
            {
                "Bloc de données": label,
                "Historique disponible": f"Depuis {first:%d/%m/%Y}" if first is not None else "Pas de donnée fiable",
                "État": f"{_coverage_label(coverage)} · {100 * coverage:.0f}% des relevés récents",
                "Usage actuel": usage,
            }
        )

    current = macro_context.get("current", {}) if macro_context else {}
    macro_dimensions = [
        current.get("growth_label"),
        current.get("inflation_label"),
        current.get("liquidity_label"),
        current.get("policy_label"),
    ]
    macro_count = sum(value not in (None, "INDISPONIBLE") for value in macro_dimensions)
    output.append(
        {
            "Bloc de données": "Économie et taux",
            "Historique disponible": "Décisions Fed depuis 2021" if macro_context.get("fed") else "Partiel",
            "État": f"{macro_count}/4 dimensions économiques disponibles",
            "Usage actuel": "Contexte descriptif seulement ; révisions historiques exclues du modèle.",
        }
    )
    return pd.DataFrame(output)


def _distinct_observations(rows: pd.DataFrame, column: str) -> int:
    if rows.empty or column not in rows:
        return 0
    return int(rows[column].dropna().astype(str).nunique())


def confidence_proof_table(
    rows: pd.DataFrame,
    research_summary: Mapping[str, object] | None,
    asset: str,
    macro_context: Mapping[str, object],
) -> pd.DataFrame:
    """Explain every former orange light with a concrete gate and permitted use."""
    boundary = {}
    if research_summary:
        boundary = research_summary.get("_freeze_manifest", {}).get("boundaries", {}).get(asset, {})
    core_days = 0.0
    if boundary:
        core_days = max(
            0.0,
            (pd.Timestamp(boundary["history_end"]) - pd.Timestamp(boundary["history_start"])).total_seconds()
            / 86_400,
        )
    options_count = _distinct_observations(rows, "feature_available_time_options")
    etf_counts = pd.to_numeric(rows.get("etf_history_day_count", pd.Series(dtype=float)), errors="coerce").dropna()
    etf_count = int(etf_counts.max()) if not etf_counts.empty else _distinct_observations(rows, "etf_trading_date")
    stablecoin_count = _distinct_observations(rows, "stablecoin_observation_time")
    liquidation_count = _distinct_observations(rows, "liquidations_observation_time")
    dex_count = _distinct_observations(rows, "feature_available_time_perps") if "perp_dex_exchange_coverage" in rows else 0
    regions = macro_context.get("regions", {}) if macro_context else {}
    current = macro_context.get("current", {}) if macro_context else {}
    macro_current = sum(
        state.get(name) not in (None, "INDISPONIBLE")
        for state in regions.values()
        for name in ("growth_label", "inflation_label", "liquidity_label", "policy_label")
    ) if regions else sum(
        current.get(name) not in (None, "INDISPONIBLE")
        for name in ("growth_label", "inflation_label", "liquidity_label", "policy_label")
    )
    macro_total = max(4, 4 * len(regions))
    return pd.DataFrame(
        [
            {
                "Preuve": "Prix / volumes",
                "État": "✅ SOCLE MATURE" if core_days >= 730 else "🟠 EN MATURATION",
                "Mesure": f"{core_days:,.0f} jours historiques",
                "Usage autorisé": "Taux de base et tests hors échantillon",
            },
            {
                "Preuve": "Spot et perpétuels",
                "État": "🟦 TESTÉS, NON PROMUS" if core_days >= 730 else "🟠 EN MATURATION",
                "Mesure": "Aucun gain robuste contre le taux de base",
                "Usage autorisé": "Contexte tactique ; pas de probabilité conditionnelle",
            },
            {
                "Preuve": "Options / gamma",
                "État": "🟠 COLLECTE FORWARD",
                "Mesure": f"{options_count:,} relevés distincts / seuil 2 688",
                "Usage autorisé": "Amplitude et scénarios ; pas de signe dealer supposé",
            },
            {
                "Preuve": "ETF BTC / ETH",
                "État": "🟠 COLLECTE QUOTIDIENNE" if etf_count < 60 else "🟦 PRÊT À TESTER",
                "Mesure": f"{etf_count} journées reçues / seuil 60",
                "Usage autorisé": "Affichage descriptif jusqu’au test walk-forward",
            },
            {
                "Preuve": "Stablecoins",
                "État": "🟠 COLLECTE QUOTIDIENNE" if stablecoin_count < 60 else "🟦 PRÊT À TESTER",
                "Mesure": f"{stablecoin_count} snapshots distincts / seuil 60",
                "Usage autorisé": "Proxy de liquidité, séparé des flux d’exchange",
            },
            {
                "Preuve": "Liquidations longues / courtes",
                "État": "🟠 FLUX FORWARD" if liquidation_count < 2_688 else "🟦 PRÊT À TESTER",
                "Mesure": f"{liquidation_count:,} fenêtres capturées / seuil 2 688",
                "Usage autorisé": "Borne basse observée ; jamais présentée comme total marché",
            },
            {
                "Preuve": "Dérivés DEX · Hyperliquid",
                "État": "🟠 COLLECTE FORWARD" if dex_count < 2_688 else "🟦 PRÊT À TESTER",
                "Mesure": f"{dex_count:,} relevés DEX / seuil 2 688",
                "Usage autorisé": "Contexte tactique ; poids validé seulement après walk-forward",
            },
            {
                "Preuve": "Macro quotidienne Fed / BCE / BoJ",
                "État": "✅ CONTEXTE COMPLET" if macro_current == macro_total else "🟠 COUVERTURE PARTIELLE",
                "Mesure": f"Contexte courant {macro_current}/{macro_total} dimensions nommées",
                "Usage autorisé": "Lecture actuelle ; versions historiques séparées avant backtest",
            },
            {
                "Preuve": "Validation finale",
                "État": "✅ TAUX DE BASE VALIDÉ",
                "Mesure": "Modèles conditionnels rejetés par les garde-fous",
                "Usage autorisé": "Fréquence historique seulement, pas conseil ni certitude",
            },
        ]
    )
