from __future__ import annotations

import math
from typing import Mapping

import pandas as pd

from .scenarios import (
    FAMILY_EXPECTED_COUNTS,
    directional_evidence_table,
    directional_family_scores,
    directional_thesis,
)


DECISION_HORIZONS: dict[str, float] = {
    "4 heures": 4 / 24,
    "1 jour": 1.0,
    "7 jours": 7.0,
    "30 jours": 30.0,
}


def _finite(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _coverage_counts(features: Mapping[str, object]) -> tuple[int, int]:
    evidence = directional_evidence_table(features)
    present = 0
    expected = sum(FAMILY_EXPECTED_COUNTS.values())
    for value in evidence.get("Couverture", pd.Series(dtype=str)):
        try:
            received, _ = str(value).split("/", maxsplit=1)
            present += int(received)
        except (TypeError, ValueError):
            continue
    return present, expected


def _vote_counts(features: Mapping[str, object]) -> dict[str, int]:
    scores = directional_family_scores(features)
    bullish = sum(value >= 0.20 for value in scores.values())
    bearish = sum(value <= -0.20 for value in scores.values())
    neutral = sum(-0.20 < value < 0.20 for value in scores.values())
    return {
        "bullish": bullish,
        "bearish": bearish,
        "neutral": neutral,
        "available": len(scores),
        "total": len(FAMILY_EXPECTED_COUNTS),
    }


def _data_quality(
    features: Mapping[str, object],
    *,
    observation_time: pd.Timestamp,
    now: pd.Timestamp,
) -> dict[str, object]:
    present, expected = _coverage_counts(features)
    coverage = present / expected if expected else 0.0
    age_minutes = max(0.0, (now - observation_time).total_seconds() / 60.0)
    freshness = 1.0 if age_minutes <= 30 else 0.5 if age_minutes <= 120 else 0.0
    score = round(100.0 * (0.80 * coverage + 0.20 * freshness), 1)
    if present == expected and age_minutes <= 30:
        label = "COMPLÈTE"
    elif age_minutes > 30:
        label = "À ACTUALISER"
    elif score >= 75:
        label = "OPÉRATIONNELLE"
    elif score >= 50:
        label = "PARTIELLE"
    else:
        label = "DÉGRADÉE"
    return {
        "score": score,
        "label": label,
        "present_measures": present,
        "expected_measures": expected,
        "coverage_percent": round(100.0 * coverage, 1),
        "age_minutes": age_minutes,
        "fresh": age_minutes <= 30,
    }


def _multi_horizon(
    features: Mapping[str, object], history: pd.DataFrame
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for label, horizon in DECISION_HORIZONS.items():
        thesis = directional_thesis(features, history, horizon=horizon)
        if not thesis.get("available"):
            rows.append(
                {
                    "Horizon": label,
                    "Biais": "INDISPONIBLE",
                    "Zone dominante": None,
                    "Invalidation": None,
                    "Amplitude implicite": None,
                }
            )
            continue
        rows.append(
            {
                "Horizon": label,
                "Biais": thesis["bias"],
                "Zone dominante": float(thesis["dominant_target"]),
                "Invalidation": float(thesis["invalidation_level"]),
                "Invalidation détaillée": str(thesis["invalidation"]),
                "Amplitude implicite": float(thesis["sigma_percent"]),
            }
        )
    return pd.DataFrame(rows)


def _change_log(
    ordered: pd.DataFrame,
) -> dict[str, object]:
    """Compare the last two market observations without retroactive overlays."""

    if len(ordered) < 2:
        return {"available": False, "rows": pd.DataFrame()}
    previous_row = ordered.iloc[-2]
    current = ordered.iloc[-1].to_dict()
    previous = previous_row.to_dict()

    current_price = _finite(current.get("spot_price"))
    previous_price = _finite(previous.get("spot_price"))
    price_delta = (
        100.0 * (current_price / previous_price - 1.0)
        if current_price is not None and previous_price not in (None, 0.0)
        else None
    )
    current_iv = _finite(current.get("atm_iv_7d"))
    previous_iv = _finite(previous.get("atm_iv_7d"))
    iv_delta = current_iv - previous_iv if current_iv is not None and previous_iv is not None else None
    rows = pd.DataFrame(
        [
            {
                "Mesure": "Prix observé",
                "Maintenant": current_price,
                "Évolution": price_delta,
                "Unité": "price_pct",
            },
            {
                "Mesure": "Volatilité implicite 7 jours",
                "Maintenant": current_iv,
                "Évolution": iv_delta,
                "Unité": "percentage_points",
            },
        ]
    )
    # Only directly comparable observations belong in this journal. Current
    # descriptive macro overlays have no archived prior vintage here: showing
    # an unadjusted bias beside the overlaid headline would contradict it.
    return {
        "available": True,
        "previous_time": pd.Timestamp(previous_row["prediction_time"]),
        "current_time": pd.Timestamp(ordered.iloc[-1]["prediction_time"]),
        "rows": rows,
    }


def build_decision_snapshot(
    market_rows: pd.DataFrame,
    macro_overlay: Mapping[str, object] | None = None,
    *,
    now: object | None = None,
) -> dict[str, object]:
    """Build one point-in-time source of truth for every decision view."""

    if market_rows.empty or "prediction_time" not in market_rows:
        return {"available": False}
    ordered = market_rows.copy()
    ordered["prediction_time"] = pd.to_datetime(ordered["prediction_time"], utc=True, errors="coerce")
    ordered = ordered.dropna(subset=["prediction_time"]).sort_values("prediction_time").reset_index(drop=True)
    if ordered.empty:
        return {"available": False}
    overlay = dict(macro_overlay or {})
    latest = {**ordered.iloc[-1].to_dict(), **overlay}
    observation_time = pd.Timestamp(ordered.iloc[-1]["prediction_time"])
    reference_time = pd.to_datetime(now, utc=True, errors="coerce") if now is not None else pd.Timestamp.now(tz="UTC")
    if pd.isna(reference_time):
        reference_time = pd.Timestamp.now(tz="UTC")
    return {
        "available": True,
        "latest": latest,
        "observation_time": observation_time,
        "thesis_7d": directional_thesis(latest, ordered, horizon=7.0),
        "votes": _vote_counts(latest),
        "evidence": directional_evidence_table(latest),
        "quality": _data_quality(
            latest,
            observation_time=observation_time,
            now=pd.Timestamp(reference_time),
        ),
        "multi_horizon": _multi_horizon(latest, ordered),
        "changes": _change_log(ordered),
    }
