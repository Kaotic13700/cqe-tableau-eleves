"""Versioned, causal horizon evidence. Descriptive rules, not fitted forecasts."""
import math
import numpy as np
import pandas as pd

VERSION = "horizon-evidence-v5-derivatives-components"
# Observation windows are not forecast probabilities or fitted parameters.
PROFILES = {
    4 / 24: ("4 heures", "15 min", ("Spot", "Perpétuels", "Liquidations", "Dérivés DEX")),
    1.0: ("1 jour", "1 h", ("Spot", "Perpétuels", "Options", "ETF / liquidité", "Force relative", "Dérivés DEX")),
    7.0: ("7 jours", "4 h", ("Spot", "Perpétuels", "Options", "Macro / taux", "ETF / liquidité")),
    30.0: ("30 jours", "1 jour", ("Spot", "Options", "Macro / taux", "ETF / liquidité")),
}


def horizon_evidence(features, history, horizon):
    from .scenarios import _directional_signals, FAMILY_WEIGHTS, FAMILY_EXPECTED_COUNTS
    days = min(PROFILES, key=lambda d: abs(d - horizon))
    label, confirmation, selected = PROFILES[days]
    now = pd.to_datetime(features.get("prediction_time"), utc=True, errors="coerce")
    frame = pd.DataFrame() if history is None else history.copy()
    if pd.isna(now) or "prediction_time" not in frame:
        frame = pd.DataFrame()
    else:
        frame["prediction_time"] = pd.to_datetime(frame["prediction_time"], utc=True, errors="coerce", format="mixed")
        frame = frame[frame["prediction_time"] <= now]
        if "asset" in frame and features.get("asset"):
            frame = frame[frame["asset"] == features["asset"]]
        if "available_time" in frame:
            availability = pd.to_datetime(frame["available_time"], utc=True, errors="coerce", format="mixed")
            frame = frame[availability <= frame["prediction_time"]]
        frame = frame.sort_values("prediction_time").drop_duplicates("prediction_time", keep="last")
        frame = frame[frame["prediction_time"] >= now - pd.Timedelta(days=days)]
    notes = []
    complete = False
    if len(frame) >= 2:
        times = frame["prediction_time"]
        complete = ((times.iloc[-1] - times.iloc[0]).total_seconds() >= days * 86400 * .9
                    and (now-times.iloc[-1]).total_seconds() <= 1800
                    and times.diff().dropna().max() <= pd.Timedelta(minutes=30))
    if not complete:
        notes.append(f"Fenêtre historique {label} incomplète : lecture provisoire, sans extrapoler les observations absentes.")
    from .price_context import describe_price_window
    price_note = describe_price_window(frame, complete)
    if price_note:
        notes.append(price_note)
    current = dict(features)
    # Do not let a daily ETF print and a month-long supply change count as
    # interchangeable observations of the same horizon.
    if days == 1:
        for key in ("etf_flow_5d_usd", "stablecoin_supply_change_7d_usd", "stablecoin_supply_change_30d_usd"):
            current.pop(key, None)
    elif days >= 7:
        current.pop("etf_daily_net_flow_usd", None)
        current.pop("stablecoin_supply_change_30d_usd" if days == 7 else "stablecoin_supply_change_7d_usd", None)
    named, raw = _directional_signals(current)
    scores, weights = {}, {}
    fast = {"Spot", "Perpétuels", "Options", "Dérivés DEX"}
    for family in selected:
        if family in ("Perpétuels", "Dérivés DEX") and features.get("settled_funding_context"):
            from ..collectors.historical.funding_context import summarize
            samples = summarize(features["settled_funding_context"], now, days,
                                ("bybit", "okx", "bitget") if family == "Perpétuels" else ("hyperliquid",))
            if samples:
                hourly = float(np.mean([s["hourly_rate"] for s in samples]))
                # Le financement réalisé remplace uniquement le financement
                # instantané, jamais la prime. Deux composantes, un seul vote.
                funding_signal = float(-np.tanh(hourly * 8 / .0005))
                components = [funding_signal]
                basis_name = "Basis perp CEX" if family == "Perpétuels" else "Prime perp DEX"
                basis = named.get(basis_name)
                basis_scope = "dernier relevé"
                if complete:
                    basis_history = []
                    for row in frame.to_dict("records"):
                        past_named, _ = _directional_signals(row)
                        if basis_name in past_named:
                            basis_history.append(past_named[basis_name])
                    if len(basis_history) >= .9 * len(frame):
                        basis = float(np.mean(basis_history))
                        basis_scope = f"moyenne des signaux sur {label}"
                # Une prime instantanée ne devient pas une prime hebdomadaire.
                if basis is not None and (days < 7 or basis_scope != "dernier relevé"):
                    components.append(basis)
                    notes.append(f"{family} : prime intégrée séparément ({basis_scope}), "
                                 "avec le financement réalisé ; financement instantané non compté une seconde fois.")
                else:
                    notes.append(f"{family} : financement seul ; prime de l’horizon non établie.")
                scores[family] = float(np.mean(components))
                weights[family] = FAMILY_WEIGHTS[family] * len(components) / FAMILY_EXPECTED_COUNTS[family]
                descriptions = []
                for s in samples:
                    first=pd.to_datetime(s["start"],unit="ms",utc=True).strftime("%d/%m %H:%M")
                    last=pd.to_datetime(s["end"],unit="ms",utc=True).strftime("%d/%m %H:%M")
                    descriptions.append(f"{s['venue']} : {s['count']} règlements, {first} → {last} UTC")
                notes.append(f"{family} : financement réalisé moyen {hourly*100:.6f} %/h ; "
                             + "; ".join(descriptions) + ". Moyenne équipondérée des plateformes, pas prime historique. "
                             "Si aucun règlement dans les 4 h, le dernier intervalle réglé est utilisé et daté.")
                continue
        vals = raw[family]
        if not vals:
            continue
        value = float(np.mean(vals))
        if family in fast and complete:
            observations = []
            for row in frame.to_dict("records"):
                _, past = _directional_signals(row)
                if past[family]:
                    observations.append(float(np.mean(past[family])))
            if len(observations) >= .9 * len(frame):
                value = float(np.mean(observations))
            else:
                notes.append(f"{family} : lecture du relevé courant ; l’historique de cette mesure n’est pas reconstitué.")
        if days >= 7 and family == "Spot":
            # A current order book is not a monthly trend.
            continue
        scores[family] = value
        weights[family] = FAMILY_WEIGHTS[family] * min(len(vals)/FAMILY_EXPECTED_COUNTS[family], 1)
    if complete and "spot_price" in frame:
        prices = pd.to_numeric(frame["spot_price"], errors="coerce")
        if np.isfinite(prices).all() and (prices > 0).all():
            returns = np.log(prices).diff().dropna()
            dispersion = float(np.sqrt(np.square(returns).sum()))
            if dispersion > 0:
                trend = float(np.tanh(math.log(prices.iloc[-1]/prices.iloc[0])/dispersion))
                # Trend and order flow share one Spot vote, never double counted.
                scores["Spot"] = (scores["Spot"] + trend)/2 if "Spot" in scores else trend
                weights["Spot"] = FAMILY_WEIGHTS["Spot"]
    total = sum(weights.values())
    composite = sum(scores[k]*weights[k] for k in scores)/total if total else 0.
    coverage = total / sum(FAMILY_WEIGHTS[k] for k in selected)
    agreement = sum(weights[k] for k in scores if scores[k]*composite > 0)/total if total else 0.
    conviction = 100 * coverage * agreement * min(abs(composite)/.5, 1.)
    if not complete:
        notes.append("Les signaux disponibles restent visibles ; cette lecture n’est pas validée hors échantillon par horizon.")
    return dict(score=50+40*composite, conviction=conviction, families=scores,
                confirmation=confirmation, label=label, notes=list(dict.fromkeys(notes)),
                historical_window_complete=complete, version=VERSION, history=frame,
                method=f"Fenêtre d’observation {label} ; familles actives : {', '.join(scores) or 'aucune'}. "
                       "Règles exploratoires non calibrées, pas probabilités de réussite.")
